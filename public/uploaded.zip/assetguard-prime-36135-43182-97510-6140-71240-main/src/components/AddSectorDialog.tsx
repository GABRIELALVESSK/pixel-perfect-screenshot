import { useState } from "react";
import { Button } from "@/components/ui/button";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { useData } from "@/contexts/DataContext";
import { toast } from "sonner";

interface AddSectorDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
}

export function AddSectorDialog({ open, onOpenChange }: AddSectorDialogProps) {
  const { addDepartment, locations } = useData();
  const [qtd, setQtd] = useState("");
  const [codigo, setCodigo] = useState("");
  const [sigla, setSigla] = useState("");
  const [description, setDescription] = useState("");
  const [encarregado, setEncarregado] = useState("");
  const [idFuncEnc, setIdFuncEnc] = useState("");
  const [substituto, setSubstituto] = useState("");
  const [idFuncSub, setIdFuncSub] = useState("");
  const [locationId, setLocationId] = useState("");

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    // Converter strings vazias para null
    const toNull = (val: string) => val.trim() || null;
    
    try {
      await addDepartment({
        name: description,
        qtd: qtd ? parseInt(qtd) : null,
        codigo: toNull(codigo),
        sigla: toNull(sigla),
        encarregado: toNull(encarregado),
        id_funcional_encarregado: toNull(idFuncEnc),
        substituto: toNull(substituto),
        id_funcional_substituto: toNull(idFuncSub),
        location_id: locationId || null,
        responsible_id: null,
        created_at: new Date().toISOString(),
        updated_at: new Date().toISOString(),
      });
      
      toast.success("Subunidade cadastrada com sucesso!");
      onOpenChange(false);
      
      // Reset form
      setQtd("");
      setCodigo("");
      setSigla("");
      setDescription("");
      setEncarregado("");
      setIdFuncEnc("");
      setSubstituto("");
      setIdFuncSub("");
      setLocationId("");
    } catch (error) {
      toast.error("Erro ao cadastrar subunidade");
      console.error(error);
    }
  };

  const predios = locations.filter(l => l.type === "Prédio" || l.type === "Unidade");

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-[600px] max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>Nova Subunidade</DialogTitle>
          <DialogDescription>
            Cadastre uma nova subunidade e vincule a um prédio.
          </DialogDescription>
        </DialogHeader>
        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="qtd">QTD</Label>
              <Input
                id="qtd"
                type="number"
                placeholder="Ex: 1"
                value={qtd}
                onChange={(e) => setQtd(e.target.value)}
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="codigo">Código</Label>
              <Input
                id="codigo"
                placeholder="Ex: 01"
                value={codigo}
                onChange={(e) => setCodigo(e.target.value)}
              />
            </div>
          </div>

          <div className="space-y-2">
            <Label htmlFor="sigla">Sigla</Label>
            <Input
              id="sigla"
              placeholder="Ex: ASSAACG"
              value={sigla}
              onChange={(e) => setSigla(e.target.value)}
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="description">Descrição (Nome Completo) *</Label>
            <Input
              id="description"
              placeholder="Ex: ASSESSORIA DE APOIO ADMINISTRATIVO"
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              required
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="location">Prédio Vinculado</Label>
          <Select value={locationId || "none"} onValueChange={(val) => setLocationId(val === "none" ? "" : val)}>
              <SelectTrigger>
                <SelectValue placeholder="Selecione o prédio" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="none">Nenhum</SelectItem>
                {predios.map((loc) => (
                  <SelectItem key={loc.id} value={loc.id}>
                    {loc.name}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          <div className="space-y-2">
            <Label htmlFor="encarregado">Encarregado</Label>
            <Input
              id="encarregado"
              placeholder="Ex: MARIO SERGIO EUGÊNIO MENDES"
              value={encarregado}
              onChange={(e) => setEncarregado(e.target.value)}
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="idFuncEnc">ID Funcional (Encarregado)</Label>
            <Input
              id="idFuncEnc"
              placeholder="Ex: 4390041-0"
              value={idFuncEnc}
              onChange={(e) => setIdFuncEnc(e.target.value)}
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="substituto">Substituto</Label>
            <Input
              id="substituto"
              placeholder="Ex: PATRICK PINTO MARTINS FERREIRA"
              value={substituto}
              onChange={(e) => setSubstituto(e.target.value)}
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="idFuncSub">ID Funcional (Substituto)</Label>
            <Input
              id="idFuncSub"
              placeholder="Ex: 5122059-8"
              value={idFuncSub}
              onChange={(e) => setIdFuncSub(e.target.value)}
            />
          </div>

          <div className="flex justify-end gap-2 pt-4">
            <Button type="button" variant="outline" onClick={() => onOpenChange(false)}>
              Cancelar
            </Button>
            <Button type="submit">Cadastrar Subunidade</Button>
          </div>
        </form>
      </DialogContent>
    </Dialog>
  );
}
