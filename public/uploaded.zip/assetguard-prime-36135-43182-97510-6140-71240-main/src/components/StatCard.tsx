import { LucideIcon } from "lucide-react";
import { Card, CardContent } from "@/components/ui/card";

interface StatCardProps {
  title: string;
  value: string | number;
  change?: string;
  icon: LucideIcon;
  iconColor: string;
}

export function StatCard({ title, value, change, icon: Icon, iconColor }: StatCardProps) {
  const isPositive = change?.includes("+");
  const changeValue = change?.split(' ')[0];
  
  return (
    <Card className="border-border bg-card/50 backdrop-blur">
      <CardContent className="flex items-start justify-between p-6">
        <div className="flex-1">
          <p className="text-sm font-medium text-muted-foreground">{title}</p>
          <h3 className="mt-2 text-3xl font-bold text-foreground">{value}</h3>
          {change && (
            <p className={`mt-2 text-sm font-medium flex items-center gap-1 ${isPositive ? 'text-success' : 'text-destructive'}`}>
              {changeValue} em relação ao período anterior
            </p>
          )}
        </div>
        <div className={`rounded-xl p-3 ${iconColor}`}>
          <Icon className="h-6 w-6" />
        </div>
      </CardContent>
    </Card>
  );
}
