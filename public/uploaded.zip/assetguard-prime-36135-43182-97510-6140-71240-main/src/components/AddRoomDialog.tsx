import { useState } from "react";
import { Button } from "@/components/ui/button";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { useData } from "@/contexts/DataContext";
import { toast } from "sonner";

interface AddRoomDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
}

export function AddRoomDialog({ open, onOpenChange }: AddRoomDialogProps) {
  const { addLocation, locations, departments } = useData();
  const [name, setName] = useState("");
  const [locationId, setLocationId] = useState("");
  const [departmentId, setDepartmentId] = useState("");
  const [floor, setFloor] = useState("");
  const [capacity, setCapacity] = useState("");
  const [roomType, setRoomType] = useState("");

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    try {
      await addLocation({
        name,
        type: "Sala",
        parent: locationId || undefined,
        floors: floor ? parseInt(floor) : undefined,
        status: true,
      });
      
      toast.success("Sala cadastrada com sucesso!");
      onOpenChange(false);
      
      // Reset form
      setName("");
      setLocationId("");
      setDepartmentId("");
      setFloor("");
      setCapacity("");
      setRoomType("");
    } catch (error) {
      toast.error("Erro ao cadastrar sala");
      console.error(error);
    }
  };

  const predios = locations.filter(l => l.type === "Prédio" || l.type === "Unidade");

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-[500px]">
        <DialogHeader>
          <DialogTitle>Nova Sala</DialogTitle>
          <DialogDescription>
            Cadastre uma nova sala, escritório ou espaço específico.
          </DialogDescription>
        </DialogHeader>
        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="space-y-2">
            <Label htmlFor="name">Nome/Número da Sala *</Label>
            <Input
              id="name"
              placeholder="Ex: Sala 301, Auditório B"
              value={name}
              onChange={(e) => setName(e.target.value)}
              required
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="location">Localização (Prédio/Unidade)</Label>
            <Select value={locationId} onValueChange={setLocationId}>
              <SelectTrigger>
                <SelectValue placeholder="Selecione a localização" />
              </SelectTrigger>
              <SelectContent>
                {predios.map((loc) => (
                  <SelectItem key={loc.id} value={loc.id}>
                    {loc.name}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          <div className="space-y-2">
            <Label htmlFor="department">Setor</Label>
            <Select value={departmentId} onValueChange={setDepartmentId}>
              <SelectTrigger>
                <SelectValue placeholder="Selecione o setor" />
              </SelectTrigger>
              <SelectContent>
                {departments.map((dept) => (
                  <SelectItem key={dept.id} value={dept.id}>
                    {dept.name}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          <div className="space-y-2">
            <Label htmlFor="floor">Andar</Label>
            <Select value={floor} onValueChange={setFloor}>
              <SelectTrigger>
                <SelectValue placeholder="Selecione o andar" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="0">Térreo</SelectItem>
                <SelectItem value="1">1º Andar</SelectItem>
                <SelectItem value="2">2º Andar</SelectItem>
                <SelectItem value="3">3º Andar</SelectItem>
                <SelectItem value="4">4º Andar</SelectItem>
                <SelectItem value="5">5º Andar</SelectItem>
              </SelectContent>
            </Select>
          </div>

          <div className="space-y-2">
            <Label htmlFor="capacity">Capacidade (Pessoas)</Label>
            <Input
              id="capacity"
              type="number"
              placeholder="0"
              value={capacity}
              onChange={(e) => setCapacity(e.target.value)}
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="roomType">Tipo de Sala</Label>
            <Select value={roomType} onValueChange={setRoomType}>
              <SelectTrigger>
                <SelectValue placeholder="Selecione o tipo de sala" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="escritorio">Escritório</SelectItem>
                <SelectItem value="reuniao">Sala de Reunião</SelectItem>
                <SelectItem value="auditorio">Auditório</SelectItem>
                <SelectItem value="laboratorio">Laboratório</SelectItem>
                <SelectItem value="almoxarifado">Almoxarifado</SelectItem>
                <SelectItem value="outro">Outro</SelectItem>
              </SelectContent>
            </Select>
          </div>

          <div className="flex justify-end gap-2 pt-4">
            <Button type="button" variant="outline" onClick={() => onOpenChange(false)}>
              Cancelar
            </Button>
            <Button type="submit">Cadastrar Sala</Button>
          </div>
        </form>
      </DialogContent>
    </Dialog>
  );
}
