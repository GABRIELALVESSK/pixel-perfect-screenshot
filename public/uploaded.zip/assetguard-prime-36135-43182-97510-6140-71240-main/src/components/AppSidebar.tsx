import { Link, useLocation } from "react-router-dom";
import {
  LayoutDashboard,
  Package,
  MapPin,
  ClipboardList,
  TrendingDown,
  ArrowLeftRight,
  BarChart3,
  Users,
} from "lucide-react";
import {
  Sidebar,
  SidebarContent,
  SidebarGroup,
  SidebarGroupContent,
  SidebarGroupLabel,
  SidebarMenu,
  SidebarMenuButton,
  SidebarMenuItem,
  SidebarHeader,
} from "@/components/ui/sidebar";
import { useUserRole } from "@/hooks/useUserRole";

export function AppSidebar() {
  const location = useLocation();
  const { isAdmin, isManager, loading } = useUserRole();

  // Items que o admin pode ver (todos)
  const adminNavigationItems = [
    { title: "Dashboard", url: "/", icon: LayoutDashboard },
    { title: "Bens Patrimoniais", url: "/bens", icon: Package },
    { title: "Localizações", url: "/localizacoes", icon: MapPin },
    { title: "Inventário", url: "/inventario", icon: ClipboardList },
    { title: "Depreciação", url: "/depreciacao", icon: TrendingDown },
    { title: "Transferência de Bens", url: "/transferencias", icon: ArrowLeftRight },
    { title: "Relatórios", url: "/relatorios", icon: BarChart3 },
  ];

  // Items que o manager pode ver (apenas bens e transferências)
  const managerNavigationItems = [
    { title: "Bens Patrimoniais", url: "/bens", icon: Package },
    { title: "Transferência de Bens", url: "/transferencias", icon: ArrowLeftRight },
  ];

  const adminItems = [
    { title: "Gerenciamento de Usuários", url: "/usuarios", icon: Users },
  ];

  // Selecionar items baseado no role
  const navigationItems = isAdmin ? adminNavigationItems : isManager ? managerNavigationItems : [];

  if (loading) {
    return (
      <Sidebar className="border-r border-sidebar-border">
        <SidebarHeader className="border-b border-sidebar-border px-6 py-4">
          <h1 className="text-lg font-semibold text-foreground">Gestão Patrimonial</h1>
        </SidebarHeader>
        <SidebarContent>
          <div className="flex items-center justify-center py-8">
            <span className="text-muted-foreground">Carregando...</span>
          </div>
        </SidebarContent>
      </Sidebar>
    );
  }

  return (
    <Sidebar className="border-r border-sidebar-border">
      <SidebarHeader className="border-b border-sidebar-border px-6 py-4">
        <h1 className="text-lg font-semibold text-foreground">Gestão Patrimonial</h1>
      </SidebarHeader>
      <SidebarContent>
        <SidebarGroup>
          <SidebarGroupLabel className="px-6 text-xs uppercase text-muted-foreground">
            Navegação
          </SidebarGroupLabel>
          <SidebarGroupContent>
            <SidebarMenu>
              {navigationItems.map((item) => {
                const isActive = location.pathname === item.url;
                return (
                  <SidebarMenuItem key={item.title}>
                    <SidebarMenuButton
                      asChild
                      isActive={isActive}
                      className="px-6 hover:bg-sidebar-accent"
                    >
                      <Link to={item.url} className="flex items-center gap-3">
                        <item.icon className="h-4 w-4" />
                        <span>{item.title}</span>
                      </Link>
                    </SidebarMenuButton>
                  </SidebarMenuItem>
                );
              })}
            </SidebarMenu>
          </SidebarGroupContent>
        </SidebarGroup>

        {isAdmin && (
          <SidebarGroup>
            <SidebarGroupLabel className="px-6 text-xs uppercase text-muted-foreground">
              Administração
            </SidebarGroupLabel>
            <SidebarGroupContent>
              <SidebarMenu>
                {adminItems.map((item) => {
                  const isActive = location.pathname === item.url;
                  return (
                    <SidebarMenuItem key={item.title}>
                      <SidebarMenuButton
                        asChild
                        isActive={isActive}
                        className="px-6 hover:bg-sidebar-accent"
                      >
                        <Link to={item.url} className="flex items-center gap-3">
                          <item.icon className="h-4 w-4" />
                          <span>{item.title}</span>
                        </Link>
                      </SidebarMenuButton>
                    </SidebarMenuItem>
                  );
                })}
              </SidebarMenu>
            </SidebarGroupContent>
          </SidebarGroup>
        )}
      </SidebarContent>
    </Sidebar>
  );
}
