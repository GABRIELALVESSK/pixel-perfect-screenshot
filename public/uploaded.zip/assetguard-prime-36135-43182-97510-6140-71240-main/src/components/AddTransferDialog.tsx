import { useState } from 'react';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { useData } from "@/contexts/DataContext";
import { useAuth } from "@/hooks/useAuth";
import { supabase } from "@/integrations/supabase/client";
import { useToast } from "@/hooks/use-toast";
import { Loader2 } from "lucide-react";

interface AddTransferDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  onSuccess?: () => void;
}

export function AddTransferDialog({ open, onOpenChange, onSuccess }: AddTransferDialogProps) {
  const { assets, locations, departments, users } = useData();
  const { user } = useAuth();
  const { toast } = useToast();
  const [loading, setLoading] = useState(false);
  const [formData, setFormData] = useState({
    assetId: '',
    toLocationId: '',
    toDepartmentId: '',
    notes: '',
  });

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!user) return;

    setLoading(true);

    try {
      // Get asset details to find current location
      const selectedAsset = assets.find(a => a.id === formData.assetId);
      if (!selectedAsset) {
        throw new Error('Bem não encontrado');
      }

      // Find the department manager (encarregado) of the origin department
      const originDept = departments.find(d => d.id === selectedAsset.department_id);
      const destDept = departments.find(d => d.id === formData.toDepartmentId);

      // Create the transfer
      const { data: transfer, error: transferError } = await supabase
        .from('transfers')
        .insert({
          asset_id: formData.assetId,
          from_location_id: selectedAsset.location_id,
          to_location_id: formData.toLocationId,
          from_department_id: selectedAsset.department_id,
          to_department_id: formData.toDepartmentId,
          requester_id: user.id,
          responsible_id: user.id,
          status: 'Aguardando Aprovação Origem',
          notes: formData.notes,
        })
        .select()
        .single();

      if (transferError) throw transferError;

      // Get location names for notification
      const fromLocation = locations.find(l => l.id === selectedAsset.location_id);
      const toLocation = locations.find(l => l.id === formData.toLocationId);

      // Create in-app notification for origin department manager
      if (originDept?.responsible_id) {
        await supabase.from('notifications').insert({
          user_id: originDept.responsible_id,
          title: 'Nova Transferência Iniciada',
          message: `Solicitação de transferência do bem "${selectedAsset.name}" de ${fromLocation?.name || 'N/A'} para ${toLocation?.name || 'N/A'}. Aguardando sua aprovação.`,
          type: 'transfer',
          related_id: transfer.id,
          related_type: 'transfer',
        });

        // Get origin manager email and send email notification
        const originManager = users.find(u => u.id === originDept.responsible_id);
        if (originManager?.email) {
          try {
            await supabase.functions.invoke('send-notification-email', {
              body: {
                to: originManager.email,
                subject: 'Nova Transferência Iniciada - Aguardando Aprovação',
                type: 'transfer_initiated',
                data: {
                  userName: originManager.name,
                  assetName: selectedAsset.name,
                  fromLocation: fromLocation?.name || 'N/A',
                  toLocation: toLocation?.name || 'N/A',
                },
              },
            });
          } catch (emailError) {
            console.error('Error sending email:', emailError);
          }
        }
      }

      toast({
        title: 'Transferência iniciada',
        description: 'O encarregado da unidade de origem foi notificado.',
      });

      setFormData({ assetId: '', toLocationId: '', toDepartmentId: '', notes: '' });
      onOpenChange(false);
      onSuccess?.();
    } catch (error: any) {
      console.error('Error creating transfer:', error);
      toast({
        title: 'Erro ao criar transferência',
        description: error.message || 'Ocorreu um erro ao iniciar a transferência',
        variant: 'destructive',
      });
    } finally {
      setLoading(false);
    }
  };

  // Filter managers (encarregados)
  const managers = users.filter(u => {
    // In a real app, you'd check if they have manager role
    return true;
  });

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-[500px] bg-card border-border">
        <DialogHeader>
          <DialogTitle className="text-foreground">Iniciar Nova Transferência de Bem</DialogTitle>
          <p className="text-sm text-muted-foreground">
            Selecione o bem e preencha os detalhes para iniciar uma nova solicitação de transferência.
          </p>
        </DialogHeader>
        
        <form onSubmit={handleSubmit}>
          <div className="space-y-4 py-4">
            <div className="space-y-2">
              <Label htmlFor="asset" className="text-foreground">Bem a ser Transferido *</Label>
              <Select
                value={formData.assetId}
                onValueChange={(value) => setFormData({ ...formData, assetId: value })}
                required
              >
                <SelectTrigger id="asset" className="bg-secondary border-border">
                  <SelectValue placeholder="Selecione um bem" />
                </SelectTrigger>
                <SelectContent>
                  {assets.map((asset) => (
                    <SelectItem key={asset.id} value={asset.id}>
                      {asset.inventory_number} - {asset.name}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <Label htmlFor="location" className="text-foreground">Nova Localização *</Label>
              <Select
                value={formData.toLocationId}
                onValueChange={(value) => setFormData({ ...formData, toLocationId: value })}
                required
              >
                <SelectTrigger id="location" className="bg-secondary border-border">
                  <SelectValue placeholder="Selecione a nova localização" />
                </SelectTrigger>
                <SelectContent>
                  {locations.map((location) => (
                    <SelectItem key={location.id} value={location.id}>
                      {location.name}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <Label htmlFor="department" className="text-foreground">Nova Subunidade *</Label>
              <Select
                value={formData.toDepartmentId}
                onValueChange={(value) => setFormData({ ...formData, toDepartmentId: value })}
                required
              >
                <SelectTrigger id="department" className="bg-secondary border-border">
                  <SelectValue placeholder="Selecione a nova subunidade" />
                </SelectTrigger>
                <SelectContent>
                  {departments.map((dept) => (
                    <SelectItem key={dept.id} value={dept.id}>
                      {dept.name}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <Label htmlFor="notes" className="text-foreground">Observações</Label>
              <Textarea
                id="notes"
                value={formData.notes}
                onChange={(e) => setFormData({ ...formData, notes: e.target.value })}
                placeholder="Observações sobre a transferência..."
                className="bg-secondary border-border"
              />
            </div>
          </div>

          <div className="flex justify-end gap-3">
            <Button type="button" variant="outline" onClick={() => onOpenChange(false)}>
              Cancelar
            </Button>
            <Button 
              type="submit" 
              className="bg-info hover:bg-info/90 text-info-foreground"
              disabled={loading || !formData.assetId || !formData.toLocationId || !formData.toDepartmentId}
            >
              {loading && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
              Iniciar Solicitação
            </Button>
          </div>
        </form>
      </DialogContent>
    </Dialog>
  );
}
