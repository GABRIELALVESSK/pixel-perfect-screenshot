import { useState, useEffect } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Checkbox } from "@/components/ui/checkbox";
import { useData, Asset } from "@/contexts/DataContext";
import { toast } from "sonner";

interface EditAssetDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  asset: Asset | null;
}

export function EditAssetDialog({ open, onOpenChange, asset }: EditAssetDialogProps) {
  const { updateAsset, locations, departments, categories, users } = useData();
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [formData, setFormData] = useState({
    name: "",
    category_id: "",
    description: "",
    inventory_number: "",
    location_id: "",
    department_id: "",
    responsible_id: "",
    status: "Ativo",
    value: "",
    acquisition_date: "",
    start_use_date: "",
    notes: "",
    custom_depreciation: false,
  });

  useEffect(() => {
    if (asset) {
      setFormData({
        name: asset.name || "",
        category_id: asset.category_id || "",
        description: asset.description || "",
        inventory_number: asset.inventory_number || "",
        location_id: asset.location_id || "",
        department_id: asset.department_id || "",
        responsible_id: asset.responsible_id || "",
        status: asset.status || "Ativo",
        value: asset.value?.toString() || "",
        acquisition_date: asset.acquisition_date || "",
        start_use_date: asset.start_use_date || "",
        notes: asset.notes || "",
        custom_depreciation: asset.custom_depreciation || false,
      });
    }
  }, [asset]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!asset) return;

    setIsSubmitting(true);
    try {
      await updateAsset(asset.id, {
        name: formData.name,
        category_id: formData.category_id || null,
        description: formData.description || null,
        inventory_number: formData.inventory_number,
        location_id: formData.location_id || null,
        department_id: formData.department_id || null,
        responsible_id: formData.responsible_id || null,
        status: formData.status,
        value: parseFloat(formData.value) || 0,
        acquisition_date: formData.acquisition_date,
        start_use_date: formData.start_use_date || null,
        notes: formData.notes || null,
        custom_depreciation: formData.custom_depreciation,
      });

      toast.success("Ativo atualizado com sucesso!");
      onOpenChange(false);
    } catch (error) {
      toast.error("Erro ao atualizar ativo");
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>Editar Ativo</DialogTitle>
          <p className="text-sm text-muted-foreground">
            Atualize as informações do ativo selecionado.
          </p>
        </DialogHeader>

        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="edit-name">Nome do Ativo</Label>
              <Input
                id="edit-name"
                placeholder="Ex: Laptop Dell XPS 15"
                value={formData.name}
                onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                required
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="edit-category">Categoria</Label>
              <Select
                value={formData.category_id}
                onValueChange={(value) => setFormData({ ...formData, category_id: value })}
              >
                <SelectTrigger>
                  <SelectValue placeholder="Selecione uma categoria" />
                </SelectTrigger>
                <SelectContent>
                  {categories.map((category) => (
                    <SelectItem key={category.id} value={category.id}>
                      {category.name}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          </div>

          <div className="space-y-2">
            <Label htmlFor="edit-description">Descrição (Opcional)</Label>
            <Textarea
              id="edit-description"
              placeholder="Detalhes sobre o ativo..."
              value={formData.description}
              onChange={(e) => setFormData({ ...formData, description: e.target.value })}
              rows={3}
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="edit-inventory_number">Número de Inventário</Label>
            <Input
              id="edit-inventory_number"
              placeholder="Ex: SEFAZ-00123, PAT-456"
              value={formData.inventory_number}
              onChange={(e) => setFormData({ ...formData, inventory_number: e.target.value })}
              required
            />
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="edit-location">Localização</Label>
              <Select
                value={formData.location_id}
                onValueChange={(value) => setFormData({ ...formData, location_id: value })}
              >
                <SelectTrigger>
                  <SelectValue placeholder="Selecione uma localização" />
                </SelectTrigger>
                <SelectContent>
                  {locations.map((location) => (
                    <SelectItem key={location.id} value={location.id}>
                      {location.name}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <Label htmlFor="edit-department">Departamento</Label>
              <Select
                value={formData.department_id}
                onValueChange={(value) => setFormData({ ...formData, department_id: value })}
              >
                <SelectTrigger>
                  <SelectValue placeholder="Selecione um departamento" />
                </SelectTrigger>
                <SelectContent>
                  {departments.map((department) => (
                    <SelectItem key={department.id} value={department.id}>
                      {department.name}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          </div>

          <div className="space-y-2">
            <Label htmlFor="edit-responsible">Atribuído Para (Encarregado)</Label>
            <Select
              value={formData.responsible_id}
              onValueChange={(value) => setFormData({ ...formData, responsible_id: value })}
            >
              <SelectTrigger>
                <SelectValue placeholder="Selecione um responsável" />
              </SelectTrigger>
              <SelectContent>
                {users.map((user) => (
                  <SelectItem key={user.id} value={user.id}>
                    {user.name}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="edit-status">Status</Label>
              <Select
                value={formData.status}
                onValueChange={(value) => setFormData({ ...formData, status: value })}
              >
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="Ativo">Ativo</SelectItem>
                  <SelectItem value="Inativo">Inativo</SelectItem>
                  <SelectItem value="Manutenção">Manutenção</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <Label htmlFor="edit-value">Valor (R$)</Label>
              <Input
                id="edit-value"
                type="number"
                step="0.01"
                placeholder="0"
                value={formData.value}
                onChange={(e) => setFormData({ ...formData, value: e.target.value })}
                required
              />
              <p className="text-xs text-muted-foreground">Use ponto como separador decimal</p>
            </div>
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="edit-acquisition_date">Data de Aquisição</Label>
              <Input
                id="edit-acquisition_date"
                type="date"
                value={formData.acquisition_date}
                onChange={(e) => setFormData({ ...formData, acquisition_date: e.target.value })}
                required
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="edit-start_use_date">Data de Início de Uso (Opcional)</Label>
              <Input
                id="edit-start_use_date"
                type="date"
                value={formData.start_use_date}
                onChange={(e) => setFormData({ ...formData, start_use_date: e.target.value })}
              />
            </div>
          </div>

          <div className="space-y-2">
            <Label htmlFor="edit-notes">Notas Adicionais (Opcional)</Label>
            <Textarea
              id="edit-notes"
              placeholder="Observações, histórico de manutenção, etc."
              value={formData.notes}
              onChange={(e) => setFormData({ ...formData, notes: e.target.value })}
              rows={3}
            />
          </div>

          <div className="flex items-start space-x-3 rounded-lg border border-border p-4">
            <Checkbox
              id="edit-custom_depreciation"
              checked={formData.custom_depreciation}
              onCheckedChange={(checked) =>
                setFormData({ ...formData, custom_depreciation: checked as boolean })
              }
            />
            <div className="space-y-1 leading-none">
              <Label
                htmlFor="edit-custom_depreciation"
                className="text-sm font-medium cursor-pointer"
              >
                Regras de Depreciação Personalizadas
              </Label>
              <p className="text-sm text-muted-foreground">
                Ativar para definir regras de depreciação específicas para este ativo.
              </p>
            </div>
          </div>

          <div className="flex justify-end gap-2 pt-4">
            <Button type="button" variant="outline" onClick={() => onOpenChange(false)} disabled={isSubmitting}>
              Cancelar
            </Button>
            <Button type="submit" disabled={isSubmitting}>
              {isSubmitting ? "Salvando..." : "Salvar Alterações"}
            </Button>
          </div>
        </form>
      </DialogContent>
    </Dialog>
  );
}
