import { useState } from 'react';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { useToast } from '@/hooks/use-toast';
import { supabase } from '@/integrations/supabase/client';
import { Loader2 } from 'lucide-react';

interface InviteUserDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  onSuccess?: () => void;
}

export function InviteUserDialog({ open, onOpenChange, onSuccess }: InviteUserDialogProps) {
  const { toast } = useToast();
  const [loading, setLoading] = useState(false);
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    idFuncional: '',
    role: 'user' as 'admin' | 'manager' | 'user',
  });

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);

    try {
      // Create the user with Supabase Auth
      const redirectUrl = `${window.location.origin}/auth`;
      
      const { data: authData, error: authError } = await supabase.auth.signUp({
        email: formData.email,
        password: crypto.randomUUID(), // Temporary password - user will reset
        options: {
          emailRedirectTo: redirectUrl,
          data: {
            name: formData.name,
            id_funcional: formData.idFuncional,
          },
        },
      });

      if (authError) throw authError;

      if (authData.user) {
        // Update the role
        const { error: roleError } = await supabase
          .from('user_roles')
          .update({ role: formData.role })
          .eq('user_id', authData.user.id);

        if (roleError) {
          console.error('Error updating role:', roleError);
        }

        // Send password reset email so user can set their own password
        await supabase.auth.resetPasswordForEmail(formData.email, {
          redirectTo: redirectUrl,
        });

        // Send notification email via edge function
        try {
          await supabase.functions.invoke('send-notification-email', {
            body: {
              to: formData.email,
              subject: 'Convite para o Sistema de Gestão de Bens',
              type: 'user_invitation',
              data: {
                userName: formData.name,
                inviteLink: redirectUrl,
              },
            },
          });
        } catch (emailError) {
          console.error('Error sending invitation email:', emailError);
        }
      }

      toast({
        title: 'Convite enviado',
        description: `Um email de convite foi enviado para ${formData.email}`,
      });

      setFormData({ name: '', email: '', idFuncional: '', role: 'user' });
      onOpenChange(false);
      onSuccess?.();
    } catch (error: any) {
      console.error('Error inviting user:', error);
      toast({
        title: 'Erro ao convidar usuário',
        description: error.message || 'Ocorreu um erro ao enviar o convite',
        variant: 'destructive',
      });
    } finally {
      setLoading(false);
    }
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-[425px]">
        <DialogHeader>
          <DialogTitle>Convidar Novo Usuário</DialogTitle>
          <DialogDescription>
            Preencha os dados do usuário. Um email de convite será enviado.
          </DialogDescription>
        </DialogHeader>
        <form onSubmit={handleSubmit}>
          <div className="grid gap-4 py-4">
            <div className="grid gap-2">
              <Label htmlFor="name">Nome *</Label>
              <Input
                id="name"
                value={formData.name}
                onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                placeholder="Nome completo"
                required
              />
            </div>
            <div className="grid gap-2">
              <Label htmlFor="idFuncional">ID Funcional *</Label>
              <Input
                id="idFuncional"
                value={formData.idFuncional}
                onChange={(e) => setFormData({ ...formData, idFuncional: e.target.value })}
                placeholder="ID funcional do servidor"
                required
              />
            </div>
            <div className="grid gap-2">
              <Label htmlFor="email">E-mail *</Label>
              <Input
                id="email"
                type="email"
                value={formData.email}
                onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                placeholder="email@exemplo.com"
                required
              />
            </div>
            <div className="grid gap-2">
              <Label htmlFor="role">Função *</Label>
              <Select
                value={formData.role}
                onValueChange={(value: 'admin' | 'manager' | 'user') =>
                  setFormData({ ...formData, role: value })
                }
              >
                <SelectTrigger>
                  <SelectValue placeholder="Selecione a função" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="admin">Administrador</SelectItem>
                  <SelectItem value="manager">Encarregado</SelectItem>
                  <SelectItem value="user">Usuário</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>
          <DialogFooter>
            <Button type="button" variant="outline" onClick={() => onOpenChange(false)}>
              Cancelar
            </Button>
            <Button type="submit" disabled={loading}>
              {loading && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
              Enviar Convite
            </Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  );
}
