import { useState } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Switch } from "@/components/ui/switch";
import { useData } from "@/contexts/DataContext";
import { useToast } from "@/hooks/use-toast";

interface AddLocationDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
}

export function AddLocationDialog({ open, onOpenChange }: AddLocationDialogProps) {
  const { addLocation } = useData();
  const { toast } = useToast();
  const [formData, setFormData] = useState({
    name: "",
    address: "",
    type: "",
    floors: 1,
    status: true,
  });

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    try {
      const locationData = {
        ...formData,
        parent: undefined,
      };
      await addLocation(locationData);
      
      toast({
        title: "Localização cadastrada",
        description: "A localização foi cadastrada com sucesso.",
      });
      
      onOpenChange(false);
      setFormData({
        name: "",
        address: "",
        type: "",
        floors: 1,
        status: true,
      });
    } catch (error) {
      toast({
        title: "Erro ao cadastrar",
        description: "Não foi possível cadastrar a localização.",
        variant: "destructive",
      });
    }
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-[500px] bg-card border-border">
        <DialogHeader>
          <DialogTitle className="text-foreground">Nova Localização</DialogTitle>
          <p className="text-sm text-muted-foreground">
            Cadastre um novo prédio, unidade ou área física.
          </p>
        </DialogHeader>
        
        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="space-y-2">
            <Label htmlFor="name" className="text-foreground">Nome da Localização</Label>
            <Input
              id="name"
              placeholder="Ex: Edifício Sede, Bloco Administrativo"
              value={formData.name}
              onChange={(e) => setFormData({ ...formData, name: e.target.value })}
              required
              className="bg-secondary border-border"
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="address" className="text-foreground">Endereço Completo</Label>
            <Input
              id="address"
              placeholder="Ex: Rua da Assembleia, 10, Centro, Rio de Janeiro - RJ"
              value={formData.address}
              onChange={(e) => setFormData({ ...formData, address: e.target.value })}
              className="bg-secondary border-border"
            />
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="type" className="text-foreground">Tipo de Localização</Label>
              <Select
                value={formData.type}
                onValueChange={(value) => setFormData({ ...formData, type: value })}
                required
              >
                <SelectTrigger className="bg-secondary border-border">
                  <SelectValue placeholder="Selecione o tipo" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="Prédio">Prédio</SelectItem>
                  <SelectItem value="Unidade">Unidade</SelectItem>
                  <SelectItem value="Setor">Setor</SelectItem>
                  <SelectItem value="Sala">Sala</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <Label htmlFor="floors" className="text-foreground">Nº de Andares</Label>
              <Input
                id="floors"
                type="number"
                min="1"
                value={formData.floors}
                onChange={(e) => setFormData({ ...formData, floors: parseInt(e.target.value) || 1 })}
                className="bg-secondary border-border"
              />
            </div>
          </div>

          <div className="space-y-2">
            <div className="flex items-center justify-between">
              <div>
                <Label htmlFor="status" className="text-foreground">Status</Label>
                <p className="text-sm text-muted-foreground">
                  Define se a localização está ativa ou inativa.
                </p>
              </div>
              <Switch
                id="status"
                checked={formData.status}
                onCheckedChange={(checked) => setFormData({ ...formData, status: checked })}
              />
            </div>
          </div>

          <div className="flex gap-3 justify-end pt-4">
            <Button
              type="button"
              variant="outline"
              onClick={() => onOpenChange(false)}
            >
              Cancelar
            </Button>
            <Button type="submit" className="bg-primary text-primary-foreground hover:bg-primary/90">
              Cadastrar Localização
            </Button>
          </div>
        </form>
      </DialogContent>
    </Dialog>
  );
}
