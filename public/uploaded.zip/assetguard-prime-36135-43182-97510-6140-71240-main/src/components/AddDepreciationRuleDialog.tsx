import { useState } from "react";
import { Button } from "@/components/ui/button";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Switch } from "@/components/ui/switch";
import { toast } from "sonner";

interface AddDepreciationRuleDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
}

export function AddDepreciationRuleDialog({ open, onOpenChange }: AddDepreciationRuleDialogProps) {
  const [category, setCategory] = useState("");
  const [rate, setRate] = useState("");
  const [method, setMethod] = useState("Linear");
  const [usefulLife, setUsefulLife] = useState("");
  const [residualValue, setResidualValue] = useState("");
  const [notificationDays, setNotificationDays] = useState("30");
  const [automaticWriteOff, setAutomaticWriteOff] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    try {
      // Aqui você pode adicionar a lógica para salvar a regra no banco
      toast.success("Regra de depreciação criada com sucesso!");
      onOpenChange(false);
      
      // Reset form
      setCategory("");
      setRate("");
      setMethod("Linear");
      setUsefulLife("");
      setResidualValue("");
      setNotificationDays("30");
      setAutomaticWriteOff(false);
    } catch (error) {
      toast.error("Erro ao criar regra de depreciação");
      console.error(error);
    }
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-[500px]">
        <DialogHeader>
          <DialogTitle>Nova Regra de Depreciação</DialogTitle>
          <DialogDescription>
            Crie uma nova regra de depreciação para uma categoria de bens.
          </DialogDescription>
        </DialogHeader>
        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="space-y-2">
            <Label htmlFor="category">Categoria do Setor *</Label>
            <Select value={category} onValueChange={setCategory} required>
              <SelectTrigger>
                <SelectValue placeholder="Selecione uma categoria" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="ti">Equipamentos de TI</SelectItem>
                <SelectItem value="mobiliario">Mobiliário</SelectItem>
                <SelectItem value="veiculos">Veículos</SelectItem>
                <SelectItem value="outros">Outros</SelectItem>
              </SelectContent>
            </Select>
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="rate">Taxa (%) *</Label>
              <Input
                id="rate"
                type="number"
                placeholder="20"
                value={rate}
                onChange={(e) => setRate(e.target.value)}
                required
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="method">Método *</Label>
              <Select value={method} onValueChange={setMethod}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="Linear">Linear</SelectItem>
                  <SelectItem value="Saldo Decrescente">Saldo Decrescente</SelectItem>
                  <SelectItem value="Unidades Produzidas">Unidades Produzidas</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="usefulLife">Vida Útil (anos) *</Label>
              <Input
                id="usefulLife"
                type="number"
                placeholder="5"
                value={usefulLife}
                onChange={(e) => setUsefulLife(e.target.value)}
                required
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="residualValue">Valor Residual (%) *</Label>
              <Input
                id="residualValue"
                type="number"
                placeholder="10"
                value={residualValue}
                onChange={(e) => setResidualValue(e.target.value)}
                required
              />
            </div>
          </div>

          <div className="space-y-2">
            <Label htmlFor="notificationDays">Notificação Antecipada</Label>
            <Input
              id="notificationDays"
              type="number"
              placeholder="30"
              value={notificationDays}
              onChange={(e) => setNotificationDays(e.target.value)}
            />
            <p className="text-xs text-muted-foreground">
              Ex: Número de dias antes da depreciação total para notificar.
            </p>
          </div>

          <div className="flex items-center justify-between rounded-lg border border-border p-4">
            <div className="space-y-0.5">
              <Label htmlFor="automaticWriteOff">Baixa Automática</Label>
              <p className="text-xs text-muted-foreground">
                Ativar baixa automática quando atingir depreciação total
              </p>
            </div>
            <Switch
              id="automaticWriteOff"
              checked={automaticWriteOff}
              onCheckedChange={setAutomaticWriteOff}
            />
          </div>

          <div className="flex justify-end gap-2 pt-4">
            <Button type="button" variant="outline" onClick={() => onOpenChange(false)}>
              Cancelar
            </Button>
            <Button type="submit">Criar Regra</Button>
          </div>
        </form>
      </DialogContent>
    </Dialog>
  );
}
