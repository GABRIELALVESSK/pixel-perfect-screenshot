import { useState } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Checkbox } from "@/components/ui/checkbox";
import { useData } from "@/contexts/DataContext";
import { useToast } from "@/hooks/use-toast";

interface AddAssetDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
}

export function AddAssetDialog({ open, onOpenChange }: AddAssetDialogProps) {
  const { addAsset, locations, departments, categories, users } = useData();
  const { toast } = useToast();
  const [formData, setFormData] = useState({
    name: "",
    category_id: "",
    description: "",
    inventory_number: "",
    location_id: "",
    department_id: "",
    responsible_id: "",
    status: "Ativo",
    value: "",
    acquisition_date: "",
    start_use_date: "",
    notes: "",
    custom_depreciation: false,
  });

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    await addAsset({
      name: formData.name,
      category_id: formData.category_id || undefined,
      description: formData.description || undefined,
      inventory_number: formData.inventory_number,
      location_id: formData.location_id || undefined,
      department_id: formData.department_id || undefined,
      responsible_id: formData.responsible_id || undefined,
      status: formData.status,
      value: parseFloat(formData.value) || 0,
      acquisition_date: formData.acquisition_date,
      start_use_date: formData.start_use_date || undefined,
      notes: formData.notes || undefined,
      custom_depreciation: formData.custom_depreciation,
      created_at: new Date().toISOString(),
      updated_at: new Date().toISOString(),
    });

    toast({
      title: "Ativo adicionado com sucesso!",
    });

    onOpenChange(false);
    setFormData({
      name: "",
      category_id: "",
      description: "",
      inventory_number: "",
      location_id: "",
      department_id: "",
      responsible_id: "",
      status: "Ativo",
      value: "",
      acquisition_date: "",
      start_use_date: "",
      notes: "",
      custom_depreciation: false,
    });
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>Adicionar Novo Ativo</DialogTitle>
          <p className="text-sm text-muted-foreground">
            Preencha as informações abaixo para registrar um novo ativo.
          </p>
        </DialogHeader>

        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="name">Nome do Ativo</Label>
              <Input
                id="name"
                placeholder="Ex: Laptop Dell XPS 15"
                value={formData.name}
                onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                required
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="category">Categoria</Label>
              <Select
                value={formData.category_id}
                onValueChange={(value) => setFormData({ ...formData, category_id: value })}
              >
                <SelectTrigger>
                  <SelectValue placeholder="Selecione uma categoria" />
                </SelectTrigger>
                <SelectContent>
                  {categories.map((category) => (
                    <SelectItem key={category.id} value={category.id}>
                      {category.name}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          </div>

          <div className="space-y-2">
            <Label htmlFor="description">Descrição (Opcional)</Label>
            <Textarea
              id="description"
              placeholder="Detalhes sobre o ativo..."
              value={formData.description}
              onChange={(e) => setFormData({ ...formData, description: e.target.value })}
              rows={3}
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="inventory_number">Número de Inventário</Label>
            <Input
              id="inventory_number"
              placeholder="Ex: SEFAZ-00123, PAT-456"
              value={formData.inventory_number}
              onChange={(e) => setFormData({ ...formData, inventory_number: e.target.value })}
              required
            />
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="location">Localização</Label>
              <Select
                value={formData.location_id}
                onValueChange={(value) => setFormData({ ...formData, location_id: value })}
              >
                <SelectTrigger>
                  <SelectValue placeholder="Selecione uma localização" />
                </SelectTrigger>
                <SelectContent>
                  {locations.map((location) => (
                    <SelectItem key={location.id} value={location.id}>
                      {location.name}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <Label htmlFor="department">Departamento</Label>
              <Select
                value={formData.department_id}
                onValueChange={(value) => setFormData({ ...formData, department_id: value })}
              >
                <SelectTrigger>
                  <SelectValue placeholder="Selecione um departamento" />
                </SelectTrigger>
                <SelectContent>
                  {departments.map((department) => (
                    <SelectItem key={department.id} value={department.id}>
                      {department.name}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          </div>

          <div className="space-y-2">
            <Label htmlFor="responsible">Atribuído Para (Encarregado)</Label>
            <Select
              value={formData.responsible_id}
              onValueChange={(value) => setFormData({ ...formData, responsible_id: value })}
            >
              <SelectTrigger>
                <SelectValue placeholder="Selecione um responsável" />
              </SelectTrigger>
              <SelectContent>
                {users.map((user) => (
                  <SelectItem key={user.id} value={user.id}>
                    {user.name}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="status">Status</Label>
              <Select
                value={formData.status}
                onValueChange={(value) => setFormData({ ...formData, status: value })}
              >
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="Ativo">Ativo</SelectItem>
                  <SelectItem value="Inativo">Inativo</SelectItem>
                  <SelectItem value="Manutenção">Manutenção</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <Label htmlFor="value">Valor (R$)</Label>
              <Input
                id="value"
                type="number"
                step="0.01"
                placeholder="0"
                value={formData.value}
                onChange={(e) => setFormData({ ...formData, value: e.target.value })}
                required
              />
              <p className="text-xs text-muted-foreground">Use ponto como separador decimal</p>
            </div>
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="acquisition_date">Data de Aquisição</Label>
              <Input
                id="acquisition_date"
                type="date"
                value={formData.acquisition_date}
                onChange={(e) => setFormData({ ...formData, acquisition_date: e.target.value })}
                required
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="start_use_date">Data de Início de Uso (Opcional)</Label>
              <Input
                id="start_use_date"
                type="date"
                placeholder="Escolha uma data (se aplicável)"
                value={formData.start_use_date}
                onChange={(e) => setFormData({ ...formData, start_use_date: e.target.value })}
              />
            </div>
          </div>

          <div className="space-y-2">
            <Label htmlFor="notes">Notas Adicionais (Opcional)</Label>
            <Textarea
              id="notes"
              placeholder="Observações, histórico de manutenção, etc."
              value={formData.notes}
              onChange={(e) => setFormData({ ...formData, notes: e.target.value })}
              rows={3}
            />
          </div>

          <div className="flex items-start space-x-3 rounded-lg border border-border p-4">
            <Checkbox
              id="custom_depreciation"
              checked={formData.custom_depreciation}
              onCheckedChange={(checked) =>
                setFormData({ ...formData, custom_depreciation: checked as boolean })
              }
            />
            <div className="space-y-1 leading-none">
              <Label
                htmlFor="custom_depreciation"
                className="text-sm font-medium cursor-pointer"
              >
                Regras de Depreciação Personalizadas
              </Label>
              <p className="text-sm text-muted-foreground">
                Ativar para definir regras de depreciação específicas para este ativo.
              </p>
            </div>
          </div>

          <div className="flex justify-end gap-2 pt-4">
            <Button type="button" variant="outline" onClick={() => onOpenChange(false)}>
              Cancelar
            </Button>
            <Button type="submit">Adicionar Ativo</Button>
          </div>
        </form>
      </DialogContent>
    </Dialog>
  );
}
