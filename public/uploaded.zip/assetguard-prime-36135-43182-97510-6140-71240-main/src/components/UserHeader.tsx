import { useEffect, useState } from "react";
import { LogOut, KeyRound } from "lucide-react";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { Button } from "@/components/ui/button";
import { useNavigate } from "react-router-dom";
import { toast } from "sonner";
import { useAuth } from "@/hooks/useAuth";
import { supabase } from "@/integrations/supabase/client";
import { NotificationsDropdown } from "@/components/NotificationsDropdown";
import { ChangePasswordDialog } from "@/components/ChangePasswordDialog";

export function UserHeader() {
  const navigate = useNavigate();
  const { user } = useAuth();
  const [userName, setUserName] = useState<string>("");
  const [userRole, setUserRole] = useState<string>("Usuário");
  const [changePasswordOpen, setChangePasswordOpen] = useState(false);

  useEffect(() => {
    if (user) {
      // Fetch user profile and role
      const fetchUserData = async () => {
        const { data: profile } = await supabase
          .from('profiles')
          .select('name')
          .eq('id', user.id)
          .single();

        if (profile) {
          setUserName(profile.name);
        }

        const { data: roleData } = await supabase
          .from('user_roles')
          .select('role')
          .eq('user_id', user.id)
          .single();

        if (roleData) {
          const roleMap: { [key: string]: string } = {
            'admin': 'Administrador',
            'manager': 'Encarregado',
            'user': 'Usuário'
          };
          setUserRole(roleMap[roleData.role] || 'Usuário');
        }
      };

      fetchUserData();
    }
  }, [user]);

  const getInitials = (name: string) => {
    return name
      .split(" ")
      .map((n) => n[0])
      .join("")
      .toUpperCase()
      .slice(0, 2);
  };

  const handleLogout = async () => {
    const { error } = await supabase.auth.signOut();
    if (error) {
      toast.error("Erro ao sair do sistema");
    } else {
      toast.success("Saiu do sistema com sucesso");
      navigate("/auth");
    }
  };

  return (
    <div className="flex items-center justify-end gap-3 px-6 py-4 border-b border-border bg-background">
      <NotificationsDropdown />
      <DropdownMenu>
        <DropdownMenuTrigger asChild>
          <Button variant="ghost" className="flex items-center gap-3 h-auto py-2">
            <div className="flex flex-col items-end">
              <span className="text-sm font-medium text-foreground">{userName}</span>
              <span className="text-xs text-muted-foreground">{userRole}</span>
            </div>
            <Avatar className="h-9 w-9 bg-secondary">
              <AvatarFallback className="bg-secondary text-foreground">
                {getInitials(userName)}
              </AvatarFallback>
            </Avatar>
          </Button>
        </DropdownMenuTrigger>
        <DropdownMenuContent align="end" className="w-56">
          <DropdownMenuLabel>Minha Conta</DropdownMenuLabel>
          <DropdownMenuSeparator />
          <DropdownMenuItem onClick={() => setChangePasswordOpen(true)} className="cursor-pointer">
            <KeyRound className="mr-2 h-4 w-4" />
            <span>Alterar Senha</span>
          </DropdownMenuItem>
          <DropdownMenuSeparator />
          <DropdownMenuItem onClick={handleLogout} className="cursor-pointer text-destructive focus:text-destructive">
            <LogOut className="mr-2 h-4 w-4" />
            <span>Sair do sistema</span>
          </DropdownMenuItem>
        </DropdownMenuContent>
      </DropdownMenu>

      <ChangePasswordDialog
        open={changePasswordOpen}
        onOpenChange={setChangePasswordOpen}
      />
    </div>
  );
}
