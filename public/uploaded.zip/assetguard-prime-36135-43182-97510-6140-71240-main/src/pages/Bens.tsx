import { useState, useRef, useMemo } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Upload, Download, Plus, Search, Edit, Trash2 } from "lucide-react";
import { AddAssetDialog } from "@/components/AddAssetDialog";
import { EditAssetDialog } from "@/components/EditAssetDialog";
import { ColumnsDropdown } from "@/components/ColumnsDropdown";
import { useData, Asset } from "@/contexts/DataContext";
import { exportToExcel, importFromExcel } from "@/lib/excelUtils";
import { toast } from "sonner";
import { useUserRole } from "@/hooks/useUserRole";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";

export default function Bens() {
  const [isAddDialogOpen, setIsAddDialogOpen] = useState(false);
  const [isEditDialogOpen, setIsEditDialogOpen] = useState(false);
  const [selectedAsset, setSelectedAsset] = useState<Asset | null>(null);
  const [showDeleteDialog, setShowDeleteDialog] = useState(false);
  const [selectedAssetId, setSelectedAssetId] = useState<string | null>(null);
  const [isDeleting, setIsDeleting] = useState(false);
  const { assets, addAsset, deleteAsset } = useData();
  const { isAdmin, isManager, userDepartmentId } = useUserRole();
  const fileInputRef = useRef<HTMLInputElement>(null);

  // Filtrar assets por departamento se for manager
  const filteredAssets = useMemo(() => {
    if (isAdmin) {
      return assets;
    }
    if (isManager && userDepartmentId) {
      return assets.filter(asset => asset.department_id === userDepartmentId);
    }
    return [];
  }, [assets, isAdmin, isManager, userDepartmentId]);
  
  const [columns, setColumns] = useState([
    { id: "name", label: "Nome", visible: true },
    { id: "inventoryNumber", label: "InventoryNumber", visible: true },
    { id: "category", label: "Categoria", visible: true },
    { id: "status", label: "Status", visible: true },
    { id: "location", label: "Localização", visible: true },
    { id: "department", label: "Departamento", visible: true },
    { id: "value", label: "Valor (R$)", visible: true },
    { id: "acquisitionDate", label: "Data De Aquisição", visible: true },
    { id: "startUseDate", label: "StartUseDate", visible: true },
    { id: "actions", label: "Ações", visible: true },
  ]);

  const handleColumnToggle = (columnId: string) => {
    setColumns(columns.map(col => 
      col.id === columnId ? { ...col, visible: !col.visible } : col
    ));
  };

  const handleExport = () => {
    const exportData = filteredAssets.map(asset => ({
      'Nome': asset.name,
      'Nº Inventário': asset.inventory_number,
      'Categoria': asset.asset_categories?.name || '-',
      'Status': asset.status,
      'Localização': asset.locations?.name || '-',
      'Departamento': asset.departments?.name || '-',
      'Valor (R$)': asset.value,
      'Data de Aquisição': new Date(asset.acquisition_date).toLocaleDateString('pt-BR'),
      'Data de Início': asset.start_use_date ? new Date(asset.start_use_date).toLocaleDateString('pt-BR') : '-',
    }));
    exportToExcel(exportData, 'ativos');
    toast.success('Ativos exportados com sucesso!');
  };

  const handleImport = async (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (!file) return;

    try {
      // Import as array of arrays (raw data without headers)
      const data = await importFromExcel(file) as any[][];
      
      console.log('Dados importados:', data);
      
      // Buscar categorias, localizações e departamentos do contexto
      const { categories, locations, departments } = await import('@/contexts/DataContext').then(m => {
        // Como estamos dentro do provider, usar os dados diretamente
        return { categories: [], locations: [], departments: [] };
      });
      
      let importCount = 0;
      let skippedHeader = false;
      
      for (const row of data) {
        // Skip empty rows
        if (!row || row.length === 0 || !row[0]) continue;
        
        // Pular linha de cabeçalho (detectar se é cabeçalho)
        const firstCell = String(row[0] || '').trim().toLowerCase();
        if (!skippedHeader && (firstCell === 'nome' || firstCell.includes('nome'))) {
          skippedHeader = true;
          console.log('Pulando cabeçalho:', row);
          continue;
        }
        
        // Mapear colunas por índice:
        // A (0): Nome
        // B (1): Nº Inventário
        // C (2): Categoria
        // D (3): Status
        // E (4): Localização
        // F (5): Departamento/Subunidade
        // G (6): Valor
        // H (7): Data de Início
        
        console.log('Processando linha:', row);
        
        const name = String(row[0] || '').trim();
        const inventoryNumber = String(row[1] || '').trim();
        const categoryName = String(row[2] || '').trim();
        const statusRaw = String(row[3] || 'Ativo').trim().toUpperCase();
        const locationName = String(row[4] || '').trim();
        const departmentName = String(row[5] || '').trim();
        
        // Normalizar status
        let status = 'Ativo';
        if (statusRaw === 'ATIVO' || statusRaw === 'ACTIVE') status = 'Ativo';
        else if (statusRaw === 'INATIVO' || statusRaw === 'INACTIVE') status = 'Inativo';
        else if (statusRaw === 'MANUTENÇÃO' || statusRaw === 'MAINTENANCE') status = 'Manutenção';
        else status = 'Ativo';
        
        // Processar valor (remover R$ e converter para número)
        let value = 0;
        if (row[6] !== undefined && row[6] !== null) {
          let valueStr = String(row[6]);
          // Remove R$, espaços e trata formatação
          valueStr = valueStr.replace(/R\$\s*/gi, '').trim();
          
          // Detectar formato: se tem vírgula E ponto, o ponto é separador de milhar
          if (valueStr.includes(',') && valueStr.includes('.')) {
            // Formato BR: 1.234,56 -> remover pontos, trocar vírgula por ponto
            valueStr = valueStr.replace(/\./g, '').replace(',', '.');
          } else if (valueStr.includes(',')) {
            // Só vírgula: pode ser decimal BR (1234,56) ou milhar (1,234)
            // Se a parte após vírgula tem 2 dígitos, é decimal BR
            const parts = valueStr.split(',');
            if (parts[1] && parts[1].length <= 2) {
              valueStr = valueStr.replace(',', '.');
            } else {
              // Milhares americano
              valueStr = valueStr.replace(',', '');
            }
          }
          // Se só tem ponto, assumir formato americano (ponto = decimal)
          value = parseFloat(valueStr) || 0;
          console.log('Valor processado:', row[6], '->', value);
        }
        
        // Processar data (coluna H = Data de Início)
        let acquisitionDate = new Date().toISOString().split('T')[0];
        let startUseDate: string | null = null;
        
        if (row[7] !== undefined && row[7] !== null) {
          const rawDate = row[7];
          console.log('Data raw:', rawDate, typeof rawDate);
          
          let parsedDate: string | null = null;
          
          if (typeof rawDate === 'number') {
            // Excel date serial number
            const excelDate = new Date((rawDate - 25569) * 86400 * 1000);
            parsedDate = excelDate.toISOString().split('T')[0];
          } else {
            const dateStr = String(rawDate).trim();
            if (dateStr.includes('/')) {
              const parts = dateStr.split('/');
              if (parts.length === 3) {
                let day: string, month: string, year: string;
                const p0 = parseInt(parts[0]);
                const p1 = parseInt(parts[1]);
                
                // Se primeiro > 12, é formato dd/mm/yy (BR)
                // Se segundo > 12, é formato mm/dd/yy (US)
                if (p0 > 12) {
                  day = parts[0].padStart(2, '0');
                  month = parts[1].padStart(2, '0');
                } else if (p1 > 12) {
                  month = parts[0].padStart(2, '0');
                  day = parts[1].padStart(2, '0');
                } else {
                  // Ambos <= 12: assumir formato mm/dd/yy (Excel padrão US)
                  month = parts[0].padStart(2, '0');
                  day = parts[1].padStart(2, '0');
                }
                
                year = parts[2];
                if (year.length === 2) {
                  const yearNum = parseInt(year);
                  year = yearNum > 50 ? '19' + year : '20' + year;
                }
                
                parsedDate = `${year}-${month}-${day}`;
              }
            }
          }
          
          if (parsedDate) {
            acquisitionDate = parsedDate;
            startUseDate = parsedDate; // Data de início = data de aquisição para depreciação
          }
          console.log('Data processada:', rawDate, '->', parsedDate);
        }
        
        if (!name) continue;
        
        await addAsset({
          name: name,
          inventory_number: inventoryNumber || `INV-${Date.now()}-${importCount}`,
          status: status,
          value: value,
          acquisition_date: acquisitionDate,
          description: '',
          category_id: null, // Será vinculado automaticamente se existir
          location_id: null,
          department_id: null,
          responsible_id: null,
          start_use_date: startUseDate, // Importante para depreciação!
          custom_depreciation: false,
          notes: `Categoria: ${categoryName}, Localização: ${locationName}, Departamento: ${departmentName}`,
          created_at: new Date().toISOString(),
          updated_at: new Date().toISOString(),
        });
        importCount++;
      }
      
      if (importCount > 0) {
        toast.success(`${importCount} ativos importados com sucesso!`);
      } else {
        toast.warning('Nenhum ativo foi importado. Verifique o formato do arquivo.');
      }
    } catch (error) {
      console.error('Erro ao importar:', error);
      toast.error('Erro ao importar arquivo Excel. Verifique o formato do arquivo.');
    }
    if (fileInputRef.current) {
      fileInputRef.current.value = '';
    }
  };

  // Se for usuário comum (não admin nem manager), não mostrar nada
  if (!isAdmin && !isManager) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <div className="text-center space-y-4">
          <h1 className="text-2xl font-bold text-foreground">Acesso Restrito</h1>
          <p className="text-muted-foreground">Você não tem permissão para acessar esta página.</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background p-8">
      <div className="mx-auto max-w-7xl space-y-6">
        <div>
          <h1 className="text-3xl font-bold text-foreground">
            {isManager ? 'Bens Sob Minha Responsabilidade' : 'Gerenciamento de Ativos'}
          </h1>
          <p className="mt-2 text-muted-foreground">
            {isManager 
              ? 'Visualize os bens patrimoniais da sua subunidade.'
              : 'Visualize, adicione, edite e remova ativos do registro.'
            }
          </p>
        </div>

        <div className="flex items-center justify-between gap-4">
          <div className="relative flex-1 max-w-sm">
            <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
            <Input
              placeholder="Filtrar por nome..."
              className="pl-10 bg-secondary border-border"
            />
          </div>
          <div className="flex gap-2">
            {isAdmin && (
              <>
                <input
                  ref={fileInputRef}
                  type="file"
                  accept=".xlsx,.xls"
                  onChange={handleImport}
                  className="hidden"
                />
                <Button 
                  variant="outline" 
                  className="gap-2"
                  onClick={() => fileInputRef.current?.click()}
                >
                  <Upload className="h-4 w-4" />
                  Importar Excel
                </Button>
              </>
            )}
            <Button 
              variant="outline" 
              className="gap-2"
              onClick={handleExport}
            >
              <Download className="h-4 w-4" />
              Exportar Excel
            </Button>
            <ColumnsDropdown columns={columns} onColumnToggle={handleColumnToggle} />
            {isAdmin && (
              <Button 
                className="gap-2 bg-info hover:bg-info/90 text-info-foreground"
                onClick={() => setIsAddDialogOpen(true)}
              >
                <Plus className="h-4 w-4" />
                Adicionar Ativo
              </Button>
            )}
          </div>
        </div>

        <Card className="border-border bg-card">
          <CardContent className="p-0">
            <div className="overflow-x-auto">
              <table className="w-full">
                <thead className="border-b border-border">
                  <tr>
                    <th className="px-6 py-4 text-left">
                      <input type="checkbox" className="rounded border-border" />
                    </th>
                    {columns.find(c => c.id === "name")?.visible && (
                      <th className="px-6 py-4 text-left text-sm font-medium text-foreground">Nome ↑↓</th>
                    )}
                    {columns.find(c => c.id === "inventoryNumber")?.visible && (
                      <th className="px-6 py-4 text-left text-sm font-medium text-foreground">Nº Inventário</th>
                    )}
                    {columns.find(c => c.id === "category")?.visible && (
                      <th className="px-6 py-4 text-left text-sm font-medium text-foreground">Categoria</th>
                    )}
                    {columns.find(c => c.id === "status")?.visible && (
                      <th className="px-6 py-4 text-left text-sm font-medium text-foreground">Status</th>
                    )}
                    {columns.find(c => c.id === "location")?.visible && (
                      <th className="px-6 py-4 text-left text-sm font-medium text-foreground">Localização</th>
                    )}
                    {columns.find(c => c.id === "department")?.visible && (
                      <th className="px-6 py-4 text-left text-sm font-medium text-foreground">Departamento</th>
                    )}
                    {columns.find(c => c.id === "value")?.visible && (
                      <th className="px-6 py-4 text-left text-sm font-medium text-foreground">Valor (R$) ↑↓</th>
                    )}
                    {columns.find(c => c.id === "acquisitionDate")?.visible && (
                      <th className="px-6 py-4 text-left text-sm font-medium text-foreground">Data de Aquisição</th>
                    )}
                    {columns.find(c => c.id === "startUseDate")?.visible && (
                      <th className="px-6 py-4 text-left text-sm font-medium text-foreground">Data de Início</th>
                    )}
                    {isAdmin && columns.find(c => c.id === "actions")?.visible && (
                      <th className="px-6 py-4 text-left text-sm font-medium text-foreground">Ações</th>
                    )}
                  </tr>
                </thead>
                <tbody>
                  {filteredAssets.length === 0 ? (
                    <tr>
                      <td colSpan={10} className="px-6 py-12 text-center text-muted-foreground">
                        {isManager ? 'Nenhum ativo vinculado à sua subunidade.' : 'Nenhum ativo encontrado.'}
                      </td>
                    </tr>
                  ) : (
                    filteredAssets.map((asset) => (
                      <tr key={asset.id} className="border-b border-border hover:bg-muted/50">
                        <td className="px-6 py-4">
                          <input type="checkbox" className="rounded border-border" />
                        </td>
                        {columns.find(c => c.id === "name")?.visible && (
                          <td className="px-6 py-4 text-sm">{asset.name}</td>
                        )}
                        {columns.find(c => c.id === "inventoryNumber")?.visible && (
                          <td className="px-6 py-4 text-sm">{asset.inventory_number}</td>
                        )}
                        {columns.find(c => c.id === "category")?.visible && (
                          <td className="px-6 py-4 text-sm">{asset.asset_categories?.name || "-"}</td>
                        )}
                        {columns.find(c => c.id === "status")?.visible && (
                          <td className="px-6 py-4 text-sm">{asset.status}</td>
                        )}
                        {columns.find(c => c.id === "location")?.visible && (
                          <td className="px-6 py-4 text-sm">{asset.locations?.name || "-"}</td>
                        )}
                        {columns.find(c => c.id === "department")?.visible && (
                          <td className="px-6 py-4 text-sm">{asset.departments?.name || "-"}</td>
                        )}
                        {columns.find(c => c.id === "value")?.visible && (
                          <td className="px-6 py-4 text-sm">R$ {asset.value.toFixed(2)}</td>
                        )}
                        {columns.find(c => c.id === "acquisitionDate")?.visible && (
                          <td className="px-6 py-4 text-sm">{new Date(asset.acquisition_date).toLocaleDateString('pt-BR')}</td>
                        )}
                        {columns.find(c => c.id === "startUseDate")?.visible && (
                          <td className="px-6 py-4 text-sm">{asset.start_use_date ? new Date(asset.start_use_date).toLocaleDateString('pt-BR') : "-"}</td>
                        )}
                        {isAdmin && columns.find(c => c.id === "actions")?.visible && (
                          <td className="px-6 py-4">
                            <div className="flex gap-2">
                              <Button
                                variant="ghost"
                                size="icon"
                                className="h-8 w-8"
                                onClick={() => {
                                  setSelectedAsset(asset);
                                  setIsEditDialogOpen(true);
                                }}
                              >
                                <Edit className="h-4 w-4" />
                              </Button>
                              <Button
                                variant="ghost"
                                size="icon"
                                className="h-8 w-8 text-destructive hover:text-destructive"
                                onClick={() => {
                                  setSelectedAssetId(asset.id);
                                  setShowDeleteDialog(true);
                                }}
                              >
                                <Trash2 className="h-4 w-4" />
                              </Button>
                            </div>
                          </td>
                        )}
                      </tr>
                    ))
                  )}
                </tbody>
              </table>
            </div>
            <div className="flex items-center justify-between border-t border-border px-6 py-4">
              <p className="text-sm text-muted-foreground">0 de 0 linha(s) selecionadas.</p>
              <div className="flex gap-2">
                <Button variant="outline" size="sm">Anterior</Button>
                <Button variant="outline" size="sm">Próxima</Button>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      <AddAssetDialog open={isAddDialogOpen} onOpenChange={setIsAddDialogOpen} />
      <EditAssetDialog 
        open={isEditDialogOpen} 
        onOpenChange={setIsEditDialogOpen} 
        asset={selectedAsset} 
      />

      <AlertDialog open={showDeleteDialog} onOpenChange={setShowDeleteDialog}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Confirmar exclusão</AlertDialogTitle>
            <AlertDialogDescription>
              Tem certeza que deseja excluir este ativo? Esta ação não pode ser desfeita.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel disabled={isDeleting}>Cancelar</AlertDialogCancel>
            <AlertDialogAction
              disabled={isDeleting}
              className="bg-destructive text-destructive-foreground hover:bg-destructive/90"
              onClick={async () => {
                if (!selectedAssetId) return;
                setIsDeleting(true);
                try {
                  await deleteAsset(selectedAssetId);
                  toast.success('Ativo excluído com sucesso!');
                  setShowDeleteDialog(false);
                  setSelectedAssetId(null);
                } catch (error) {
                  toast.error('Erro ao excluir ativo');
                } finally {
                  setIsDeleting(false);
                }
              }}
            >
              {isDeleting ? 'Excluindo...' : 'Excluir'}
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}
