import { useState, useEffect } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Plus, Download, Check, X, ArrowRight, Clock, CheckCircle2 } from "lucide-react";
import { AddTransferDialog } from "@/components/AddTransferDialog";
import { useData } from "@/contexts/DataContext";
import { useAuth } from "@/hooks/useAuth";
import { useUserRole } from "@/hooks/useUserRole";
import { exportToExcel } from "@/lib/excelUtils";
import { toast } from "sonner";
import { supabase } from "@/integrations/supabase/client";
import { Badge } from "@/components/ui/badge";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";

export default function Transferencias() {
  const [isAddDialogOpen, setIsAddDialogOpen] = useState(false);
  const [confirmDialog, setConfirmDialog] = useState<{
    open: boolean;
    type: 'approve_origin' | 'approve_destination' | 'reject';
    transferId: string;
  } | null>(null);
  const { transfers, assets, locations, departments, users, refreshTransfers, refreshAssets } = useData();
  const { user } = useAuth();
  const { isAdmin, isManager } = useUserRole();

  const handleExport = () => {
    const exportData = transfers.map(transfer => {
      const asset = assets.find(a => a.id === transfer.asset_id);
      const fromDepartment = departments.find(d => d.id === (transfer as any).from_department_id);
      const toDepartment = departments.find(d => d.id === (transfer as any).to_department_id);
      
      return {
        'ID': transfer.id.slice(0, 8),
        'Bem': asset?.name || transfer.asset_id,
        'Nº Patrimônio': asset?.inventory_number || '-',
        'Subunidade Origem': fromDepartment?.name || '-',
        'Sigla Origem': fromDepartment?.sigla || '-',
        'Subunidade Destino': toDepartment?.name || '-',
        'Sigla Destino': toDepartment?.sigla || '-',
        'Data': transfer.date ? new Date(transfer.date).toLocaleDateString('pt-BR') : '-',
        'Status': transfer.status,
        'Observações': transfer.notes || '-',
      };
    });
    exportToExcel(exportData, 'transferencias');
    toast.success('Transferências exportadas com sucesso!');
  };

  const getStatusBadge = (status: string) => {
    const statusConfig: Record<string, { variant: 'default' | 'secondary' | 'destructive' | 'outline'; icon: any }> = {
      'Aguardando Aprovação Origem': { variant: 'secondary', icon: Clock },
      'Aguardando Recebimento': { variant: 'default', icon: ArrowRight },
      'Concluída': { variant: 'outline', icon: CheckCircle2 },
      'Rejeitada': { variant: 'destructive', icon: X },
      'Pendente': { variant: 'secondary', icon: Clock },
    };

    const config = statusConfig[status] || statusConfig['Pendente'];
    const Icon = config.icon;

    return (
      <Badge variant={config.variant} className="gap-1">
        <Icon className="h-3 w-3" />
        {status}
      </Badge>
    );
  };

  const handleApproveOrigin = async (transferId: string) => {
    try {
      const transfer = transfers.find(t => t.id === transferId);
      if (!transfer) return;

      // Update transfer status
      const { error } = await supabase
        .from('transfers')
        .update({
          status: 'Aguardando Recebimento',
          origin_approved_at: new Date().toISOString(),
          origin_approved_by: user?.id,
        })
        .eq('id', transferId);

      if (error) throw error;

      const asset = assets.find(a => a.id === transfer.asset_id);
      const fromLocation = locations.find(l => l.id === transfer.from_location_id);
      const toLocation = locations.find(l => l.id === transfer.to_location_id);

      // Get destination department manager
      const toDept = departments.find(d => d.id === (transfer as any).to_department_id);
      if (toDept?.responsible_id) {
        // Create in-app notification
        await supabase.from('notifications').insert({
          user_id: toDept.responsible_id,
          title: 'Transferência Aguardando Recebimento',
          message: `O bem "${asset?.name}" foi enviado de ${fromLocation?.name}. Por favor, confirme o recebimento.`,
          type: 'transfer',
          related_id: transferId,
          related_type: 'transfer',
        });

        // Send email
        const destManager = users.find(u => u.id === toDept.responsible_id);
        if (destManager?.email) {
          try {
            await supabase.functions.invoke('send-notification-email', {
              body: {
                to: destManager.email,
                subject: 'Transferência Aguardando Recebimento',
                type: 'transfer_pending_approval',
                data: {
                  userName: destManager.name,
                  assetName: asset?.name,
                  fromLocation: fromLocation?.name,
                  toLocation: toLocation?.name,
                },
              },
            });
          } catch (e) {
            console.error('Error sending email:', e);
          }
        }
      }

      toast.success('Envio aprovado! Aguardando confirmação de recebimento.');
      refreshTransfers();
    } catch (error: any) {
      console.error('Error approving transfer:', error);
      toast.error('Erro ao aprovar transferência');
    }
  };

  const handleApproveDestination = async (transferId: string) => {
    try {
      const transfer = transfers.find(t => t.id === transferId);
      if (!transfer) return;

      // Update transfer status
      const { error: transferError } = await supabase
        .from('transfers')
        .update({
          status: 'Concluída',
          destination_approved_at: new Date().toISOString(),
          destination_approved_by: user?.id,
        })
        .eq('id', transferId);

      if (transferError) throw transferError;

      // Update asset location
      await supabase
        .from('assets')
        .update({
          location_id: transfer.to_location_id,
          department_id: (transfer as any).to_department_id,
        })
        .eq('id', transfer.asset_id);

      const asset = assets.find(a => a.id === transfer.asset_id);
      const toLocation = locations.find(l => l.id === transfer.to_location_id);

      // Notify requester
      if ((transfer as any).requester_id) {
        await supabase.from('notifications').insert({
          user_id: (transfer as any).requester_id,
          title: 'Transferência Concluída',
          message: `A transferência do bem "${asset?.name}" para ${toLocation?.name} foi concluída com sucesso.`,
          type: 'transfer',
          related_id: transferId,
          related_type: 'transfer',
        });

        const requester = users.find(u => u.id === (transfer as any).requester_id);
        if (requester?.email) {
          try {
            await supabase.functions.invoke('send-notification-email', {
              body: {
                to: requester.email,
                subject: 'Transferência Concluída',
                type: 'transfer_completed',
                data: {
                  userName: requester.name,
                  assetName: asset?.name,
                  toLocation: toLocation?.name,
                },
              },
            });
          } catch (e) {
            console.error('Error sending email:', e);
          }
        }
      }

      toast.success('Recebimento confirmado! Transferência concluída.');
      refreshTransfers();
      refreshAssets();
    } catch (error: any) {
      console.error('Error completing transfer:', error);
      toast.error('Erro ao confirmar recebimento');
    }
  };

  const handleReject = async (transferId: string) => {
    try {
      await supabase
        .from('transfers')
        .update({ status: 'Rejeitada' })
        .eq('id', transferId);

      toast.success('Transferência rejeitada.');
      refreshTransfers();
    } catch (error) {
      console.error('Error rejecting transfer:', error);
      toast.error('Erro ao rejeitar transferência');
    }
  };

  const canApproveOrigin = (transfer: any) => {
    if (!user) return false;
    const originDept = departments.find(d => d.id === transfer.from_department_id);
    return (isAdmin || (isManager && originDept?.responsible_id === user.id)) && 
           transfer.status === 'Aguardando Aprovação Origem';
  };

  const canApproveDestination = (transfer: any) => {
    if (!user) return false;
    const destDept = departments.find(d => d.id === transfer.to_department_id);
    return (isAdmin || (isManager && destDept?.responsible_id === user.id)) && 
           transfer.status === 'Aguardando Recebimento';
  };

  return (
    <div className="min-h-screen bg-background p-8">
      <div className="mx-auto max-w-7xl space-y-6">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-3xl font-bold text-foreground">Transferência de Bens</h1>
            <p className="mt-2 text-muted-foreground">
              Gerencie o processo de movimentação de bens entre responsáveis e localidades.
            </p>
          </div>
          <div className="flex gap-2">
            <Button 
              variant="outline"
              className="gap-2"
              onClick={handleExport}
            >
              <Download className="h-4 w-4" />
              Exportar Excel
            </Button>
            {(isAdmin || isManager) && (
              <Button 
                className="bg-info hover:bg-info/90 text-info-foreground"
                onClick={() => setIsAddDialogOpen(true)}
              >
                <Plus className="mr-2 h-4 w-4" />
                Iniciar Transferência
              </Button>
            )}
          </div>
        </div>

        <Card className="border-border bg-card">
          <CardHeader>
            <CardTitle className="text-xl">Solicitações de Transferência</CardTitle>
            <p className="text-sm text-muted-foreground">
              Acompanhe e gerencie todas as solicitações de transferência de bens.
            </p>
          </CardHeader>
          <CardContent>
            {transfers.length === 0 ? (
              <div className="flex h-[300px] items-center justify-center text-muted-foreground">
                Nenhuma solicitação de transferência encontrada.
              </div>
            ) : (
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Bem</TableHead>
                    <TableHead>Prédio</TableHead>
                    <TableHead>Subunidade Origem</TableHead>
                    <TableHead>Subunidade Destino</TableHead>
                    <TableHead>Data</TableHead>
                    <TableHead>Status</TableHead>
                    <TableHead className="text-right">Ações</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {transfers.map((transfer) => {
                    const asset = assets.find(a => a.id === transfer.asset_id);
                    const fromDepartment = departments.find(d => d.id === (transfer as any).from_department_id);
                    const toDepartment = departments.find(d => d.id === (transfer as any).to_department_id);
                    const fromLocation = locations.find(l => l.id === transfer.from_location_id);

                    return (
                      <TableRow key={transfer.id}>
                        <TableCell>
                          <div>
                            <div className="font-medium">{asset?.name || 'N/A'}</div>
                            <div className="text-sm text-muted-foreground">
                              {asset?.inventory_number}
                            </div>
                          </div>
                        </TableCell>
                        <TableCell>{fromLocation?.name || 'N/A'}</TableCell>
                        <TableCell>
                          <div>
                            <div className="font-medium">{fromDepartment?.sigla || fromDepartment?.name || 'N/A'}</div>
                            <div className="text-sm text-muted-foreground">{fromDepartment?.name || ''}</div>
                          </div>
                        </TableCell>
                        <TableCell>
                          <div>
                            <div className="font-medium">{toDepartment?.sigla || toDepartment?.name || 'N/A'}</div>
                            <div className="text-sm text-muted-foreground">{toDepartment?.name || ''}</div>
                          </div>
                        </TableCell>
                        <TableCell>
                          {transfer.date 
                            ? new Date(transfer.date).toLocaleDateString('pt-BR')
                            : '-'
                          }
                        </TableCell>
                        <TableCell>{getStatusBadge(transfer.status)}</TableCell>
                        <TableCell className="text-right">
                          <div className="flex justify-end gap-2">
                            {canApproveOrigin(transfer) && (
                              <>
                                <Button
                                  size="sm"
                                  variant="outline"
                                  className="text-green-600 hover:text-green-700"
                                  onClick={() => setConfirmDialog({
                                    open: true,
                                    type: 'approve_origin',
                                    transferId: transfer.id,
                                  })}
                                >
                                  <Check className="h-4 w-4 mr-1" />
                                  Aprovar Envio
                                </Button>
                                <Button
                                  size="sm"
                                  variant="outline"
                                  className="text-destructive hover:text-destructive"
                                  onClick={() => setConfirmDialog({
                                    open: true,
                                    type: 'reject',
                                    transferId: transfer.id,
                                  })}
                                >
                                  <X className="h-4 w-4 mr-1" />
                                  Rejeitar
                                </Button>
                              </>
                            )}
                            {canApproveDestination(transfer) && (
                              <Button
                                size="sm"
                                variant="outline"
                                className="text-green-600 hover:text-green-700"
                                onClick={() => setConfirmDialog({
                                  open: true,
                                  type: 'approve_destination',
                                  transferId: transfer.id,
                                })}
                              >
                                <Check className="h-4 w-4 mr-1" />
                                Confirmar Recebimento
                              </Button>
                            )}
                          </div>
                        </TableCell>
                      </TableRow>
                    );
                  })}
                </TableBody>
              </Table>
            )}
          </CardContent>
        </Card>

        <AddTransferDialog 
          open={isAddDialogOpen} 
          onOpenChange={setIsAddDialogOpen}
          onSuccess={refreshTransfers}
        />

        <AlertDialog 
          open={confirmDialog?.open} 
          onOpenChange={(open) => !open && setConfirmDialog(null)}
        >
          <AlertDialogContent>
            <AlertDialogHeader>
              <AlertDialogTitle>
                {confirmDialog?.type === 'approve_origin' && 'Aprovar Envio'}
                {confirmDialog?.type === 'approve_destination' && 'Confirmar Recebimento'}
                {confirmDialog?.type === 'reject' && 'Rejeitar Transferência'}
              </AlertDialogTitle>
              <AlertDialogDescription>
                {confirmDialog?.type === 'approve_origin' && 
                  'Ao aprovar o envio, o encarregado da unidade de destino será notificado para confirmar o recebimento do bem.'}
                {confirmDialog?.type === 'approve_destination' && 
                  'Ao confirmar o recebimento, a transferência será concluída e a localização do bem será atualizada.'}
                {confirmDialog?.type === 'reject' && 
                  'Tem certeza que deseja rejeitar esta transferência? Esta ação não pode ser desfeita.'}
              </AlertDialogDescription>
            </AlertDialogHeader>
            <AlertDialogFooter>
              <AlertDialogCancel>Cancelar</AlertDialogCancel>
              <AlertDialogAction
                onClick={() => {
                  if (confirmDialog?.type === 'approve_origin') {
                    handleApproveOrigin(confirmDialog.transferId);
                  } else if (confirmDialog?.type === 'approve_destination') {
                    handleApproveDestination(confirmDialog.transferId);
                  } else if (confirmDialog?.type === 'reject') {
                    handleReject(confirmDialog.transferId);
                  }
                  setConfirmDialog(null);
                }}
                className={confirmDialog?.type === 'reject' ? 'bg-destructive hover:bg-destructive/90' : ''}
              >
                {confirmDialog?.type === 'reject' ? 'Rejeitar' : 'Confirmar'}
              </AlertDialogAction>
            </AlertDialogFooter>
          </AlertDialogContent>
        </AlertDialog>
      </div>
    </div>
  );
}
