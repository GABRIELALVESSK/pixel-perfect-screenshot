import { useState } from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Badge } from "@/components/ui/badge";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Search, Download, Plus, MoreHorizontal, ClipboardCheck, Package, AlertTriangle } from "lucide-react";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
  DropdownMenuSeparator,
} from "@/components/ui/dropdown-menu";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Label } from "@/components/ui/label";
import { exportToExcel } from "@/lib/excelUtils";
import { toast } from "sonner";
import { useData } from "@/contexts/DataContext";

export default function Inventario() {
  const { assets, inventories, discrepancies, addInventory, refreshAssets } = useData();
  const [isNewInventoryDialogOpen, setIsNewInventoryDialogOpen] = useState(false);
  const [newInventoryName, setNewInventoryName] = useState("");
  const [newInventoryStartDate, setNewInventoryStartDate] = useState("");
  const [newInventoryEndDate, setNewInventoryEndDate] = useState("");
  const [isCreating, setIsCreating] = useState(false);
  const [searchTerm, setSearchTerm] = useState("");

  // Estatísticas reais
  const totalInventories = inventories.length;
  const inProgressInventories = inventories.filter(inv => inv.status === 'Em Andamento').length;
  const totalAssetsCount = assets.length;
  const totalDiscrepancies = discrepancies.length;
  const pendingDiscrepancies = discrepancies.filter(d => d.status === 'Pendente').length;

  // Filtrar inventários por busca
  const filteredInventories = inventories.filter(inv => 
    inv.name.toLowerCase().includes(searchTerm.toLowerCase())
  );

  // Criar novo inventário com todos os bens
  const handleCreateInventory = async () => {
    if (!newInventoryName.trim() || !newInventoryStartDate) {
      toast.error("Preencha o nome e a data de início do inventário");
      return;
    }

    setIsCreating(true);
    try {
      await addInventory({
        name: newInventoryName.trim(),
        start_date: newInventoryStartDate,
        end_date: newInventoryEndDate || null,
        status: 'Em Andamento',
        responsible_id: null,
        progress: 0,
        created_at: new Date().toISOString(),
        updated_at: new Date().toISOString(),
      });

      toast.success(`Inventário "${newInventoryName}" criado com ${totalAssetsCount} bens incluídos!`);
      setIsNewInventoryDialogOpen(false);
      setNewInventoryName("");
      setNewInventoryStartDate("");
      setNewInventoryEndDate("");
    } catch (error) {
      console.error("Erro ao criar inventário:", error);
      toast.error("Erro ao criar inventário");
    } finally {
      setIsCreating(false);
    }
  };

  const handleExportInventories = () => {
    const exportData = inventories.map(inv => ({
      'ID': inv.id.slice(0, 8).toUpperCase(),
      'Nome': inv.name,
      'Data Início': new Date(inv.start_date).toLocaleDateString('pt-BR'),
      'Data Fim': inv.end_date ? new Date(inv.end_date).toLocaleDateString('pt-BR') : '-',
      'Progresso': `${inv.progress}%`,
      'Status': inv.status,
      'Total de Bens': totalAssetsCount,
    }));
    exportToExcel(exportData, 'inventarios');
    toast.success('Inventários exportados com sucesso!');
  };

  const handleExportDiscrepancies = () => {
    const exportData = discrepancies.map(disc => ({
      'ID': disc.id.slice(0, 8).toUpperCase(),
      'Inventário': disc.inventory_id.slice(0, 8).toUpperCase(),
      'Bem': disc.asset_id.slice(0, 8).toUpperCase(),
      'Data': disc.date ? new Date(disc.date).toLocaleDateString('pt-BR') : '-',
      'Status': disc.status,
      'Observações': disc.notes || '-',
    }));
    exportToExcel(exportData, 'discrepancias');
    toast.success('Discrepâncias exportadas com sucesso!');
  };

  const getStatusBadge = (status: string) => {
    switch (status) {
      case 'Concluído':
        return <Badge className="bg-success text-background">Concluído</Badge>;
      case 'Em Andamento':
        return <Badge className="bg-warning text-background">Em andamento</Badge>;
      case 'Planejado':
        return <Badge className="bg-muted-foreground text-foreground">Planejado</Badge>;
      default:
        return <Badge variant="outline">{status}</Badge>;
    }
  };

  return (
    <div className="min-h-screen bg-background p-8">
      <div className="mx-auto max-w-7xl space-y-6">
        <div>
          <h1 className="text-3xl font-bold text-foreground">Inventário</h1>
          <p className="mt-2 text-muted-foreground">
            Gerencie os processos de inventário e acompanhe as discrepâncias.
          </p>
        </div>

        <Tabs defaultValue="geral" className="space-y-6">
          <TabsList className="bg-secondary">
            <TabsTrigger value="geral">Visão Geral</TabsTrigger>
            <TabsTrigger value="inventarios">Inventários</TabsTrigger>
            <TabsTrigger value="bens">Bens do Inventário</TabsTrigger>
            <TabsTrigger value="discrepancias">Discrepâncias</TabsTrigger>
          </TabsList>

          <TabsContent value="geral" className="space-y-6">
            <div className="grid gap-6 md:grid-cols-4">
              <Card className="border-border bg-card">
                <CardContent className="p-6">
                  <div className="flex items-center gap-3">
                    <ClipboardCheck className="h-8 w-8 text-primary" />
                    <div>
                      <p className="text-sm text-muted-foreground">Total de Inventários</p>
                      <h3 className="text-3xl font-bold text-foreground">{totalInventories}</h3>
                      <p className="text-sm text-muted-foreground">{inProgressInventories} em andamento</p>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card className="border-border bg-card">
                <CardContent className="p-6">
                  <div className="flex items-center gap-3">
                    <Package className="h-8 w-8 text-info" />
                    <div>
                      <p className="text-sm text-muted-foreground">Bens Cadastrados</p>
                      <h3 className="text-3xl font-bold text-foreground">{totalAssetsCount}</h3>
                      <p className="text-sm text-muted-foreground">Incluídos no inventário</p>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card className="border-border bg-card">
                <CardContent className="p-6">
                  <div className="flex items-center gap-3">
                    <AlertTriangle className="h-8 w-8 text-warning" />
                    <div>
                      <p className="text-sm text-muted-foreground">Discrepâncias</p>
                      <h3 className="text-3xl font-bold text-foreground">{totalDiscrepancies}</h3>
                      <p className="text-sm text-muted-foreground">{pendingDiscrepancies} pendentes</p>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card className="border-border bg-card">
                <CardContent className="p-6">
                  <div className="flex items-center gap-3">
                    <ClipboardCheck className="h-8 w-8 text-success" />
                    <div>
                      <p className="text-sm text-muted-foreground">Taxa de Verificação</p>
                      <h3 className="text-3xl font-bold text-foreground">
                        {totalAssetsCount > 0 ? Math.round((totalAssetsCount - pendingDiscrepancies) / totalAssetsCount * 100) : 0}%
                      </h3>
                      <p className="text-sm text-muted-foreground">Bens verificados</p>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>

            <Card className="border-border bg-card">
              <CardContent className="p-6 space-y-4">
                <div className="flex items-center justify-between">
                  <div>
                    <h3 className="text-lg font-semibold text-foreground">Inventários Recentes</h3>
                    <p className="text-sm text-muted-foreground">
                      Status dos inventários em andamento e recentes
                    </p>
                  </div>
                  <Button 
                    className="gap-2 bg-info hover:bg-info/90 text-info-foreground"
                    onClick={() => setIsNewInventoryDialogOpen(true)}
                  >
                    <Plus className="h-4 w-4" />
                    Novo Inventário
                  </Button>
                </div>

                <div className="space-y-4">
                  {inventories.length === 0 ? (
                    <div className="text-center py-8 text-muted-foreground">
                      Nenhum inventário cadastrado. Crie um novo inventário para começar.
                    </div>
                  ) : (
                    inventories.slice(0, 5).map((inv) => (
                      <div
                        key={inv.id}
                        className="rounded-lg border border-border bg-secondary/50 p-4"
                      >
                        <div className="flex items-start justify-between">
                          <div className="flex-1">
                            <h4 className="font-medium text-foreground">{inv.name}</h4>
                            <p className="text-sm text-muted-foreground">
                              {new Date(inv.start_date).toLocaleDateString('pt-BR')} 
                              {inv.end_date && ` - ${new Date(inv.end_date).toLocaleDateString('pt-BR')}`}
                            </p>
                            <p className="text-sm text-muted-foreground mt-1">
                              {totalAssetsCount} bens incluídos
                            </p>
                            <div className="mt-3 space-y-2">
                              <div className="flex items-center justify-between text-sm">
                                <span className="text-muted-foreground">Progresso</span>
                                <span className="text-foreground">{inv.progress}%</span>
                              </div>
                              <div className="h-2 w-full overflow-hidden rounded-full bg-secondary">
                                <div
                                  className="h-full bg-primary transition-all"
                                  style={{ width: `${inv.progress}%` }}
                                />
                              </div>
                            </div>
                          </div>
                          {getStatusBadge(inv.status)}
                        </div>
                      </div>
                    ))
                  )}
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="inventarios" className="space-y-6">
            <div className="flex items-center justify-between gap-4">
              <div className="relative max-w-sm flex-1">
                <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
                <Input
                  placeholder="Buscar inventários..."
                  className="pl-10 bg-secondary border-border"
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                />
              </div>
              <div className="flex gap-2">
                <Button 
                  variant="outline" 
                  className="gap-2"
                  onClick={handleExportInventories}
                >
                  <Download className="h-4 w-4" />
                  Exportar
                </Button>
                <Button 
                  className="gap-2 bg-info hover:bg-info/90 text-info-foreground"
                  onClick={() => setIsNewInventoryDialogOpen(true)}
                >
                  <Plus className="h-4 w-4" />
                  Novo Inventário
                </Button>
              </div>
            </div>

            <Card className="border-border bg-card">
              <CardContent className="p-0">
                <div className="overflow-x-auto">
                  <table className="w-full">
                    <thead className="border-b border-border">
                      <tr>
                        <th className="px-6 py-4 text-left text-sm font-medium text-foreground">ID</th>
                        <th className="px-6 py-4 text-left text-sm font-medium text-foreground">Nome</th>
                        <th className="px-6 py-4 text-left text-sm font-medium text-foreground">Período</th>
                        <th className="px-6 py-4 text-left text-sm font-medium text-foreground">Bens</th>
                        <th className="px-6 py-4 text-left text-sm font-medium text-foreground">Progresso</th>
                        <th className="px-6 py-4 text-left text-sm font-medium text-foreground">Status</th>
                        <th className="px-6 py-4"></th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-border">
                      {filteredInventories.length === 0 ? (
                        <tr>
                          <td colSpan={7} className="px-6 py-12 text-center text-muted-foreground">
                            Nenhum inventário encontrado.
                          </td>
                        </tr>
                      ) : (
                        filteredInventories.map((inv) => (
                          <tr key={inv.id} className="hover:bg-secondary/50">
                            <td className="px-6 py-4 text-sm text-foreground font-mono">{inv.id.slice(0, 8).toUpperCase()}</td>
                            <td className="px-6 py-4 text-sm text-foreground">{inv.name}</td>
                            <td className="px-6 py-4 text-sm text-muted-foreground">
                              {new Date(inv.start_date).toLocaleDateString('pt-BR')}
                              {inv.end_date && ` - ${new Date(inv.end_date).toLocaleDateString('pt-BR')}`}
                            </td>
                            <td className="px-6 py-4 text-sm text-foreground">{totalAssetsCount}</td>
                            <td className="px-6 py-4">
                              <div className="flex items-center gap-2">
                                <div className="h-2 w-24 overflow-hidden rounded-full bg-secondary">
                                  <div
                                    className="h-full bg-primary"
                                    style={{ width: `${inv.progress}%` }}
                                  />
                                </div>
                                <span className="text-sm text-foreground">{inv.progress}%</span>
                              </div>
                            </td>
                            <td className="px-6 py-4">{getStatusBadge(inv.status)}</td>
                            <td className="px-6 py-4">
                              <DropdownMenu>
                                <DropdownMenuTrigger asChild>
                                  <Button variant="ghost" size="sm">
                                    <MoreHorizontal className="h-4 w-4" />
                                  </Button>
                                </DropdownMenuTrigger>
                                <DropdownMenuContent align="end">
                                  <DropdownMenuItem>Ver detalhes</DropdownMenuItem>
                                  <DropdownMenuItem>Editar</DropdownMenuItem>
                                  <DropdownMenuSeparator />
                                  <DropdownMenuItem className="text-destructive">Excluir</DropdownMenuItem>
                                </DropdownMenuContent>
                              </DropdownMenu>
                            </td>
                          </tr>
                        ))
                      )}
                    </tbody>
                  </table>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="bens" className="space-y-6">
            <div className="flex items-center justify-between gap-4">
              <div className="relative max-w-sm flex-1">
                <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
                <Input
                  placeholder="Buscar bens..."
                  className="pl-10 bg-secondary border-border"
                />
              </div>
              <Button 
                variant="outline" 
                className="gap-2"
                onClick={() => {
                  const exportData = assets.map(asset => ({
                    'Nº Inventário': asset.inventory_number,
                    'Nome': asset.name,
                    'Categoria': asset.asset_categories?.name || '-',
                    'Status': asset.status,
                    'Localização': asset.locations?.name || '-',
                    'Departamento': asset.departments?.name || '-',
                    'Valor': `R$ ${asset.value.toLocaleString('pt-BR', { minimumFractionDigits: 2 })}`,
                    'Data Aquisição': new Date(asset.acquisition_date).toLocaleDateString('pt-BR'),
                  }));
                  exportToExcel(exportData, 'bens-inventario');
                  toast.success('Bens exportados com sucesso!');
                }}
              >
                <Download className="h-4 w-4" />
                Exportar Bens
              </Button>
            </div>

            <Card className="border-border bg-card">
              <CardContent className="p-0">
                <div className="overflow-x-auto">
                  <table className="w-full">
                    <thead className="border-b border-border">
                      <tr>
                        <th className="px-6 py-4 text-left text-sm font-medium text-foreground">Nº Inventário</th>
                        <th className="px-6 py-4 text-left text-sm font-medium text-foreground">Nome</th>
                        <th className="px-6 py-4 text-left text-sm font-medium text-foreground">Categoria</th>
                        <th className="px-6 py-4 text-left text-sm font-medium text-foreground">Status</th>
                        <th className="px-6 py-4 text-left text-sm font-medium text-foreground">Localização</th>
                        <th className="px-6 py-4 text-left text-sm font-medium text-foreground">Valor</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-border">
                      {assets.length === 0 ? (
                        <tr>
                          <td colSpan={6} className="px-6 py-12 text-center text-muted-foreground">
                            Nenhum bem cadastrado. Importe ou adicione bens primeiro.
                          </td>
                        </tr>
                      ) : (
                        assets.map((asset) => (
                          <tr key={asset.id} className="hover:bg-secondary/50">
                            <td className="px-6 py-4 text-sm font-mono text-foreground">{asset.inventory_number}</td>
                            <td className="px-6 py-4 text-sm text-foreground">{asset.name}</td>
                            <td className="px-6 py-4 text-sm text-muted-foreground">{asset.asset_categories?.name || '-'}</td>
                            <td className="px-6 py-4">
                              <Badge 
                                variant="outline" 
                                className={
                                  asset.status === 'Ativo' ? 'bg-success/10 text-success border-success/20' :
                                  asset.status === 'Inativo' ? 'bg-destructive/10 text-destructive border-destructive/20' :
                                  'bg-warning/10 text-warning border-warning/20'
                                }
                              >
                                {asset.status}
                              </Badge>
                            </td>
                            <td className="px-6 py-4 text-sm text-muted-foreground">{asset.locations?.name || '-'}</td>
                            <td className="px-6 py-4 text-sm text-foreground">R$ {asset.value.toLocaleString('pt-BR', { minimumFractionDigits: 2 })}</td>
                          </tr>
                        ))
                      )}
                    </tbody>
                  </table>
                </div>
                <div className="flex items-center justify-between border-t border-border px-6 py-4">
                  <p className="text-sm text-muted-foreground">{assets.length} bens no inventário</p>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="discrepancias" className="space-y-6">
            <div className="flex items-center justify-between gap-4">
              <div className="flex gap-2 flex-1">
                <div className="relative max-w-sm flex-1">
                  <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
                  <Input
                    placeholder="Buscar discrepâncias..."
                    className="pl-10 bg-secondary border-border"
                  />
                </div>
                <DropdownMenu>
                  <DropdownMenuTrigger asChild>
                    <Button variant="outline" className="gap-2">
                      Filtrar por
                    </Button>
                  </DropdownMenuTrigger>
                  <DropdownMenuContent align="start">
                    <DropdownMenuItem>Status</DropdownMenuItem>
                    <DropdownMenuItem>Inventário</DropdownMenuItem>
                    <DropdownMenuItem>Data</DropdownMenuItem>
                  </DropdownMenuContent>
                </DropdownMenu>
              </div>
              <Button 
                variant="outline" 
                className="gap-2"
                onClick={handleExportDiscrepancies}
              >
                <Download className="h-4 w-4" />
                Exportar
              </Button>
            </div>

            <Card className="border-border bg-card">
              <CardContent className="p-0">
                <div className="overflow-x-auto">
                  <Table>
                    <TableHeader>
                      <TableRow className="border-b border-border hover:bg-transparent">
                        <TableHead className="text-foreground">ID</TableHead>
                        <TableHead className="text-foreground">Inventário</TableHead>
                        <TableHead className="text-foreground">Bem</TableHead>
                        <TableHead className="text-foreground">Data</TableHead>
                        <TableHead className="text-foreground">Status</TableHead>
                        <TableHead className="text-foreground">Observações</TableHead>
                        <TableHead></TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {discrepancies.length === 0 ? (
                        <TableRow>
                          <TableCell colSpan={7} className="px-6 py-12 text-center text-muted-foreground">
                            Nenhuma discrepância registrada.
                          </TableCell>
                        </TableRow>
                      ) : (
                        discrepancies.map((disc) => (
                          <TableRow key={disc.id} className="border-b border-border hover:bg-secondary/50">
                            <TableCell className="text-foreground font-mono">{disc.id.slice(0, 8).toUpperCase()}</TableCell>
                            <TableCell className="text-foreground">{disc.inventory_id.slice(0, 8).toUpperCase()}</TableCell>
                            <TableCell className="text-foreground">{disc.asset_id.slice(0, 8).toUpperCase()}</TableCell>
                            <TableCell className="text-muted-foreground">
                              {disc.date ? new Date(disc.date).toLocaleDateString('pt-BR') : '-'}
                            </TableCell>
                            <TableCell>
                              <Badge
                                className={
                                  disc.status === 'Resolvido'
                                    ? "bg-success text-background hover:bg-success/90"
                                    : "bg-warning text-background hover:bg-warning/90"
                                }
                              >
                                {disc.status}
                              </Badge>
                            </TableCell>
                            <TableCell className="text-muted-foreground max-w-xs truncate">
                              {disc.notes || '-'}
                            </TableCell>
                            <TableCell>
                              <DropdownMenu>
                                <DropdownMenuTrigger asChild>
                                  <Button variant="ghost" size="sm">
                                    <MoreHorizontal className="h-4 w-4" />
                                  </Button>
                                </DropdownMenuTrigger>
                                <DropdownMenuContent align="end">
                                  <DropdownMenuItem>Ver detalhes</DropdownMenuItem>
                                  <DropdownMenuItem>Resolver</DropdownMenuItem>
                                  <DropdownMenuSeparator />
                                  <DropdownMenuItem>Editar</DropdownMenuItem>
                                </DropdownMenuContent>
                              </DropdownMenu>
                            </TableCell>
                          </TableRow>
                        ))
                      )}
                    </TableBody>
                  </Table>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>

      {/* Dialog para criar novo inventário */}
      <Dialog open={isNewInventoryDialogOpen} onOpenChange={setIsNewInventoryDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Criar Novo Inventário</DialogTitle>
            <DialogDescription>
              Crie um novo inventário que incluirá automaticamente todos os {totalAssetsCount} bens cadastrados.
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-4 py-4">
            <div className="space-y-2">
              <Label htmlFor="inventoryName">Nome do Inventário</Label>
              <Input
                id="inventoryName"
                placeholder="Ex: Inventário Anual 2024"
                value={newInventoryName}
                onChange={(e) => setNewInventoryName(e.target.value)}
              />
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="startDate">Data de Início</Label>
                <Input
                  id="startDate"
                  type="date"
                  value={newInventoryStartDate}
                  onChange={(e) => setNewInventoryStartDate(e.target.value)}
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="endDate">Data de Término (opcional)</Label>
                <Input
                  id="endDate"
                  type="date"
                  value={newInventoryEndDate}
                  onChange={(e) => setNewInventoryEndDate(e.target.value)}
                />
              </div>
            </div>
            <div className="rounded-lg bg-info/10 border border-info/20 p-4">
              <p className="text-sm text-foreground">
                <strong>{totalAssetsCount} bens</strong> serão incluídos automaticamente neste inventário.
              </p>
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setIsNewInventoryDialogOpen(false)}>
              Cancelar
            </Button>
            <Button 
              onClick={handleCreateInventory} 
              disabled={isCreating}
              className="bg-info hover:bg-info/90 text-info-foreground"
            >
              {isCreating ? 'Criando...' : 'Criar Inventário'}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}