import { useState } from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Badge } from "@/components/ui/badge";
import { Search, Filter, Download, Plus, Calculator, FileSpreadsheet } from "lucide-react";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { AlertCircle } from "lucide-react";
import { AddDepreciationRuleDialog } from "@/components/AddDepreciationRuleDialog";
import { useData } from "@/contexts/DataContext";
import { exportToExcel } from "@/lib/excelUtils";
import { toast } from "sonner";

// Função para calcular depreciação de um ativo
const calculateDepreciation = (asset: { value: number; start_use_date?: string; acquisition_date: string }, usefulLifeYears: number = 10) => {
  if (!asset.start_use_date) {
    return { currentValue: asset.value, accumulatedDepreciation: 0, progress: 0, remainingLife: usefulLifeYears };
  }
  
  const startDate = new Date(asset.start_use_date);
  const today = new Date();
  const monthsUsed = Math.max(0, (today.getFullYear() - startDate.getFullYear()) * 12 + (today.getMonth() - startDate.getMonth()));
  const totalMonths = usefulLifeYears * 12;
  const monthlyDepreciation = asset.value / totalMonths;
  const accumulatedDepreciation = Math.min(monthsUsed * monthlyDepreciation, asset.value);
  const currentValue = Math.max(0, asset.value - accumulatedDepreciation);
  const progress = Math.min(100, (accumulatedDepreciation / asset.value) * 100);
  const remainingMonths = Math.max(0, totalMonths - monthsUsed);
  const remainingLife = remainingMonths / 12;
  
  return { currentValue, accumulatedDepreciation, progress, remainingLife, monthlyRate: (1 / totalMonths) * 100 };
};

export default function Depreciacao() {
  const [isAddRuleDialogOpen, setIsAddRuleDialogOpen] = useState(false);
  const { assets } = useData();

  // Calcular depreciação para cada ativo
  const assetsWithDepreciation = assets.map(asset => ({
    ...asset,
    depreciation: calculateDepreciation(asset)
  }));
  
  // Ativos com mais de 75% de depreciação
  const assetsNearFullDepreciation = assetsWithDepreciation.filter(a => a.depreciation.progress >= 75);
  
  // Ativos totalmente depreciados (100%)
  const fullyDepreciatedAssets = assetsWithDepreciation.filter(a => a.depreciation.progress >= 100);

  // Calcular estatísticas dos ativos
  const assetsWithStartDate = assets.filter(a => a.start_use_date);
  const assetsWithoutStartDate = assets.filter(a => !a.start_use_date);
  const totalValue = assets.reduce((sum, a) => sum + (a.value || 0), 0);
  const totalCurrentValue = assetsWithDepreciation.reduce((sum, a) => sum + a.depreciation.currentValue, 0);
  const totalDepreciation = assetsWithDepreciation.reduce((sum, a) => sum + a.depreciation.accumulatedDepreciation, 0);
  const handleExportGeneral = () => {
    const exportData = assets.map(asset => ({
      'Nome': asset.name,
      'Nº Inventário': asset.inventory_number,
      'Categoria': asset.category_id || '-',
      'Valor Original': asset.value,
      'Data Aquisição': new Date(asset.acquisition_date).toLocaleDateString('pt-BR'),
      'Data Início Uso': asset.start_use_date ? new Date(asset.start_use_date).toLocaleDateString('pt-BR') : '-',
      'Status': asset.status,
    }));
    exportToExcel(exportData, 'depreciacao-geral');
    toast.success('Relatório de depreciação exportado com sucesso!');
  };

  const handleExportTab = (tabName: string) => {
    const exportData = assets.map(asset => ({
      'Rótulo': asset.inventory_number,
      'Nome': asset.name,
      'Categoria': asset.category_id || '-',
      'Início de Uso': asset.start_use_date ? new Date(asset.start_use_date).toLocaleDateString('pt-BR') : '-',
      'Valor Atual': asset.value,
      'Taxa': '-',
      'Vida Útil Restante': '-',
      'Progresso': '0%',
      'Regras': '-',
    }));
    exportToExcel(exportData, `depreciacao-${tabName}`);
    toast.success(`Aba ${tabName} exportada com sucesso!`);
  };

  return (
    <div className="min-h-screen bg-background p-8">
      <div className="mx-auto max-w-7xl space-y-6">
        <div>
          <h1 className="text-3xl font-bold text-foreground">Gestão de Depreciação</h1>
          <p className="mt-2 text-muted-foreground">
            Acompanhe e gerencie a depreciação dos bens patrimoniais.
          </p>
        </div>

        <Tabs defaultValue="geral" className="space-y-6">
          <TabsList className="bg-secondary">
            <TabsTrigger value="geral">Visão Geral</TabsTrigger>
            <TabsTrigger value="bens">Bens e Status</TabsTrigger>
            <TabsTrigger value="regras">Regras de Depreciação</TabsTrigger>
            <TabsTrigger value="config">Configurações</TabsTrigger>
          </TabsList>

          <TabsContent value="geral" className="space-y-6">
            <Alert className="border-warning/50 bg-warning/10">
              <AlertCircle className="h-4 w-4 text-warning" />
              <AlertDescription className="text-foreground">
                <strong>Alertas de Depreciação</strong>
                <div className="mt-2">
                  <p className="text-sm">PAT-001 - Laptop Dell XPS 15</p>
                  <p className="text-sm text-muted-foreground">
                    Bem próximo da depreciação total (90%)
                  </p>
                  <p className="text-sm text-muted-foreground">16/10/2025 - 180 dias restantes</p>
                </div>
              </AlertDescription>
            </Alert>

            <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-4">
              <Card className="border-border bg-card">
                <CardContent className="p-6">
                  <p className="text-sm text-muted-foreground">Bens em Depreciação</p>
                  <h3 className="mt-2 text-3xl font-bold text-foreground">{assetsWithStartDate.length}</h3>
                  <p className="mt-2 text-sm text-muted-foreground">{assetsWithStartDate.length} em processo de depreciação</p>
                </CardContent>
              </Card>

              <Card className="border-border bg-card">
                <CardContent className="p-6">
                  <p className="text-sm text-muted-foreground">Aguardando Início</p>
                  <h3 className="mt-2 text-3xl font-bold text-foreground">{assetsWithoutStartDate.length}</h3>
                  <p className="mt-2 text-sm text-muted-foreground">Sem data de início de uso</p>
                </CardContent>
              </Card>

              <Card className="border-border bg-card">
                <CardContent className="p-6">
                  <p className="text-sm text-muted-foreground">Valor Original Total</p>
                  <h3 className="mt-2 text-3xl font-bold text-foreground">R$ {totalValue.toLocaleString('pt-BR', { minimumFractionDigits: 2 })}</h3>
                  <p className="mt-2 text-sm text-muted-foreground">Valor de aquisição dos bens</p>
                </CardContent>
              </Card>

              <Card className="border-border bg-card">
                <CardContent className="p-6">
                  <p className="text-sm text-muted-foreground">Total de Bens</p>
                  <h3 className="mt-2 text-3xl font-bold text-foreground">{assets.length}</h3>
                  <p className="mt-2 text-sm text-muted-foreground">Bens cadastrados no sistema</p>
                </CardContent>
              </Card>
            </div>

            <Card className="border-border bg-card">
              <CardContent className="p-6 space-y-4">
                <h3 className="text-lg font-semibold text-foreground">Ações Rápidas</h3>
                <p className="text-sm text-muted-foreground">
                  Gerencie a depreciação dos bens patrimoniais
                </p>

                <div className="flex gap-3">
                  <Button className="gap-2 bg-primary text-primary-foreground hover:bg-primary/90">
                    <Calculator className="h-4 w-4" />
                    Calcular Depreciação
                  </Button>
                  <Button 
                    variant="outline" 
                    className="gap-2"
                    onClick={handleExportGeneral}
                  >
                    <Download className="h-4 w-4" />
                    Exportar Relatório Excel
                  </Button>
                  <Button 
                    variant="outline" 
                    className="gap-2"
                    onClick={() => setIsAddRuleDialogOpen(true)}
                  >
                    <Plus className="h-4 w-4" />
                    Nova Regra
                  </Button>
                </div>
              </CardContent>
            </Card>

            <Card className="border-border bg-card">
              <CardContent className="p-6 space-y-4">
                <h3 className="text-lg font-semibold text-foreground">
                  Bens Próximos da Depreciação Total
                </h3>
                <p className="text-sm text-muted-foreground">
                  Bens com mais de 75% de depreciação acumulada ({assetsNearFullDepreciation.length})
                </p>
                {assetsNearFullDepreciation.length === 0 ? (
                  <div className="text-center py-8 text-muted-foreground">
                    Nenhum bem próximo da depreciação total.
                  </div>
                ) : (
                  <div className="overflow-x-auto">
                    <table className="w-full">
                      <thead className="border-b border-border">
                        <tr>
                          <th className="px-4 py-3 text-left text-sm font-medium text-foreground">Etiqueta</th>
                          <th className="px-4 py-3 text-left text-sm font-medium text-foreground">Nome</th>
                          <th className="px-4 py-3 text-left text-sm font-medium text-foreground">Valor Original</th>
                          <th className="px-4 py-3 text-left text-sm font-medium text-foreground">Valor Atual</th>
                          <th className="px-4 py-3 text-left text-sm font-medium text-foreground">Depreciação</th>
                          <th className="px-4 py-3 text-left text-sm font-medium text-foreground">Progresso</th>
                        </tr>
                      </thead>
                      <tbody>
                        {assetsNearFullDepreciation.slice(0, 10).map((asset) => (
                          <tr key={asset.id} className="border-b border-border hover:bg-muted/50">
                            <td className="px-4 py-3 text-sm">{asset.inventory_number}</td>
                            <td className="px-4 py-3 text-sm">{asset.name}</td>
                            <td className="px-4 py-3 text-sm">R$ {asset.value.toLocaleString('pt-BR', { minimumFractionDigits: 2 })}</td>
                            <td className="px-4 py-3 text-sm">R$ {asset.depreciation.currentValue.toLocaleString('pt-BR', { minimumFractionDigits: 2 })}</td>
                            <td className="px-4 py-3 text-sm">R$ {asset.depreciation.accumulatedDepreciation.toLocaleString('pt-BR', { minimumFractionDigits: 2 })}</td>
                            <td className="px-4 py-3">
                              <div className="flex items-center gap-2">
                                <div className="h-2 w-20 overflow-hidden rounded-full bg-secondary">
                                  <div
                                    className={`h-full ${asset.depreciation.progress >= 90 ? 'bg-destructive' : 'bg-warning'}`}
                                    style={{ width: `${asset.depreciation.progress}%` }}
                                  />
                                </div>
                                <span className="text-sm font-medium">{asset.depreciation.progress.toFixed(0)}%</span>
                              </div>
                            </td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                )}
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="bens" className="space-y-6">
            <div className="flex items-center gap-4">
              <div className="relative flex-1 max-w-sm">
                <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
                <Input
                  placeholder="Buscar bens..."
                  className="pl-10 bg-secondary border-border"
                />
              </div>
              <Button variant="outline" className="gap-2">
                <Filter className="h-4 w-4" />
                Filtrar
              </Button>
              <div className="ml-auto">
                <Button className="gap-2 bg-info hover:bg-info/90 text-info-foreground">
                  <Calculator className="h-4 w-4" />
                  Calcular Depreciação
                </Button>
              </div>
            </div>

            <Tabs defaultValue="aguardando" className="space-y-4">
              <TabsList className="bg-secondary">
                <TabsTrigger value="aguardando">Aguard. Início ({assetsWithoutStartDate.length})</TabsTrigger>
                <TabsTrigger value="depreciacao">Em Depreciação ({assetsWithStartDate.length})</TabsTrigger>
                <TabsTrigger value="pausados">Pausados (0)</TabsTrigger>
                <TabsTrigger value="totalmente">Totalmente Depreciados (0)</TabsTrigger>
              </TabsList>

              <TabsContent value="aguardando">
                <Card className="border-border bg-card">
                  <CardContent className="p-0">
                    <Button 
                      variant="outline" 
                      size="sm" 
                      className="m-4 gap-2"
                      onClick={() => handleExportTab('aguardando-inicio')}
                    >
                      <FileSpreadsheet className="h-4 w-4" />
                      Exportar Aba (Excel)
                    </Button>
                    <div className="overflow-x-auto">
                       <table className="w-full">
                        <thead className="border-y border-border bg-card">
                          <tr>
                            <th className="px-6 py-4 text-left text-sm font-medium text-foreground">Etiqueta</th>
                            <th className="px-6 py-4 text-left text-sm font-medium text-foreground">Nome</th>
                            <th className="px-6 py-4 text-left text-sm font-medium text-foreground">Categoria</th>
                            <th className="px-6 py-4 text-left text-sm font-medium text-foreground">Data Aquisição</th>
                            <th className="px-6 py-4 text-left text-sm font-medium text-foreground">Valor Original</th>
                            <th className="px-6 py-4 text-left text-sm font-medium text-foreground">Status</th>
                          </tr>
                        </thead>
                        <tbody>
                          {assetsWithoutStartDate.length === 0 ? (
                            <tr>
                              <td colSpan={6} className="px-6 py-12 text-center text-muted-foreground">
                                Nenhum bem aguardando início.
                              </td>
                            </tr>
                          ) : (
                            assetsWithoutStartDate.map((asset) => (
                              <tr key={asset.id} className="border-b border-border hover:bg-muted/50">
                                <td className="px-6 py-4 text-sm">{asset.inventory_number}</td>
                                <td className="px-6 py-4 text-sm">{asset.name}</td>
                                <td className="px-6 py-4 text-sm">{asset.asset_categories?.name || '-'}</td>
                                <td className="px-6 py-4 text-sm">{new Date(asset.acquisition_date).toLocaleDateString('pt-BR')}</td>
                                <td className="px-6 py-4 text-sm">R$ {asset.value.toLocaleString('pt-BR', { minimumFractionDigits: 2 })}</td>
                                <td className="px-6 py-4 text-sm">
                                  <Badge variant="outline" className="bg-warning/10 text-warning border-warning/20">
                                    Aguardando
                                  </Badge>
                                </td>
                              </tr>
                            ))
                          )}
                        </tbody>
                      </table>
                    </div>
                  </CardContent>
                </Card>
              </TabsContent>

              <TabsContent value="depreciacao">
                <Card className="border-border bg-card">
                  <CardContent className="p-0">
                    <Button 
                      variant="outline" 
                      size="sm" 
                      className="m-4 gap-2"
                      onClick={() => handleExportTab('em-depreciacao')}
                    >
                      <FileSpreadsheet className="h-4 w-4" />
                      Exportar Aba (Excel)
                    </Button>
                    <div className="overflow-x-auto">
                      <table className="w-full">
                        <thead className="border-y border-border bg-card">
                          <tr>
                            <th className="px-6 py-4 text-left text-sm font-medium text-foreground">Etiqueta</th>
                            <th className="px-6 py-4 text-left text-sm font-medium text-foreground">Nome</th>
                            <th className="px-6 py-4 text-left text-sm font-medium text-foreground">Categoria</th>
                            <th className="px-6 py-4 text-left text-sm font-medium text-foreground">Início de Uso</th>
                            <th className="px-6 py-4 text-left text-sm font-medium text-foreground">Valor Atual</th>
                            <th className="px-6 py-4 text-left text-sm font-medium text-foreground">Taxa</th>
                            <th className="px-6 py-4 text-left text-sm font-medium text-foreground">Vida Útil Rest.</th>
                            <th className="px-6 py-4 text-left text-sm font-medium text-foreground">Progresso</th>
                            <th className="px-6 py-4 text-left text-sm font-medium text-foreground">Regras</th>
                          </tr>
                        </thead>
                        <tbody>
                          {assetsWithStartDate.length === 0 ? (
                            <tr>
                              <td colSpan={9} className="px-6 py-12 text-center text-muted-foreground">
                                Nenhum bem em depreciação.
                              </td>
                            </tr>
                          ) : (
                            assetsWithStartDate.map((asset) => (
                              <tr key={asset.id} className="border-b border-border hover:bg-muted/50">
                                <td className="px-6 py-4 text-sm">{asset.inventory_number}</td>
                                <td className="px-6 py-4 text-sm">{asset.name}</td>
                                <td className="px-6 py-4 text-sm">{asset.asset_categories?.name || '-'}</td>
                                <td className="px-6 py-4 text-sm">{new Date(asset.start_use_date!).toLocaleDateString('pt-BR')}</td>
                                <td className="px-6 py-4 text-sm">R$ {asset.value.toLocaleString('pt-BR', { minimumFractionDigits: 2 })}</td>
                                <td className="px-6 py-4 text-sm">10%</td>
                                <td className="px-6 py-4 text-sm">-</td>
                                <td className="px-6 py-4 text-sm">0%</td>
                                <td className="px-6 py-4 text-sm">-</td>
                              </tr>
                            ))
                          )}
                        </tbody>
                      </table>
                    </div>
                  </CardContent>
                </Card>
              </TabsContent>

              <TabsContent value="pausados">
                <Card className="border-border bg-card">
                  <CardContent className="p-0">
                    <Button 
                      variant="outline" 
                      size="sm" 
                      className="m-4 gap-2"
                      onClick={() => handleExportTab('pausados')}
                    >
                      <FileSpreadsheet className="h-4 w-4" />
                      Exportar Aba (Excel)
                    </Button>
                    <div className="overflow-x-auto">
                       <table className="w-full">
                        <thead className="border-y border-border bg-card">
                          <tr>
                            <th className="px-6 py-4 text-left text-sm font-medium text-foreground">Etiqueta</th>
                            <th className="px-6 py-4 text-left text-sm font-medium text-foreground">Nome</th>
                            <th className="px-6 py-4 text-left text-sm font-medium text-foreground">Categoria</th>
                            <th className="px-6 py-4 text-left text-sm font-medium text-foreground">Motivo Pausa</th>
                            <th className="px-6 py-4 text-left text-sm font-medium text-foreground">Valor Atual</th>
                          </tr>
                        </thead>
                        <tbody>
                          <tr>
                            <td colSpan={5} className="px-6 py-12 text-center text-muted-foreground">
                              Nenhum bem com depreciação pausada.
                            </td>
                          </tr>
                        </tbody>
                      </table>
                    </div>
                  </CardContent>
                </Card>
              </TabsContent>

              <TabsContent value="totalmente">
                <Card className="border-border bg-card">
                  <CardContent className="p-0">
                    <Button 
                      variant="outline" 
                      size="sm" 
                      className="m-4 gap-2"
                      onClick={() => handleExportTab('totalmente-depreciados')}
                    >
                      <FileSpreadsheet className="h-4 w-4" />
                      Exportar Aba (Excel)
                    </Button>
                    <div className="overflow-x-auto">
                      <table className="w-full">
                        <thead className="border-y border-border bg-card">
                          <tr>
                            <th className="px-6 py-4 text-left text-sm font-medium text-foreground">Etiqueta</th>
                            <th className="px-6 py-4 text-left text-sm font-medium text-foreground">Nome</th>
                            <th className="px-6 py-4 text-left text-sm font-medium text-foreground">Categoria</th>
                            <th className="px-6 py-4 text-left text-sm font-medium text-foreground">Valor Original</th>
                            <th className="px-6 py-4 text-left text-sm font-medium text-foreground">Data Depreciação Total</th>
                            <th className="px-6 py-4 text-left text-sm font-medium text-foreground">Recomendação</th>
                          </tr>
                        </thead>
                        <tbody>
                          <tr>
                            <td colSpan={6} className="px-6 py-12 text-center text-muted-foreground">
                              Nenhum bem totalmente depreciado.
                            </td>
                          </tr>
                        </tbody>
                      </table>
                    </div>
                  </CardContent>
                </Card>
              </TabsContent>
            </Tabs>
          </TabsContent>

          <TabsContent value="regras" className="space-y-6">
            <div className="flex items-center justify-between gap-4">
              <div className="relative max-w-sm flex-1">
                <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
                <Input
                  placeholder="Buscar regras..."
                  className="pl-10 bg-secondary border-border"
                />
              </div>
              <Button 
                className="gap-2 bg-primary text-primary-foreground hover:bg-primary/90"
                onClick={() => setIsAddRuleDialogOpen(true)}
              >
                <Plus className="h-4 w-4" />
                Nova Regra
              </Button>
            </div>

            <Card className="border-border bg-card">
              <CardContent className="p-0">
                <div className="overflow-x-auto">
                  <table className="w-full">
                    <thead className="border-b border-border">
                      <tr>
                        <th className="px-6 py-4 text-left text-sm font-medium text-foreground">ID</th>
                        <th className="px-6 py-4 text-left text-sm font-medium text-foreground">Categoria</th>
                        <th className="px-6 py-4 text-left text-sm font-medium text-foreground">Taxa</th>
                        <th className="px-6 py-4 text-left text-sm font-medium text-foreground">Método</th>
                        <th className="px-6 py-4 text-left text-sm font-medium text-foreground">Vida Útil</th>
                        <th className="px-6 py-4 text-left text-sm font-medium text-foreground">Valor Residual</th>
                        <th className="px-6 py-4 text-left text-sm font-medium text-foreground">Status</th>
                        <th className="px-6 py-4"></th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-border">
                      {[
                        {
                          id: "R001",
                          category: "Equipamentos de TI",
                          rate: "20% a.a.",
                          method: "Linear",
                          usefulLife: "5 anos",
                          residual: "10%",
                        },
                        {
                          id: "R002",
                          category: "Mobiliário",
                          rate: "10% a.a.",
                          method: "Linear",
                          usefulLife: "10 anos",
                          residual: "5%",
                        },
                      ].map((rule) => (
                        <tr key={rule.id} className="hover:bg-secondary/50">
                          <td className="px-6 py-4 text-sm text-foreground">{rule.id}</td>
                          <td className="px-6 py-4 text-sm text-foreground">{rule.category}</td>
                          <td className="px-6 py-4 text-sm text-foreground">{rule.rate}</td>
                          <td className="px-6 py-4 text-sm text-foreground">{rule.method}</td>
                          <td className="px-6 py-4 text-sm text-foreground">{rule.usefulLife}</td>
                          <td className="px-6 py-4 text-sm text-foreground">{rule.residual}</td>
                          <td className="px-6 py-4">
                            <Badge className="bg-success text-background">Ativo</Badge>
                          </td>
                          <td className="px-6 py-4">
                            <Button variant="ghost" size="sm">⋮</Button>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="config">
            <Card className="border-border bg-card">
              <CardContent className="p-6 space-y-6">
                <div>
                  <h3 className="text-lg font-semibold text-foreground mb-4">
                    Configurações de Depreciação
                  </h3>
                  <p className="text-sm text-muted-foreground mb-6">
                    Configure as opções de depreciação automática e padrões do sistema.
                  </p>
                </div>

                <div className="space-y-6">
                  <div className="space-y-3">
                    <h4 className="font-medium text-foreground">Cálculo de Depreciação</h4>
                    
                    <div className="space-y-2">
                      <label className="text-sm text-foreground">Frequência de Cálculo</label>
                      <select className="w-full rounded-md border border-input bg-secondary px-3 py-2 text-sm">
                        <option>Mensal</option>
                        <option>Trimestral</option>
                        <option>Anual</option>
                      </select>
                      <p className="text-xs text-muted-foreground">
                        Define com que frequência o sistema calculará a depreciação.
                      </p>
                    </div>

                    <div className="space-y-2">
                      <label className="text-sm text-foreground">Método Padrão</label>
                      <select className="w-full rounded-md border border-input bg-secondary px-3 py-2 text-sm">
                        <option>Linear</option>
                        <option>Saldo Decrescente</option>
                        <option>Unidades Produzidas</option>
                      </select>
                      <p className="text-xs text-muted-foreground">
                        Método padrão para novos bens.
                      </p>
                    </div>

                    <div className="space-y-2">
                      <label className="text-sm text-foreground">Data de Início de Uso Padrão</label>
                      <select className="w-full rounded-md border border-input bg-secondary px-3 py-2 text-sm">
                        <option>Usar data de aquisição (se início de uso não informada)</option>
                        <option>Aguardar informação manual</option>
                      </select>
                      <p className="text-xs text-muted-foreground">
                        Comportamento da data de início de uso não for informada no cadastro do bem.
                      </p>
                    </div>
                  </div>

                  <div className="space-y-3">
                    <h4 className="font-medium text-foreground">Notificações</h4>
                    
                    <div className="flex items-center justify-between rounded-lg border border-border bg-secondary/50 p-4">
                      <div>
                        <p className="text-sm font-medium text-foreground">Notificar sobre Depreciação</p>
                        <p className="text-xs text-muted-foreground">
                          Enviar notificações quando um bem atingir certo percentual de depreciação.
                        </p>
                      </div>
                      <input type="checkbox" className="rounded border-border" defaultChecked />
                    </div>

                    <div className="space-y-2">
                      <label className="text-sm text-foreground">Percentual para Notificação</label>
                      <div className="space-y-2">
                        <input 
                          type="range" 
                          min="0" 
                          max="100" 
                          defaultValue="75"
                          className="w-full"
                        />
                        <div className="flex justify-between text-xs text-muted-foreground">
                          <span>0%</span>
                          <span className="text-primary font-medium">75%</span>
                          <span>100%</span>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>

                <div className="flex justify-end gap-3 pt-4 border-t border-border">
                  <Button variant="outline">Cancelar</Button>
                  <Button className="bg-primary text-primary-foreground hover:bg-primary/90">
                    Salvar Configurações
                  </Button>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
        
        <AddDepreciationRuleDialog 
          open={isAddRuleDialogOpen} 
          onOpenChange={setIsAddRuleDialogOpen} 
        />
      </div>
    </div>
  );
}
