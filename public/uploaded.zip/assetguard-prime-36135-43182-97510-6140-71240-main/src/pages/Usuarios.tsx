import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Download, KeyRound, Trash2, UserPlus, Edit, ShieldAlert } from "lucide-react";
import { useData } from "@/contexts/DataContext";
import { exportToExcel } from "@/lib/excelUtils";
import { toast } from "sonner";
import { supabase } from "@/integrations/supabase/client";
import { useState, useEffect } from "react";
import { useUserRole } from "@/hooks/useUserRole";
import { useNavigate } from "react-router-dom";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from "@/components/ui/dialog";
import { Badge } from "@/components/ui/badge";
import { InviteUserDialog } from "@/components/InviteUserDialog";
import { EditUserDialog } from "@/components/EditUserDialog";
import { AdminChangePasswordDialog } from "@/components/AdminChangePasswordDialog";

interface UserWithRole {
  id: string;
  name: string;
  email: string;
  role?: string;
}

export default function Usuarios() {
  const { users, deleteUser } = useData();
  const { isAdmin, loading: roleLoading } = useUserRole();
  const navigate = useNavigate();
  const [selectedUser, setSelectedUser] = useState<string | null>(null);
  const [showDeleteDialog, setShowDeleteDialog] = useState(false);
  const [showInviteDialog, setShowInviteDialog] = useState(false);
  const [showEditDialog, setShowEditDialog] = useState(false);
  const [showChangePasswordDialog, setShowChangePasswordDialog] = useState(false);
  const [editingUser, setEditingUser] = useState<UserWithRole | null>(null);
  const [passwordUser, setPasswordUser] = useState<UserWithRole | null>(null);
  const [isDeleting, setIsDeleting] = useState(false);
  const [usersWithRoles, setUsersWithRoles] = useState<UserWithRole[]>([]);

  // Redirecionar se não for admin
  useEffect(() => {
    if (!roleLoading && !isAdmin) {
      toast.error('Acesso negado. Apenas administradores podem acessar esta página.');
      navigate('/');
    }
  }, [roleLoading, isAdmin, navigate]);

  const fetchUserRoles = async () => {
    const { data: roles } = await supabase
      .from('user_roles')
      .select('user_id, role');

    if (roles) {
      const roleMap = new Map(roles.map(r => [r.user_id, r.role]));
      const enrichedUsers = users.map(u => ({
        ...u,
        role: roleMap.get(u.id) || 'user'
      }));
      setUsersWithRoles(enrichedUsers);
    } else {
      setUsersWithRoles(users.map(u => ({ ...u, role: 'user' })));
    }
  };

  useEffect(() => {
    if (users.length > 0) {
      fetchUserRoles();
    }
  }, [users]);

  const handleExport = () => {
    const exportData = usersWithRoles.map(user => ({
      'ID': user.id.slice(0, 8),
      'Nome': user.name,
      'Email': user.email,
      'Função': getRoleLabel(user.role || 'user'),
    }));
    exportToExcel(exportData, 'usuarios');
    toast.success('Usuários exportados com sucesso!');
  };

  const getRoleLabel = (role: string) => {
    const roleLabels: Record<string, string> = {
      'admin': 'Administrador',
      'manager': 'Encarregado',
      'user': 'Usuário',
    };
    return roleLabels[role] || 'Usuário';
  };

  const getRoleBadgeVariant = (role: string) => {
    switch (role) {
      case 'admin':
        return 'destructive';
      case 'manager':
        return 'default';
      default:
        return 'secondary';
    }
  };

  const handleChangePassword = (user: UserWithRole) => {
    setPasswordUser(user);
    setShowChangePasswordDialog(true);
  };

  const handleDeleteUser = async () => {
    if (!selectedUser || !isAdmin) return;
    
    setIsDeleting(true);
    const user = users.find(u => u.id === selectedUser);
    
    if (!user) {
      toast.error('Usuário não encontrado');
      setIsDeleting(false);
      return;
    }

    try {
      await deleteUser(selectedUser);
      toast.success(`Usuário ${user.name} excluído com sucesso`);
      setShowDeleteDialog(false);
      setSelectedUser(null);
    } catch (error: any) {
      toast.error('Erro ao excluir usuário: ' + error.message);
    } finally {
      setIsDeleting(false);
    }
  };

  // Se está carregando, mostrar loading
  if (roleLoading) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <span className="text-muted-foreground">Carregando...</span>
      </div>
    );
  }

  // Se não for admin, mostrar acesso negado
  if (!isAdmin) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <div className="text-center space-y-4">
          <ShieldAlert className="h-16 w-16 mx-auto text-destructive" />
          <h1 className="text-2xl font-bold text-foreground">Acesso Negado</h1>
          <p className="text-muted-foreground">Você não tem permissão para acessar esta página.</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background p-8">
      <div className="mx-auto max-w-7xl space-y-6">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-3xl font-bold text-foreground">Gestão de Usuários</h1>
            <p className="mt-2 text-muted-foreground">
              Cadastre e gerencie os usuários do sistema, incluindo Administradores e Encarregados.
            </p>
          </div>
          <Button 
            className="bg-info hover:bg-info/90 text-info-foreground"
            onClick={() => setShowInviteDialog(true)}
          >
            <UserPlus className="mr-2 h-4 w-4" />
            Convidar Usuário
          </Button>
        </div>

        <Card className="border-border bg-card">
          <CardHeader className="flex flex-row items-center justify-between">
            <div>
              <CardTitle className="text-xl">Lista de Usuários Cadastrados</CardTitle>
              <p className="text-sm text-muted-foreground">
                Visualize e gerencie os usuários do sistema.
              </p>
            </div>
            <Button 
              variant="outline"
              className="gap-2"
              onClick={handleExport}
            >
              <Download className="h-4 w-4" />
              Exportar Excel
            </Button>
          </CardHeader>
          <CardContent>
            {usersWithRoles.length === 0 ? (
              <div className="flex h-[300px] items-center justify-center text-muted-foreground">
                Nenhum usuário cadastrado.
              </div>
            ) : (
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Nome</TableHead>
                    <TableHead>Email</TableHead>
                    <TableHead>Função</TableHead>
                    <TableHead className="text-right">Ações</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {usersWithRoles.map((user) => (
                    <TableRow key={user.id}>
                      <TableCell className="font-medium">{user.name}</TableCell>
                      <TableCell>{user.email}</TableCell>
                      <TableCell>
                        <Badge variant={getRoleBadgeVariant(user.role || 'user') as any}>
                          {getRoleLabel(user.role || 'user')}
                        </Badge>
                      </TableCell>
                      <TableCell className="text-right">
                        <div className="flex justify-end gap-2">
                          <Button
                            variant="ghost"
                            size="sm"
                            onClick={() => {
                              setEditingUser(user);
                              setShowEditDialog(true);
                            }}
                          >
                            <Edit className="h-4 w-4 mr-2" />
                            Editar
                          </Button>
                          <Button
                            variant="ghost"
                            size="sm"
                            onClick={() => handleChangePassword(user)}
                          >
                            <KeyRound className="h-4 w-4 mr-2" />
                            Alterar senha
                          </Button>
                          <Button
                            variant="ghost"
                            size="sm"
                            className="text-destructive hover:text-destructive"
                            onClick={() => {
                              setSelectedUser(user.id);
                              setShowDeleteDialog(true);
                            }}
                          >
                            <Trash2 className="h-4 w-4 mr-2" />
                            Excluir
                          </Button>
                        </div>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            )}
          </CardContent>
        </Card>
      </div>

      <InviteUserDialog
        open={showInviteDialog}
        onOpenChange={setShowInviteDialog}
        onSuccess={fetchUserRoles}
      />

      <EditUserDialog
        open={showEditDialog}
        onOpenChange={setShowEditDialog}
        user={editingUser}
        onSuccess={fetchUserRoles}
      />

      <AdminChangePasswordDialog
        open={showChangePasswordDialog}
        onOpenChange={setShowChangePasswordDialog}
        user={passwordUser}
      />

      <Dialog open={showDeleteDialog} onOpenChange={setShowDeleteDialog}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Excluir usuário</DialogTitle>
            <DialogDescription>
              Tem certeza que deseja excluir este usuário? Esta ação não pode ser desfeita.
            </DialogDescription>
          </DialogHeader>
          <DialogFooter>
            <Button
              variant="outline"
              onClick={() => {
                setShowDeleteDialog(false);
                setSelectedUser(null);
              }}
              disabled={isDeleting}
            >
              Cancelar
            </Button>
            <Button 
              variant="destructive" 
              onClick={handleDeleteUser} 
              disabled={isDeleting}
            >
              {isDeleting ? 'Excluindo...' : 'Excluir usuário'}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
