import { Package, DollarSign, Activity, Wrench, AlertCircle, CheckCircle, Info, Download, RefreshCw } from "lucide-react";
import { StatCard } from "@/components/StatCard";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { useData } from "@/contexts/DataContext";
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer, LineChart, Line, Area, AreaChart } from "recharts";

const alerts = [
  {
    id: 1,
    message: "10 bens com manutenção preventiva pendente",
    type: "warning",
    icon: AlertCircle,
  },
  {
    id: 2,
    message: "Inventário do setor TI concluído com 98% de conformidade",
    type: "success",
    icon: CheckCircle,
  },
  {
    id: 3,
    message: "5 novas transferências de bens aguardando aprovação",
    type: "info",
    icon: Info,
  },
];

export default function Dashboard() {
  const { assets, departments, transfers, inventories } = useData();

  // Calcular dados para os gráficos
  const evolucaoBens = [
    { mes: "Jan", Total: 45, Adicionados: 5, Removidos: 2 },
    { mes: "Fev", Total: 48, Adicionados: 4, Removidos: 1 },
    { mes: "Mar", Total: 52, Adicionados: 6, Removidos: 2 },
    { mes: "Abr", Total: 58, Adicionados: 7, Removidos: 1 },
    { mes: "Mai", Total: 65, Adicionados: 8, Removidos: 1 },
    { mes: "Jun", Total: 72, Adicionados: 9, Removidos: 2 },
    { mes: "Jul", Total: 80, Adicionados: 10, Removidos: 2 },
    { mes: "Ago", Total: 88, Adicionados: 9, Removidos: 1 },
    { mes: "Set", Total: 95, Adicionados: 8, Removidos: 1 },
    { mes: "Out", Total: 102, Adicionados: 9, Removidos: 2 },
    { mes: "Nov", Total: 110, Adicionados: 10, Removidos: 2 },
    { mes: "Dez", Total: 118, Adicionados: 10, Removidos: 2 },
  ];

  const bensPorCategoria = [
    { categoria: "Equip. de TI", quantidade: 45 },
    { categoria: "Mobiliário", quantidade: 32 },
    { categoria: "Eletrônicos", quantidade: 28 },
    { categoria: "Veículos", quantidade: 18 },
    { categoria: "Outros", quantidade: 12 },
  ];

  const valorPorCategoria = [
    { categoria: "Equip. de TI", valor: 450000 },
    { categoria: "Mobiliário", valor: 180000 },
    { categoria: "Eletrônicos", valor: 120000 },
    { categoria: "Veículos", valor: 320000 },
    { categoria: "Outros", valor: 80000 },
  ];

  const bensPorLocalizacao = [
    { localizacao: "Sede", quantidade: 65 },
    { localizacao: "Filial Sul", quantidade: 42 },
    { localizacao: "Filial Norte", quantidade: 38 },
    { localizacao: "Centro Dist.", quantidade: 28 },
  ];

  const idadeBens = [
    { faixa: "< 1 ano", quantidade: 45, fill: "hsl(var(--primary))" },
    { faixa: "1-2 anos", quantidade: 38, fill: "hsl(var(--primary) / 0.8)" },
    { faixa: "2-3 anos", quantidade: 32, fill: "hsl(var(--primary) / 0.6)" },
    { faixa: "3-5 anos", quantidade: 25, fill: "hsl(var(--primary) / 0.4)" },
    { faixa: "> 5 anos", quantidade: 18, fill: "hsl(var(--primary) / 0.2)" },
  ];

  const despesasOrcamento = [
    { mes: "Jan", Despesas: 24000, Orçamento: 25000 },
    { mes: "Fev", Despesas: 28000, Orçamento: 27000 },
    { mes: "Mar", Despesas: 32000, Orçamento: 30000 },
    { mes: "Abr", Despesas: 28000, Orçamento: 30000 },
    { mes: "Mai", Despesas: 30000, Orçamento: 28000 },
    { mes: "Jun", Despesas: 34000, Orçamento: 33000 },
  ];

  const valorPorDepartamento = [
    { departamento: "TI", valor: 280000, fill: "hsl(var(--primary))" },
    { departamento: "Admin", valor: 240000, fill: "hsl(var(--primary) / 0.8)" },
    { departamento: "RH", valor: 180000, fill: "hsl(var(--primary) / 0.6)" },
    { departamento: "Marketing", valor: 210000, fill: "hsl(var(--primary) / 0.4)" },
    { departamento: "Diretoria", valor: 140000, fill: "hsl(var(--primary) / 0.2)" },
  ];

  const taxaUtilizacaoPorTipo = [
    { tipo: "Notebooks", unidades: 120, taxa: 95 },
    { tipo: "Desktops", unidades: 80, taxa: 85 },
    { tipo: "Monitores", unidades: 150, taxa: 90 },
    { tipo: "Impressoras", unidades: 45, taxa: 70 },
    { tipo: "Projetores", unidades: 15, taxa: 60 },
    { tipo: "Mobiliário", unidades: 200, taxa: 98 },
  ];

  const conformidadeInventario = [
    { departamento: "TI", conformidade: 95, fill: "hsl(var(--primary))" },
    { departamento: "Admin", conformidade: 88, fill: "hsl(var(--primary) / 0.7)" },
    { departamento: "RH", conformidade: 82, fill: "hsl(var(--primary) / 0.5)" },
    { departamento: "Marketing", conformidade: 85, fill: "hsl(var(--primary) / 0.6)" },
    { departamento: "Diretoria", conformidade: 92, fill: "hsl(var(--primary) / 0.9)" },
  ];

  const manutencoesHistorico = [
    { mes: "Jan", Preventivas: 12, Corretivas: 5 },
    { mes: "Fev", Preventivas: 15, Corretivas: 7 },
    { mes: "Mar", Preventivas: 18, Corretivas: 6 },
    { mes: "Abr", Preventivas: 14, Corretivas: 9 },
    { mes: "Mai", Preventivas: 16, Corretivas: 8 },
    { mes: "Jun", Preventivas: 15, Corretivas: 6 },
  ];

  const totalValor = assets.reduce((sum, a) => sum + Number(a.value), 0);
  const transfersPendentes = transfers.filter(t => t.status === "Pendente").length;

  return (
    <div className="min-h-screen bg-background p-8">
      <div className="mx-auto max-w-7xl space-y-6">
        <div className="space-y-2">
          <h1 className="text-4xl font-bold text-foreground">Dashboard Principal</h1>
          <div className="flex items-center justify-between">
            <div>
              <h2 className="text-xl font-semibold text-foreground">Dashboard Analítico</h2>
              <p className="text-sm text-muted-foreground">
                Visão geral e análise detalhada dos bens patrimoniais.
              </p>
            </div>
            <div className="flex items-center gap-3">
              <select className="rounded-lg border border-border bg-secondary px-4 py-2 text-sm font-medium text-foreground focus:outline-none focus:ring-2 focus:ring-primary">
                <option>Último Ano</option>
                <option>Último Mês</option>
                <option>Última Semana</option>
              </select>
              <Button 
                variant="outline" 
                size="sm" 
                className="h-10 hover:scale-105 transition-all duration-300 hover:shadow-lg hover:border-primary/50 group"
              >
                <RefreshCw className="h-4 w-4 group-hover:rotate-180 transition-transform duration-500" />
              </Button>
              <Button variant="outline" size="sm" className="h-10 gap-2">
                <Download className="h-4 w-4" />
                Exportar
              </Button>
            </div>
          </div>
        </div>

        <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
          <StatCard
            title="Total de Bens"
            value={assets.length.toString()}
            change="+0%"
            icon={Package}
            iconColor="bg-blue-500/10 text-blue-500"
          />
          <StatCard
            title="Valor Total"
            value={`R$ ${totalValor.toLocaleString('pt-BR', { minimumFractionDigits: 0 })}`}
            change="+0%"
            icon={DollarSign}
            iconColor="bg-green-500/10 text-green-500"
          />
          <StatCard
            title="Taxa de Utilização"
            value="87%"
            change="+3%"
            icon={Activity}
            iconColor="bg-purple-500/10 text-purple-500"
          />
          <StatCard
            title="Manutenções Pendentes"
            value="0"
            change="-0"
            icon={Wrench}
            iconColor="bg-yellow-500/10 text-yellow-500"
          />
        </div>

        <Card className="border-border bg-card/50 backdrop-blur">
          <CardHeader>
            <CardTitle className="text-foreground">Alertas e Notificações</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            {alerts.map((alert) => {
              const Icon = alert.icon;
              const badgeVariant = 
                alert.type === "warning" ? "default" : 
                alert.type === "success" ? "default" : 
                "default";
              
              return (
                <div
                  key={alert.id}
                  className="flex items-center justify-between rounded-lg border border-border bg-secondary/50 p-4"
                >
                  <div className="flex items-center gap-3">
                    <Icon 
                      className={`h-5 w-5 ${
                        alert.type === "warning" ? "text-warning" :
                        alert.type === "success" ? "text-success" :
                        "text-info"
                      }`}
                    />
                    <span className="text-sm text-foreground">{alert.message}</span>
                  </div>
                  <Badge 
                    variant={badgeVariant}
                    className={
                      alert.type === "warning" ? "bg-warning text-background" :
                      alert.type === "success" ? "bg-success text-background" :
                      "bg-info text-background"
                    }
                  >
                    {alert.type === "warning" ? "Atenção" :
                     alert.type === "success" ? "Sucesso" :
                     "Informação"}
                  </Badge>
                  <Button variant="ghost" size="sm">✕</Button>
                </div>
              );
            })}
          </CardContent>
        </Card>

        <Tabs defaultValue="geral" className="space-y-6">
          <TabsList className="bg-secondary">
            <TabsTrigger value="geral">Visão Geral</TabsTrigger>
            <TabsTrigger value="financeiro">Financeiro</TabsTrigger>
            <TabsTrigger value="utilizacao">Utilização</TabsTrigger>
            <TabsTrigger value="manutencao">Manutenção</TabsTrigger>
          </TabsList>

          <TabsContent value="geral" className="space-y-4">
            <Card className="border-border bg-card">
              <CardHeader>
                <CardTitle className="text-foreground">Evolução de Bens</CardTitle>
                <CardDescription className="text-muted-foreground">
                  Quantidade total de bens ao longo do tempo
                </CardDescription>
              </CardHeader>
              <CardContent>
                <ResponsiveContainer width="100%" height={300}>
                  <AreaChart data={evolucaoBens}>
                    <defs>
                      <linearGradient id="colorTotal" x1="0" y1="0" x2="0" y2="1">
                        <stop offset="5%" stopColor="hsl(var(--primary))" stopOpacity={0.3}/>
                        <stop offset="95%" stopColor="hsl(var(--primary))" stopOpacity={0}/>
                      </linearGradient>
                    </defs>
                    <CartesianGrid strokeOpacity={0.1} vertical={false} />
                    <XAxis dataKey="mes" stroke="hsl(var(--muted-foreground))" />
                    <YAxis stroke="hsl(var(--muted-foreground))" />
                    <Tooltip 
                      contentStyle={{ 
                        backgroundColor: 'hsl(var(--card))', 
                        border: '1px solid hsl(var(--border))',
                        borderRadius: '8px'
                      }}
                    />
                    <Legend />
                    <Area 
                      type="monotone" 
                      dataKey="Total" 
                      stroke="hsl(var(--primary))" 
                      fillOpacity={1} 
                      fill="url(#colorTotal)" 
                      strokeWidth={2}
                    />
                    <Line type="monotone" dataKey="Adicionados" stroke="hsl(var(--muted-foreground))" strokeWidth={2} strokeDasharray="5 5" />
                    <Line type="monotone" dataKey="Removidos" stroke="hsl(var(--muted-foreground) / 0.5)" strokeWidth={2} strokeDasharray="3 3" />
                  </AreaChart>
                </ResponsiveContainer>
              </CardContent>
            </Card>

            <div className="grid gap-6 md:grid-cols-3">
              <Card className="border-border bg-card">
                <CardHeader>
                  <CardTitle className="text-foreground">Bens por Categoria</CardTitle>
                  <CardDescription className="text-muted-foreground">
                    Distribuição por tipo de bem
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <ResponsiveContainer width="100%" height={250}>
                    <BarChart data={bensPorCategoria} layout="vertical">
                      <CartesianGrid strokeOpacity={0.1} horizontal={false} />
                      <XAxis type="number" stroke="hsl(var(--muted-foreground))" />
                      <YAxis dataKey="categoria" type="category" width={100} stroke="hsl(var(--muted-foreground))" />
                      <Tooltip 
                        contentStyle={{ 
                          backgroundColor: 'hsl(var(--card))', 
                          border: '1px solid hsl(var(--border))',
                          borderRadius: '8px'
                        }}
                      />
                      <Bar dataKey="quantidade" fill="hsl(var(--primary))" radius={[0, 4, 4, 0]} />
                    </BarChart>
                  </ResponsiveContainer>
                </CardContent>
              </Card>

              <Card className="border-border bg-card">
                <CardHeader>
                  <CardTitle className="text-foreground">Valor por Categoria</CardTitle>
                  <CardDescription className="text-muted-foreground">
                    Distribuição do valor dos bens
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <ResponsiveContainer width="100%" height={250}>
                    <BarChart data={valorPorCategoria} layout="vertical">
                      <CartesianGrid strokeOpacity={0.1} horizontal={false} />
                      <XAxis type="number" stroke="hsl(var(--muted-foreground))" />
                      <YAxis dataKey="categoria" type="category" width={100} stroke="hsl(var(--muted-foreground))" />
                      <Tooltip 
                        contentStyle={{ 
                          backgroundColor: 'hsl(var(--card))', 
                          border: '1px solid hsl(var(--border))',
                          borderRadius: '8px'
                        }}
                        formatter={(value: number) => `R$ ${value.toLocaleString('pt-BR')}`}
                      />
                      <Bar dataKey="valor" fill="hsl(var(--primary))" radius={[0, 4, 4, 0]} />
                    </BarChart>
                  </ResponsiveContainer>
                </CardContent>
              </Card>

              <Card className="border-border bg-card">
                <CardHeader>
                  <CardTitle className="text-foreground">Bens por Localização</CardTitle>
                  <CardDescription className="text-muted-foreground">
                    Distribuído por departamento
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <ResponsiveContainer width="100%" height={250}>
                    <BarChart data={bensPorLocalizacao} layout="vertical">
                      <CartesianGrid strokeOpacity={0.1} horizontal={false} />
                      <XAxis type="number" stroke="hsl(var(--muted-foreground))" />
                      <YAxis dataKey="localizacao" type="category" width={100} stroke="hsl(var(--muted-foreground))" />
                      <Tooltip 
                        contentStyle={{ 
                          backgroundColor: 'hsl(var(--card))', 
                          border: '1px solid hsl(var(--border))',
                          borderRadius: '8px'
                        }}
                      />
                      <Bar dataKey="quantidade" fill="hsl(var(--primary))" radius={[0, 4, 4, 0]} />
                    </BarChart>
                  </ResponsiveContainer>
                </CardContent>
              </Card>
            </div>

            <Card className="border-border bg-card">
              <CardHeader>
                <CardTitle className="text-foreground">Idade dos Bens</CardTitle>
                <CardDescription className="text-muted-foreground">
                  Distribuição por tempo de aquisição
                </CardDescription>
              </CardHeader>
              <CardContent>
                <ResponsiveContainer width="100%" height={300}>
                  <BarChart data={idadeBens}>
                    <CartesianGrid strokeOpacity={0.1} vertical={false} />
                    <XAxis dataKey="faixa" stroke="hsl(var(--muted-foreground))" />
                    <YAxis stroke="hsl(var(--muted-foreground))" />
                    <Tooltip 
                      contentStyle={{ 
                        backgroundColor: 'hsl(var(--card))', 
                        border: '1px solid hsl(var(--border))',
                        borderRadius: '8px'
                      }}
                    />
                    <Bar dataKey="quantidade" radius={[4, 4, 0, 0]} />
                  </BarChart>
                </ResponsiveContainer>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="financeiro" className="space-y-4">
            <div className="grid gap-6 md:grid-cols-2">
              <Card className="border-border bg-card">
                <CardHeader>
                  <CardTitle className="text-foreground">Despesas vs Orçamento</CardTitle>
                  <CardDescription className="text-muted-foreground">
                    Comparativo mensal
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <ResponsiveContainer width="100%" height={300}>
                    <BarChart data={despesasOrcamento}>
                      <CartesianGrid strokeOpacity={0.1} vertical={false} />
                      <XAxis dataKey="mes" stroke="hsl(var(--muted-foreground))" />
                      <YAxis stroke="hsl(var(--muted-foreground))" />
                      <Tooltip 
                        contentStyle={{ 
                          backgroundColor: 'hsl(var(--card))', 
                          border: '1px solid hsl(var(--border))',
                          borderRadius: '8px'
                        }}
                        formatter={(value: number) => `R$ ${value.toLocaleString('pt-BR')}`}
                      />
                      <Legend />
                      <Bar dataKey="Despesas" fill="hsl(var(--primary))" radius={[4, 4, 0, 0]} />
                      <Bar dataKey="Orçamento" fill="hsl(var(--muted-foreground) / 0.4)" radius={[4, 4, 0, 0]} />
                    </BarChart>
                  </ResponsiveContainer>
                </CardContent>
              </Card>

              <Card className="border-border bg-card">
                <CardHeader>
                  <CardTitle className="text-foreground">Valor Total por Departamento</CardTitle>
                  <CardDescription className="text-muted-foreground">
                    Distribuição do investimento
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <ResponsiveContainer width="100%" height={300}>
                    <BarChart data={valorPorDepartamento}>
                      <CartesianGrid strokeOpacity={0.1} vertical={false} />
                      <XAxis dataKey="departamento" stroke="hsl(var(--muted-foreground))" />
                      <YAxis stroke="hsl(var(--muted-foreground))" />
                      <Tooltip 
                        contentStyle={{ 
                          backgroundColor: 'hsl(var(--card))', 
                          border: '1px solid hsl(var(--border))',
                          borderRadius: '8px'
                        }}
                        formatter={(value: number) => `R$ ${value.toLocaleString('pt-BR')}`}
                      />
                      <Bar dataKey="valor" radius={[4, 4, 0, 0]} />
                    </BarChart>
                  </ResponsiveContainer>
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          <TabsContent value="utilizacao" className="space-y-4">
            <div className="grid gap-6 md:grid-cols-2">
              <Card className="border-border bg-card">
                <CardHeader>
                  <CardTitle className="text-foreground">Taxa de Utilização por Tipo</CardTitle>
                  <CardDescription className="text-muted-foreground">
                    Percentual de uso dos bens
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <ResponsiveContainer width="100%" height={300}>
                    <BarChart data={taxaUtilizacaoPorTipo} layout="vertical">
                      <CartesianGrid strokeOpacity={0.1} horizontal={false} />
                      <XAxis 
                        type="number" 
                        domain={[0, 100]} 
                        stroke="hsl(var(--muted-foreground))"
                        tickFormatter={(value) => `${value}%`}
                      />
                      <YAxis 
                        dataKey="tipo" 
                        type="category" 
                        width={100} 
                        stroke="hsl(var(--muted-foreground))"
                      />
                      <Tooltip 
                        contentStyle={{ 
                          backgroundColor: 'hsl(var(--card))', 
                          border: '1px solid hsl(var(--border))',
                          borderRadius: '8px'
                        }}
                        formatter={(value: number, name: string, props: any) => [
                          `${value}% (${props.payload.unidades} unidades)`,
                          'Taxa de Utilização'
                        ]}
                      />
                      <Bar dataKey="taxa" fill="hsl(var(--primary))" radius={[0, 4, 4, 0]} />
                    </BarChart>
                  </ResponsiveContainer>
                </CardContent>
              </Card>

              <Card className="border-border bg-card">
                <CardHeader>
                  <CardTitle className="text-foreground">Conformidade de Inventário</CardTitle>
                  <CardDescription className="text-muted-foreground">
                    Precisão por departamento
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <ResponsiveContainer width="100%" height={300}>
                    <BarChart data={conformidadeInventario} layout="vertical">
                      <CartesianGrid strokeOpacity={0.1} horizontal={false} />
                      <XAxis 
                        type="number" 
                        domain={[0, 100]} 
                        stroke="hsl(var(--muted-foreground))"
                        tickFormatter={(value) => `${value}%`}
                      />
                      <YAxis 
                        dataKey="departamento" 
                        type="category" 
                        width={80} 
                        stroke="hsl(var(--muted-foreground))"
                      />
                      <Tooltip 
                        contentStyle={{ 
                          backgroundColor: 'hsl(var(--card))', 
                          border: '1px solid hsl(var(--border))',
                          borderRadius: '8px'
                        }}
                        formatter={(value: number) => [`${value}%`, 'Conformidade']}
                      />
                      <Bar dataKey="conformidade" radius={[0, 4, 4, 0]} />
                    </BarChart>
                  </ResponsiveContainer>
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          <TabsContent value="manutencao">
            <Card className="border-border bg-card">
              <CardHeader>
                <CardTitle className="text-foreground">Manutenções Preventivas vs Corretivas</CardTitle>
                <CardDescription className="text-muted-foreground">
                  Histórico mensal de manutenções
                </CardDescription>
              </CardHeader>
              <CardContent>
                <ResponsiveContainer width="100%" height={400}>
                  <BarChart data={manutencoesHistorico}>
                    <CartesianGrid strokeOpacity={0.1} vertical={false} />
                    <XAxis dataKey="mes" />
                    <YAxis />
                    <Tooltip />
                    <Legend />
                    <Bar dataKey="Preventivas" fill="hsl(var(--primary))" radius={[4, 4, 0, 0]} />
                    <Bar dataKey="Corretivas" fill="hsl(var(--destructive))" radius={[4, 4, 0, 0]} />
                  </BarChart>
                </ResponsiveContainer>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}
