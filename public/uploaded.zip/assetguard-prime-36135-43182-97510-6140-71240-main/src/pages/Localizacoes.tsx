import { useState, useRef } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Search, Filter, Download, Plus, Upload, Edit, Trash2 } from "lucide-react";
import { AddLocationDialog } from "@/components/AddLocationDialog";
import { AddSectorDialog } from "@/components/AddSectorDialog";
import { EditSectorDialog } from "@/components/EditSectorDialog";
import { AddRoomDialog } from "@/components/AddRoomDialog";
import { useData } from "@/contexts/DataContext";
import { exportToExcel, importFromExcel } from "@/lib/excelUtils";
import { toast } from "sonner";
import { useUserRole } from "@/hooks/useUserRole";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";

export default function Localizacoes() {
  const [isAddDialogOpen, setIsAddDialogOpen] = useState(false);
  const [isAddSectorDialogOpen, setIsAddSectorDialogOpen] = useState(false);
  const [isAddRoomDialogOpen, setIsAddRoomDialogOpen] = useState(false);
  const [showDeleteDialog, setShowDeleteDialog] = useState(false);
  const [selectedLocationId, setSelectedLocationId] = useState<string | null>(null);
  const [isDeleting, setIsDeleting] = useState(false);
  const [editingSector, setEditingSector] = useState<any>(null);
  const { locations, departments, assets, addDepartment, updateDepartment, deleteLocation } = useData();
  const { isAdmin } = useUserRole();
  const fileInputRef = useRef<HTMLInputElement>(null);
  
  const predios = locations.filter(l => l.type === "Prédio" || l.type === "Unidade");
  const setores = locations.filter(l => l.type === "Setor");
  const salas = locations.filter(l => l.type === "Sala");

  const handleExportLocations = () => {
    const exportData = locations.map(loc => ({
      'Nome': loc.name,
      'Tipo': loc.type,
      'Endereço': loc.address || '-',
      'Andares': loc.floors || '-',
      'Status': loc.status ? 'Ativo' : 'Inativo',
    }));
    exportToExcel(exportData, 'localizacoes');
    toast.success('Localizações exportadas com sucesso!');
  };

  const handleImportSectors = async (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (!file) return;

    try {
      const data = await importFromExcel(file, { header: 1, defval: '' });
      let importedCount = 0;
      
      console.log('Dados importados do Excel:', data);
      
      for (let i = 0; i < data.length; i++) {
        const row = data[i];
        
        // Skip completely empty rows
        if (!row || !Array.isArray(row) || row.every(cell => !cell && cell !== 0)) {
          console.log(`Linha ${i} pulada: vazia`);
          continue;
        }
        
        // Estrutura do Excel: [0]=QTD, [1]=CÓDIGO, [2]=SIGLA, [3]=DESCRIÇÃO, [4]=ENCARREGADO, [5]=ID_FUNC_ENC, [6]=SUBSTITUTO, [7]=ID_FUNC_SUB
        // Converter valores para null se estiverem vazios
        const parseString = (val: any) => val !== undefined && val !== '' && val !== null ? val.toString().trim() : null;
        const parseNumber = (val: any) => val !== undefined && val !== '' && val !== null ? parseInt(val.toString()) : null;
        
        const qtd = parseNumber(row[0]);
        const codigo = parseString(row[1]);
        const sigla = parseString(row[2]);
        const descricao = parseString(row[3]);
        const encarregado = parseString(row[4]);
        const idFuncEnc = parseString(row[5]);
        const substituto = parseString(row[6]);
        const idFuncSub = parseString(row[7]);
        
        // Skip if no meaningful data
        if (!sigla && !descricao && !codigo) {
          console.log(`Linha ${i} pulada: sem dados significativos`);
          continue;
        }
        
        const name = descricao || sigla || codigo || 'Sem nome';
        
        console.log(`Importando linha ${i}:`, {
          qtd, codigo, sigla, descricao, encarregado, idFuncEnc, substituto, idFuncSub
        });
        
        await addDepartment({
          name: name,
          qtd: qtd,
          codigo: codigo,
          sigla: sigla,
          encarregado: encarregado,
          id_funcional_encarregado: idFuncEnc,
          substituto: substituto,
          id_funcional_substituto: idFuncSub,
          location_id: null,
          responsible_id: null,
          created_at: new Date().toISOString(),
          updated_at: new Date().toISOString(),
        });
        importedCount++;
      }
      toast.success(`${importedCount} subunidades importadas com sucesso!`);
    } catch (error) {
      console.error('Erro ao importar:', error);
      toast.error('Erro ao importar arquivo Excel');
    }
    if (fileInputRef.current) {
      fileInputRef.current.value = '';
    }
  };

  const handleDeleteLocation = async () => {
    if (!selectedLocationId) return;
    
    setIsDeleting(true);
    try {
      await deleteLocation(selectedLocationId);
      toast.success('Localização excluída com sucesso!');
      setShowDeleteDialog(false);
      setSelectedLocationId(null);
    } catch (error) {
      toast.error('Erro ao excluir localização');
    } finally {
      setIsDeleting(false);
    }
  };

  return (
    <div className="min-h-screen bg-background p-8">
      <div className="mx-auto max-w-7xl space-y-6">
      <div>
          <h1 className="text-3xl font-bold text-foreground">Localizações</h1>
          <p className="mt-2 text-muted-foreground">
            Gerencie prédios, subunidades, salas e suas responsabilidades.
          </p>
        </div>

        <Tabs defaultValue="predios" className="space-y-6">
          <TabsList className="bg-secondary">
            <TabsTrigger value="predios">Prédio ({predios.length})</TabsTrigger>
            <TabsTrigger value="setores">Subunidades ({departments.length})</TabsTrigger>
            <TabsTrigger value="salas">Salas ({salas.length})</TabsTrigger>
            <TabsTrigger value="responsabilidades">Responsabilidades e Relatórios</TabsTrigger>
          </TabsList>

          <div className="flex items-center justify-between gap-4">
            <div className="flex gap-2 flex-1">
              <div className="relative max-w-sm flex-1">
                <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
                <Input
                  placeholder="Buscar localizações..."
                  className="pl-10 bg-secondary border-border"
                />
              </div>
              <Button variant="outline" className="gap-2">
                <Filter className="h-4 w-4" />
                Filtrar
              </Button>
            </div>
            <div className="flex gap-2">
              <Button 
                variant="outline" 
                className="gap-2"
                onClick={handleExportLocations}
              >
                <Download className="h-4 w-4" />
                Exportar
              </Button>
            </div>
          </div>

          <TabsContent value="predios">
            <div className="flex items-center justify-end gap-2 mb-4">
              <Button 
                className="gap-2 bg-primary text-primary-foreground hover:bg-primary/90"
                onClick={() => setIsAddDialogOpen(true)}
              >
                <Plus className="h-4 w-4" />
                Nova Localização
              </Button>
            </div>
            <Card className="border-border bg-card">
              <CardContent className="p-0">
                <div className="overflow-x-auto">
                  <table className="w-full">
                    <thead className="border-b border-border">
                      <tr>
                        <th className="px-6 py-4 text-left text-sm font-medium text-foreground">Nome</th>
                        <th className="px-6 py-4 text-left text-sm font-medium text-foreground">Endereço</th>
                        <th className="px-6 py-4 text-left text-sm font-medium text-foreground">Tipo</th>
                        <th className="px-6 py-4 text-left text-sm font-medium text-foreground">Andares</th>
                        <th className="px-6 py-4 text-left text-sm font-medium text-foreground">Salas</th>
                        <th className="px-6 py-4 text-left text-sm font-medium text-foreground">Bens</th>
                        <th className="px-6 py-4 text-left text-sm font-medium text-foreground">Status</th>
                        {isAdmin && (
                          <th className="px-6 py-4 text-left text-sm font-medium text-foreground">Ações</th>
                        )}
                      </tr>
                    </thead>
                    <tbody>
                      {predios.length === 0 ? (
                        <tr>
                          <td colSpan={isAdmin ? 8 : 7} className="px-6 py-12 text-center text-muted-foreground">
                            Nenhuma localização encontrada
                          </td>
                        </tr>
                      ) : (
                        predios.map((location) => (
                          <tr key={location.id} className="border-b border-border">
                            <td className="px-6 py-4 text-foreground">{location.name}</td>
                            <td className="px-6 py-4 text-muted-foreground">{location.address || "-"}</td>
                            <td className="px-6 py-4 text-muted-foreground">{location.type}</td>
                            <td className="px-6 py-4 text-muted-foreground">{location.floors || "-"}</td>
                            <td className="px-6 py-4 text-muted-foreground">-</td>
                            <td className="px-6 py-4 text-muted-foreground">-</td>
                            <td className="px-6 py-4">
                              <span className={`px-2 py-1 rounded text-xs ${location.status ? 'bg-green-500/10 text-green-500' : 'bg-red-500/10 text-red-500'}`}>
                                {location.status ? 'Ativo' : 'Inativo'}
                              </span>
                            </td>
                            {isAdmin && (
                              <td className="px-6 py-4">
                                <div className="flex gap-2">
                                  <Button
                                    variant="ghost"
                                    size="icon"
                                    className="h-8 w-8"
                                    onClick={() => {
                                      toast.info('Funcionalidade de edição em desenvolvimento');
                                    }}
                                  >
                                    <Edit className="h-4 w-4" />
                                  </Button>
                                  <Button
                                    variant="ghost"
                                    size="icon"
                                    className="h-8 w-8 text-destructive hover:text-destructive"
                                    onClick={() => {
                                      setSelectedLocationId(location.id);
                                      setShowDeleteDialog(true);
                                    }}
                                  >
                                    <Trash2 className="h-4 w-4" />
                                  </Button>
                                </div>
                              </td>
                            )}
                          </tr>
                        ))
                      )}
                    </tbody>
                  </table>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="setores">
            <div className="flex items-center justify-end gap-2 mb-4">
              <input
                ref={fileInputRef}
                type="file"
                accept=".xlsx,.xls"
                onChange={handleImportSectors}
                className="hidden"
              />
              <Button 
                variant="outline" 
                className="gap-2"
                onClick={() => fileInputRef.current?.click()}
              >
                <Upload className="h-4 w-4" />
                Importar Subunidades (Excel)
              </Button>
              <Button 
                className="gap-2 bg-primary text-primary-foreground hover:bg-primary/90"
                onClick={() => setIsAddSectorDialogOpen(true)}
              >
                <Plus className="h-4 w-4" />
                Nova Subunidade
              </Button>
            </div>
            <Card className="border-border bg-card">
              <CardContent className="p-0">
                <div className="overflow-x-auto">
                  <table className="w-full">
                    <thead className="border-b border-border">
                      <tr>
                        <th className="px-6 py-4 text-left text-sm font-medium text-foreground">QTD</th>
                        <th className="px-6 py-4 text-left text-sm font-medium text-foreground">CÓDIGO</th>
                        <th className="px-6 py-4 text-left text-sm font-medium text-foreground">SIGLA</th>
                        <th className="px-6 py-4 text-left text-sm font-medium text-foreground">DESCRIÇÃO</th>
                        <th className="px-6 py-4 text-left text-sm font-medium text-foreground">ENCARREGADO</th>
                        <th className="px-6 py-4 text-left text-sm font-medium text-foreground">ID FUNCIONAL (Enc.)</th>
                        <th className="px-6 py-4 text-left text-sm font-medium text-foreground">SUBSTITUTO</th>
                        <th className="px-6 py-4 text-left text-sm font-medium text-foreground">ID FUNCIONAL (Sub.)</th>
                        {isAdmin && (
                          <th className="px-6 py-4 text-left text-sm font-medium text-foreground">Ações</th>
                        )}
                      </tr>
                    </thead>
                    <tbody>
                      {departments.length === 0 ? (
                        <tr>
                          <td colSpan={9} className="px-6 py-12 text-center text-muted-foreground">
                            Nenhuma subunidade encontrada
                          </td>
                        </tr>
                      ) : (
                        departments.map((dept) => (
                          <tr key={dept.id} className="border-b border-border hover:bg-muted/50">
                            <td className="px-6 py-4 text-muted-foreground">{dept.qtd || "-"}</td>
                            <td className="px-6 py-4 text-muted-foreground">{dept.codigo || "-"}</td>
                            <td className="px-6 py-4 text-muted-foreground">{dept.sigla || "-"}</td>
                            <td className="px-6 py-4 text-foreground">{dept.name}</td>
                            <td className="px-6 py-4 text-muted-foreground">{dept.encarregado || "-"}</td>
                            <td className="px-6 py-4 text-muted-foreground">{dept.id_funcional_encarregado || "-"}</td>
                            <td className="px-6 py-4 text-muted-foreground">{dept.substituto || "-"}</td>
                            <td className="px-6 py-4 text-muted-foreground">{dept.id_funcional_substituto || "-"}</td>
                            {isAdmin && (
                              <td className="px-6 py-4">
                                <Button
                                  variant="ghost"
                                  size="icon"
                                  className="h-8 w-8"
                                  onClick={() => setEditingSector(dept)}
                                >
                                  <Edit className="h-4 w-4" />
                                </Button>
                              </td>
                            )}
                          </tr>
                        ))
                      )}
                    </tbody>
                  </table>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="salas">
            <div className="flex items-center justify-end gap-2 mb-4">
              <Button 
                variant="outline" 
                className="gap-2"
                onClick={() => {
                  const exportData = salas.map(sala => ({
                    'Nome': sala.name,
                    'Tipo': sala.type,
                    'Andar': sala.floors || '-',
                  }));
                  exportToExcel(exportData, 'salas');
                  toast.success('Salas exportadas com sucesso!');
                }}
              >
                <Download className="h-4 w-4" />
                Exportar
              </Button>
              <Button 
                className="gap-2 bg-primary text-primary-foreground hover:bg-primary/90"
                onClick={() => setIsAddRoomDialogOpen(true)}
              >
                <Plus className="h-4 w-4" />
                Nova Sala
              </Button>
            </div>
            <Card className="border-border bg-card">
              <CardContent className="p-0">
                <div className="overflow-x-auto">
                  <table className="w-full">
                    <thead className="border-b border-border">
                      <tr>
                        <th className="px-6 py-4 text-left text-sm font-medium text-foreground">ID</th>
                        <th className="px-6 py-4 text-left text-sm font-medium text-foreground">Nome</th>
                        <th className="px-6 py-4 text-left text-sm font-medium text-foreground">Localização</th>
                        <th className="px-6 py-4 text-left text-sm font-medium text-foreground">Setor</th>
                        <th className="px-6 py-4 text-left text-sm font-medium text-foreground">Andar</th>
                        <th className="px-6 py-4 text-left text-sm font-medium text-foreground">Tipo</th>
                        <th className="px-6 py-4 text-left text-sm font-medium text-foreground">Capacidade</th>
                        <th className="px-6 py-4 text-left text-sm font-medium text-foreground">Bens</th>
                      </tr>
                    </thead>
                    <tbody>
                      {salas.length === 0 ? (
                        <tr>
                          <td colSpan={8} className="px-6 py-12 text-center text-muted-foreground">
                            Nenhuma sala encontrada
                          </td>
                        </tr>
                      ) : (
                        salas.map((sala) => (
                          <tr key={sala.id} className="border-b border-border">
                            <td className="px-6 py-4 text-muted-foreground">{sala.id.slice(0, 8)}</td>
                            <td className="px-6 py-4 text-foreground">{sala.name}</td>
                            <td className="px-6 py-4 text-muted-foreground">-</td>
                            <td className="px-6 py-4 text-muted-foreground">-</td>
                            <td className="px-6 py-4 text-muted-foreground">{sala.floors || "-"}</td>
                            <td className="px-6 py-4 text-muted-foreground">-</td>
                            <td className="px-6 py-4 text-muted-foreground">-</td>
                            <td className="px-6 py-4 text-muted-foreground">-</td>
                          </tr>
                        ))
                      )}
                    </tbody>
                  </table>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="responsabilidades">
            <Card className="border-border bg-card">
              <CardContent className="pt-6 space-y-6">
                <div>
                  <h3 className="text-lg font-semibold text-foreground">
                    Relatório de Responsabilidade por Encarregado
                  </h3>
                  <p className="text-sm text-muted-foreground">
                    Veja quais subunidades estão sob responsabilidade de cada encarregado.
                  </p>
                </div>
                <div className="overflow-x-auto">
                  <table className="w-full">
                    <thead className="border-b border-border">
                      <tr>
                        <th className="px-6 py-4 text-left text-sm font-medium text-foreground">Encarregado</th>
                        <th className="px-6 py-4 text-left text-sm font-medium text-foreground">ID Funcional</th>
                        <th className="px-6 py-4 text-left text-sm font-medium text-foreground">Subunidade</th>
                        <th className="px-6 py-4 text-left text-sm font-medium text-foreground">Sigla</th>
                        <th className="px-6 py-4 text-left text-sm font-medium text-foreground">Substituto</th>
                        <th className="px-6 py-4 text-left text-sm font-medium text-foreground">ID Func. Substituto</th>
                      </tr>
                    </thead>
                    <tbody>
                      {departments.filter(d => d.encarregado).length === 0 ? (
                        <tr>
                          <td colSpan={6} className="px-6 py-12 text-center text-muted-foreground">
                            Nenhum encarregado cadastrado.
                          </td>
                        </tr>
                      ) : (
                        departments
                          .filter(d => d.encarregado)
                          .map((dept) => (
                            <tr key={dept.id} className="border-b border-border hover:bg-muted/50">
                              <td className="px-6 py-4 text-foreground font-medium">{dept.encarregado}</td>
                              <td className="px-6 py-4 text-muted-foreground">{dept.id_funcional_encarregado || '-'}</td>
                              <td className="px-6 py-4 text-foreground">{dept.name}</td>
                              <td className="px-6 py-4 text-muted-foreground">{dept.sigla || '-'}</td>
                              <td className="px-6 py-4 text-muted-foreground">{dept.substituto || '-'}</td>
                              <td className="px-6 py-4 text-muted-foreground">{dept.id_funcional_substituto || '-'}</td>
                            </tr>
                          ))
                      )}
                    </tbody>
                  </table>
                </div>
              </CardContent>
            </Card>

            <Card className="border-border bg-card mt-6">
              <CardContent className="pt-6 space-y-6">
                <div className="flex items-center justify-between">
                  <div>
                    <h3 className="text-lg font-semibold text-foreground">
                      Resumo de Bens por Subunidade
                    </h3>
                    <p className="text-sm text-muted-foreground">
                      Quantidade de bens atribuídos a cada subunidade.
                    </p>
                  </div>
                  <Button 
                    variant="outline" 
                    className="gap-2"
                    onClick={() => {
                      const reportData = departments.map(dept => {
                        const deptAssets = assets.filter(a => a.department_id === dept.id);
                        const totalValue = deptAssets.reduce((sum, a) => sum + Number(a.value), 0);
                        return {
                          'Subunidade': dept.name,
                          'Sigla': dept.sigla || '-',
                          'Encarregado': dept.encarregado || '-',
                          'Quantidade de Bens': deptAssets.length,
                          'Valor Total (R$)': totalValue.toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' }),
                        };
                      });
                      exportToExcel(reportData, 'relatorio-responsabilidades');
                      toast.success('Relatório exportado com sucesso!');
                    }}
                  >
                    <Download className="h-4 w-4" />
                    Exportar Relatório
                  </Button>
                </div>
                <div className="overflow-x-auto">
                  <table className="w-full">
                    <thead className="border-b border-border">
                      <tr>
                        <th className="px-6 py-4 text-left text-sm font-medium text-foreground">Subunidade</th>
                        <th className="px-6 py-4 text-left text-sm font-medium text-foreground">Sigla</th>
                        <th className="px-6 py-4 text-left text-sm font-medium text-foreground">Encarregado</th>
                        <th className="px-6 py-4 text-left text-sm font-medium text-foreground">Qtd. Bens</th>
                        <th className="px-6 py-4 text-left text-sm font-medium text-foreground">Valor Total</th>
                      </tr>
                    </thead>
                    <tbody>
                      {departments.map((dept) => {
                        const deptAssets = assets.filter(a => a.department_id === dept.id);
                        const totalValue = deptAssets.reduce((sum, a) => sum + Number(a.value), 0);
                        return (
                          <tr key={dept.id} className="border-b border-border hover:bg-muted/50">
                            <td className="px-6 py-4 text-foreground">{dept.name}</td>
                            <td className="px-6 py-4 text-muted-foreground">{dept.sigla || '-'}</td>
                            <td className="px-6 py-4 text-muted-foreground">{dept.encarregado || '-'}</td>
                            <td className="px-6 py-4 text-foreground font-medium">{deptAssets.length}</td>
                            <td className="px-6 py-4 text-foreground">
                              {totalValue.toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' })}
                            </td>
                          </tr>
                        );
                      })}
                    </tbody>
                  </table>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
        
        <AddLocationDialog open={isAddDialogOpen} onOpenChange={setIsAddDialogOpen} />
        <AddSectorDialog open={isAddSectorDialogOpen} onOpenChange={setIsAddSectorDialogOpen} />
        <EditSectorDialog
          open={!!editingSector}
          onOpenChange={(open) => !open && setEditingSector(null)}
          sector={editingSector}
        />
        <AddRoomDialog open={isAddRoomDialogOpen} onOpenChange={setIsAddRoomDialogOpen} />
        
        <AlertDialog open={showDeleteDialog} onOpenChange={setShowDeleteDialog}>
          <AlertDialogContent>
            <AlertDialogHeader>
              <AlertDialogTitle>Confirmar exclusão</AlertDialogTitle>
              <AlertDialogDescription>
                Tem certeza que deseja excluir esta localização? Esta ação não pode ser desfeita.
              </AlertDialogDescription>
            </AlertDialogHeader>
            <AlertDialogFooter>
              <AlertDialogCancel disabled={isDeleting}>Cancelar</AlertDialogCancel>
              <AlertDialogAction
                onClick={handleDeleteLocation}
                disabled={isDeleting}
                className="bg-destructive text-destructive-foreground hover:bg-destructive/90"
              >
                {isDeleting ? "Excluindo..." : "Excluir"}
              </AlertDialogAction>
            </AlertDialogFooter>
          </AlertDialogContent>
        </AlertDialog>
      </div>
    </div>
  );
}
