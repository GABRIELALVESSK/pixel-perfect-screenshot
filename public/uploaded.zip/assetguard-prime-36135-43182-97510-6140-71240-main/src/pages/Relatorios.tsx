import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Checkbox } from "@/components/ui/checkbox";
import { Filter, FileDown, ChevronDown } from "lucide-react";
import { useState } from "react";
import { useData } from "@/contexts/DataContext";
import { exportToExcel } from "@/lib/excelUtils";
import { toast } from "sonner";

export default function Relatorios() {
  const [selectedCount, setSelectedCount] = useState(0);
  const [locationFilter, setLocationFilter] = useState("todas");
  const [statusFilter, setStatusFilter] = useState("todos");
  const [categoryFilter, setCategoryFilter] = useState("todas");
  const [searchTerm, setSearchTerm] = useState("");
  const { assets, locations, departments } = useData();

  // Filtrar os ativos baseado nos filtros selecionados
  const filteredAssets = assets.filter(asset => {
    const matchesLocation = locationFilter === "todas" || asset.location_id === locationFilter;
    const matchesStatus = statusFilter === "todos" || asset.status === statusFilter;
    const matchesCategory = categoryFilter === "todas" || asset.category_id === categoryFilter;
    const matchesSearch = searchTerm === "" || 
      asset.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      asset.inventory_number.toLowerCase().includes(searchTerm.toLowerCase());
    
    return matchesLocation && matchesStatus && matchesCategory && matchesSearch;
  });

  const handleExport = () => {
    const exportData = assets.map(asset => ({
      'Nome': asset.name,
      'Nº Inventário': asset.inventory_number,
      'Categoria': asset.category_id || '-',
      'Status': asset.status,
      'Localização': asset.location_id || '-',
      'Departamento': asset.department_id || '-',
      'Valor (R$)': asset.value,
      'Data de Aquisição': new Date(asset.acquisition_date).toLocaleDateString('pt-BR'),
      'Data de Início': asset.start_use_date ? new Date(asset.start_use_date).toLocaleDateString('pt-BR') : '-',
    }));
    exportToExcel(exportData, 'relatorio-ativos');
    toast.success('Relatório exportado com sucesso!');
  };

  return (
    <div className="min-h-screen bg-background p-8">
      <div className="mx-auto max-w-7xl space-y-6">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-3xl font-bold text-foreground">Relatórios de Ativos</h1>
            <p className="mt-2 text-muted-foreground">
              Gere relatórios customizados e exporte dados para análise.
            </p>
          </div>
          <div className="flex gap-3">
            <Button variant="outline" className="border-border">
              <Filter className="mr-2 h-4 w-4" />
              Aplicar Filtros
            </Button>
            <Button 
              className="bg-info hover:bg-info/90 text-info-foreground"
              onClick={handleExport}
            >
              <FileDown className="mr-2 h-4 w-4" />
              Exportar para Excel
            </Button>
          </div>
        </div>

        <Card className="border-border bg-card">
          <CardHeader>
            <CardTitle className="text-xl">Filtros de Relatório</CardTitle>
            <p className="text-sm text-muted-foreground">
              Selecione os filtros para customizar seu relatório.
            </p>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 gap-4 md:grid-cols-3">
              <div className="space-y-2">
                <label className="text-sm font-medium text-foreground">Localização</label>
                <Select defaultValue="todas">
                  <SelectTrigger className="bg-background border-border">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="todas">Todas</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-2">
                <label className="text-sm font-medium text-foreground">Status</label>
                <Select defaultValue="todos">
                  <SelectTrigger className="bg-background border-border">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="todos">Todos</SelectItem>
                    <SelectItem value="ativo">Ativo</SelectItem>
                    <SelectItem value="inativo">Inativo</SelectItem>
                    <SelectItem value="manutencao">Manutenção</SelectItem>
                    <SelectItem value="descartado">Descartado</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-2">
                <label className="text-sm font-medium text-foreground">Categoria</label>
                <Select defaultValue="todas">
                  <SelectTrigger className="bg-background border-border">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="todas">Todas</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </div>
      </CardContent>
        </Card>

        <Card className="border-border bg-card">
          <CardHeader>
            <CardTitle className="text-xl">Visualização de Dados</CardTitle>
            <p className="text-sm text-muted-foreground">
              Dados dos ativos baseados nos filtros aplicados.
            </p>
          </CardHeader>
          <CardContent className="space-y-6">
            {/* Filtros na seção de Visualização */}
            <div className="space-y-4">
              <div className="grid grid-cols-1 gap-4 md:grid-cols-3">
                <div className="space-y-2">
                  <label className="text-sm font-medium text-foreground">Localização</label>
                  <Select value={locationFilter} onValueChange={setLocationFilter}>
                    <SelectTrigger className="bg-background border-border">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent className="bg-popover border-border z-50">
                      <SelectItem value="todas">Todas</SelectItem>
                      {locations.map(location => (
                        <SelectItem key={location.id} value={location.id}>
                          {location.name}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
                <div className="space-y-2">
                  <label className="text-sm font-medium text-foreground">Status</label>
                  <Select value={statusFilter} onValueChange={setStatusFilter}>
                    <SelectTrigger className="bg-background border-border">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent className="bg-popover border-border z-50">
                      <SelectItem value="todos">Todos</SelectItem>
                      <SelectItem value="Ativo">Ativo</SelectItem>
                      <SelectItem value="Inativo">Inativo</SelectItem>
                      <SelectItem value="Manutenção">Manutenção</SelectItem>
                      <SelectItem value="Descartado">Descartado</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div className="space-y-2">
                  <label className="text-sm font-medium text-foreground">Categoria</label>
                  <Select value={categoryFilter} onValueChange={setCategoryFilter}>
                    <SelectTrigger className="bg-background border-border">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent className="bg-popover border-border z-50">
                      <SelectItem value="todas">Todas</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>
              <Button className="w-full md:w-auto bg-primary hover:bg-primary/90">
                <Filter className="mr-2 h-4 w-4" />
                Aplicar Filtros na Visualização
              </Button>
            </div>

            {/* Barra de pesquisa e colunas */}
            <div className="flex items-center gap-4">
              <Input 
                placeholder="Filtrar por nome..." 
                className="max-w-xs bg-background border-border"
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
              />
              <Button variant="outline" className="ml-auto border-border">
                Colunas
                <ChevronDown className="ml-2 h-4 w-4" />
              </Button>
            </div>

            <div className="rounded-md border border-border">
              <Table>
                <TableHeader>
                  <TableRow className="border-border hover:bg-transparent">
                    <TableHead className="w-12">
                      <Checkbox />
                    </TableHead>
                    <TableHead>Nome</TableHead>
                    <TableHead>Nº Inventário</TableHead>
                    <TableHead>Categoria</TableHead>
                    <TableHead>Status</TableHead>
                    <TableHead>Localização</TableHead>
                    <TableHead>Departamento</TableHead>
                    <TableHead>Valor (R$)</TableHead>
                    <TableHead>Data de Aquisição</TableHead>
                    <TableHead>Data de Início de Uso</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {filteredAssets.length === 0 ? (
                    <TableRow>
                      <TableCell colSpan={10} className="h-[400px] text-center text-muted-foreground">
                        Nenhum ativo encontrado.
                      </TableCell>
                    </TableRow>
                  ) : (
                    filteredAssets.map((asset) => (
                      <TableRow key={asset.id} className="border-border">
                        <TableCell>
                          <Checkbox />
                        </TableCell>
                        <TableCell className="font-medium">{asset.name}</TableCell>
                        <TableCell>{asset.inventory_number}</TableCell>
                        <TableCell>{asset.category_id || '-'}</TableCell>
                        <TableCell>
                          <span className={`inline-flex items-center rounded-full px-2.5 py-0.5 text-xs font-medium ${
                            asset.status === 'Ativo' ? 'bg-success/10 text-success' :
                            asset.status === 'Inativo' ? 'bg-muted text-muted-foreground' :
                            asset.status === 'Manutenção' ? 'bg-warning/10 text-warning' :
                            'bg-destructive/10 text-destructive'
                          }`}>
                            {asset.status}
                          </span>
                        </TableCell>
                        <TableCell>
                          {locations.find(l => l.id === asset.location_id)?.name || '-'}
                        </TableCell>
                        <TableCell>
                          {departments.find(d => d.id === asset.department_id)?.name || '-'}
                        </TableCell>
                        <TableCell>
                          {Number(asset.value).toLocaleString('pt-BR', { 
                            style: 'currency', 
                            currency: 'BRL' 
                          })}
                        </TableCell>
                        <TableCell>
                          {new Date(asset.acquisition_date).toLocaleDateString('pt-BR')}
                        </TableCell>
                        <TableCell>
                          {asset.start_use_date 
                            ? new Date(asset.start_use_date).toLocaleDateString('pt-BR') 
                            : '-'}
                        </TableCell>
                      </TableRow>
                    ))
                  )}
                </TableBody>
              </Table>
            </div>

            <div className="flex items-center justify-between">
              <p className="text-sm text-muted-foreground">
                {selectedCount} de {filteredAssets.length} linha(s) selecionadas.
              </p>
              <div className="flex gap-2">
                <Button variant="outline" size="sm" className="border-border">
                  Anterior
                </Button>
                <Button variant="outline" size="sm" className="border-border">
                  Próxima
                </Button>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
