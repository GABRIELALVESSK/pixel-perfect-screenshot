import { createContext, useContext, useState, useEffect, ReactNode } from "react";
import { createClient } from "@supabase/supabase-js";
import { toast } from 'sonner';
import { 
  assetSchema, 
  locationSchema, 
  departmentSchema,
  transferSchema,
  inventorySchema,
  discrepancySchema 
} from '@/lib/validationSchemas';
import { z } from 'zod';

const SUPABASE_URL = import.meta.env.VITE_SUPABASE_URL;
const SUPABASE_PUBLISHABLE_KEY = import.meta.env.VITE_SUPABASE_PUBLISHABLE_KEY;

const supabase = createClient(SUPABASE_URL, SUPABASE_PUBLISHABLE_KEY, {
  auth: {
    storage: localStorage,
    persistSession: true,
    autoRefreshToken: true,
  }
});

export interface User {
  id: string;
  name: string;
  email: string;
  avatar?: string;
}

export interface Location {
  id: string;
  name: string;
  address?: string;
  type: string;
  floors?: number;
  parent?: string;
  status: boolean;
  created_at: string;
  updated_at: string;
}

export interface Asset {
  id: string;
  name: string;
  description?: string;
  inventory_number: string;
  category_id?: string;
  location_id?: string;
  department_id?: string;
  responsible_id?: string;
  value: number;
  status: string;
  acquisition_date: string;
  start_use_date?: string;
  notes?: string;
  custom_depreciation: boolean;
  created_at: string;
  updated_at: string;
  asset_categories?: { name: string };
  locations?: { name: string };
  departments?: { name: string };
}

export interface Inventory {
  id: string;
  name: string;
  start_date: string;
  end_date?: string;
  status: string;
  responsible_id?: string;
  progress: number;
  created_at: string;
  updated_at: string;
}

export interface Discrepancy {
  id: string;
  inventory_id: string;
  asset_id: string;
  expected_location_id?: string;
  actual_location_id?: string;
  date: string;
  status: string;
  notes?: string;
  created_at: string;
  updated_at: string;
}

export interface Transfer {
  id: string;
  asset_id: string;
  from_location_id?: string;
  to_location_id?: string;
  from_department_id?: string;
  to_department_id?: string;
  date: string;
  responsible_id?: string;
  requester_id?: string;
  origin_approved_at?: string;
  origin_approved_by?: string;
  destination_approved_at?: string;
  destination_approved_by?: string;
  status: string;
  notes?: string;
  created_at: string;
  updated_at: string;
}

export interface Department {
  id: string;
  name: string;
  location_id?: string;
  responsible_id?: string;
  qtd?: number;
  codigo?: string;
  sigla?: string;
  encarregado?: string;
  id_funcional_encarregado?: string;
  substituto?: string;
  id_funcional_substituto?: string;
  created_at: string;
  updated_at: string;
}

export interface Category {
  id: string;
  name: string;
  created_at: string;
}

interface DataContextType {
  users: User[];
  locations: Location[];
  assets: Asset[];
  inventories: Inventory[];
  discrepancies: Discrepancy[];
  transfers: Transfer[];
  departments: Department[];
  categories: Category[];
  addUser: (user: Omit<User, "id">) => void;
  updateUser: (id: string, user: Partial<User>) => void;
  deleteUser: (id: string) => void;
  addLocation: (location: Omit<Location, "id" | "created_at" | "updated_at">) => void;
  updateLocation: (id: string, location: Partial<Location>) => void;
  deleteLocation: (id: string) => void;
  addAsset: (asset: Omit<Asset, "id">) => void;
  updateAsset: (id: string, asset: Partial<Asset>) => void;
  deleteAsset: (id: string) => void;
  addInventory: (inventory: Omit<Inventory, "id">) => void;
  updateInventory: (id: string, inventory: Partial<Inventory>) => void;
  deleteInventory: (id: string) => void;
  addDiscrepancy: (discrepancy: Omit<Discrepancy, "id">) => void;
  updateDiscrepancy: (id: string, discrepancy: Partial<Discrepancy>) => void;
  deleteDiscrepancy: (id: string) => void;
  addTransfer: (transfer: Omit<Transfer, "id">) => void;
  updateTransfer: (id: string, transfer: Partial<Transfer>) => void;
  deleteTransfer: (id: string) => void;
  addDepartment: (department: Omit<Department, "id">) => void;
  updateDepartment: (id: string, department: Partial<Department>) => void;
  deleteDepartment: (id: string) => void;
  refreshTransfers: () => void;
  refreshAssets: () => void;
}

const DataContext = createContext<DataContextType | undefined>(undefined);

export function DataProvider({ children }: { children: ReactNode }) {
  const [users, setUsers] = useState<User[]>([]);
  const [locations, setLocations] = useState<Location[]>([]);
  const [assets, setAssets] = useState<Asset[]>([]);
  const [inventories, setInventories] = useState<Inventory[]>([]);
  const [discrepancies, setDiscrepancies] = useState<Discrepancy[]>([]);
  const [transfers, setTransfers] = useState<Transfer[]>([]);
  const [departments, setDepartments] = useState<Department[]>([]);
  const [categories, setCategories] = useState<Category[]>([]);

  useEffect(() => {
    loadUsers();
    loadLocations();
    loadAssets();
    loadInventories();
    loadDiscrepancies();
    loadTransfers();
    loadDepartments();
    loadCategories();

    // Configurar canais de atualização em tempo real para todas as tabelas
    const usersChannel = supabase
      .channel('users-changes')
      .on('postgres_changes', { event: '*', schema: 'public', table: 'profiles' }, () => {
        console.log('Atualização em tempo real: profiles');
        loadUsers();
      })
      .subscribe();

    const categoriesChannel = supabase
      .channel('categories-changes')
      .on('postgres_changes', { event: '*', schema: 'public', table: 'asset_categories' }, () => {
        console.log('Atualização em tempo real: asset_categories');
        loadCategories();
      })
      .subscribe();

    const assetsChannel = supabase
      .channel('assets-changes')
      .on('postgres_changes', { event: '*', schema: 'public', table: 'assets' }, () => {
        console.log('Atualização em tempo real: assets');
        loadAssets();
      })
      .subscribe();

    const locationsChannel = supabase
      .channel('locations-changes')
      .on('postgres_changes', { event: '*', schema: 'public', table: 'locations' }, () => {
        console.log('Atualização em tempo real: locations');
        loadLocations();
      })
      .subscribe();

    const transfersChannel = supabase
      .channel('transfers-changes')
      .on('postgres_changes', { event: '*', schema: 'public', table: 'transfers' }, () => {
        console.log('Atualização em tempo real: transfers');
        loadTransfers();
      })
      .subscribe();

    const departmentsChannel = supabase
      .channel('departments-changes')
      .on('postgres_changes', { event: '*', schema: 'public', table: 'departments' }, () => {
        console.log('Atualização em tempo real: departments');
        loadDepartments();
      })
      .subscribe();

    const inventoriesChannel = supabase
      .channel('inventories-changes')
      .on('postgres_changes', { event: '*', schema: 'public', table: 'inventories' }, () => {
        console.log('Atualização em tempo real: inventories');
        loadInventories();
      })
      .subscribe();

    const discrepanciesChannel = supabase
      .channel('discrepancies-changes')
      .on('postgres_changes', { event: '*', schema: 'public', table: 'discrepancies' }, () => {
        console.log('Atualização em tempo real: discrepancies');
        loadDiscrepancies();
      })
      .subscribe();

    return () => {
      supabase.removeChannel(usersChannel);
      supabase.removeChannel(categoriesChannel);
      supabase.removeChannel(assetsChannel);
      supabase.removeChannel(locationsChannel);
      supabase.removeChannel(transfersChannel);
      supabase.removeChannel(departmentsChannel);
      supabase.removeChannel(inventoriesChannel);
      supabase.removeChannel(discrepanciesChannel);
    };
  }, []);

  const loadUsers = async () => {
    try {
      console.log('Carregando usuários...');
      const { data, error } = await (supabase.from("profiles") as any).select("*");
      if (error) {
        console.error("Erro ao carregar usuários:", error);
        toast.error("Erro ao carregar usuários do banco de dados");
        return;
      }
      if (data) {
        setUsers(data as User[]);
        console.log(`${data.length} usuários carregados com sucesso`);
      }
    } catch (error) {
      console.error("Erro inesperado ao carregar usuários:", error);
      toast.error("Erro de conexão ao carregar usuários");
    }
  };

  const loadLocations = async () => {
    try {
      console.log('Carregando localizações...');
      const { data, error } = await (supabase.from("locations") as any).select("*");
      if (error) {
        console.error("Erro ao carregar localizações:", error);
        toast.error("Erro ao carregar localizações do banco de dados");
        return;
      }
      if (data) {
        setLocations(data as Location[]);
        console.log(`${data.length} localizações carregadas com sucesso`);
      }
    } catch (error) {
      console.error("Erro inesperado ao carregar localizações:", error);
      toast.error("Erro de conexão ao carregar localizações");
    }
  };

  const loadAssets = async () => {
    try {
      console.log('Carregando ativos...');
      const { data, error } = await (supabase.from("assets") as any).select(`
        *,
        asset_categories (name),
        locations (name),
        departments (name)
      `);
      if (error) {
        console.error("Erro ao carregar ativos:", error);
        toast.error("Erro ao carregar ativos do banco de dados");
        return;
      }
      if (data) {
        setAssets(data as Asset[]);
        console.log(`${data.length} ativos carregados com sucesso`);
      }
    } catch (error) {
      console.error("Erro inesperado ao carregar ativos:", error);
      toast.error("Erro de conexão ao carregar ativos");
    }
  };

  const loadInventories = async () => {
    try {
      console.log('Carregando inventários...');
      const { data, error } = await (supabase.from("inventories") as any).select("*");
      if (error) {
        console.error("Erro ao carregar inventários:", error);
        toast.error("Erro ao carregar inventários do banco de dados");
        return;
      }
      if (data) {
        setInventories(data as Inventory[]);
        console.log(`${data.length} inventários carregados com sucesso`);
      }
    } catch (error) {
      console.error("Erro inesperado ao carregar inventários:", error);
      toast.error("Erro de conexão ao carregar inventários");
    }
  };

  const loadDiscrepancies = async () => {
    try {
      console.log('Carregando discrepâncias...');
      const { data, error } = await (supabase.from("discrepancies") as any).select("*");
      if (error) {
        console.error("Erro ao carregar discrepâncias:", error);
        toast.error("Erro ao carregar discrepâncias do banco de dados");
        return;
      }
      if (data) {
        setDiscrepancies(data as Discrepancy[]);
        console.log(`${data.length} discrepâncias carregadas com sucesso`);
      }
    } catch (error) {
      console.error("Erro inesperado ao carregar discrepâncias:", error);
      toast.error("Erro de conexão ao carregar discrepâncias");
    }
  };

  const loadTransfers = async () => {
    try {
      console.log('Carregando transferências...');
      const { data, error } = await (supabase.from("transfers") as any).select("*");
      if (error) {
        console.error("Erro ao carregar transferências:", error);
        toast.error("Erro ao carregar transferências do banco de dados");
        return;
      }
      if (data) {
        setTransfers(data as Transfer[]);
        console.log(`${data.length} transferências carregadas com sucesso`);
      }
    } catch (error) {
      console.error("Erro inesperado ao carregar transferências:", error);
      toast.error("Erro de conexão ao carregar transferências");
    }
  };

  const loadDepartments = async () => {
    try {
      console.log('Carregando departamentos...');
      const { data, error } = await (supabase.from("departments") as any).select("*");
      if (error) {
        console.error("Erro ao carregar departamentos:", error);
        toast.error("Erro ao carregar departamentos do banco de dados");
        return;
      }
      if (data) {
        setDepartments(data as Department[]);
        console.log(`${data.length} departamentos carregados com sucesso`);
      }
    } catch (error) {
      console.error("Erro inesperado ao carregar departamentos:", error);
      toast.error("Erro de conexão ao carregar departamentos");
    }
  };

  const loadCategories = async () => {
    try {
      console.log('Carregando categorias...');
      const { data, error } = await (supabase.from("asset_categories") as any).select("*");
      if (error) {
        console.error("Erro ao carregar categorias:", error);
        toast.error("Erro ao carregar categorias do banco de dados");
        return;
      }
      if (data) {
        setCategories(data as Category[]);
        console.log(`${data.length} categorias carregadas com sucesso`);
      }
    } catch (error) {
      console.error("Erro inesperado ao carregar categorias:", error);
      toast.error("Erro de conexão ao carregar categorias");
    }
  };

  const addUser = async (user: Omit<User, "id">) => {
    const { data, error } = await (supabase.from("profiles") as any).insert([user]).select();
    if (error) throw error;
    if (data) setUsers([...users, data[0] as User]);
  };

  const updateUser = async (id: string, userData: Partial<User>) => {
    const { error } = await (supabase.from("profiles") as any).update(userData).eq("id", id);
    if (error) throw error;
    setUsers(users.map(u => u.id === id ? { ...u, ...userData } : u));
  };

  const deleteUser = async (id: string) => {
    const { error } = await (supabase.from("profiles") as any).delete().eq("id", id);
    if (error) throw error;
    setUsers(users.filter(u => u.id !== id));
  };

  const addLocation = async (location: Omit<Location, "id" | "created_at" | "updated_at">) => {
    try {
      const validatedLocation = locationSchema.parse(location);
      const { data, error } = await (supabase.from("locations") as any).insert([validatedLocation]).select();
      if (error) {
        console.error("Error adding location:", error);
        toast.error("Erro ao adicionar localização");
        throw error;
      }
      if (data) {
        const newLocation = data[0] as Location;
        setLocations([...locations, newLocation]);
        toast.success("Localização adicionada com sucesso!");
      }
    } catch (error) {
      if (error instanceof z.ZodError) {
        toast.error(error.errors[0].message);
        throw error;
      }
      throw error;
    }
  };

  const updateLocation = async (id: string, locationData: Partial<Location>) => {
    try {
      const validatedUpdates = locationSchema.partial().parse(locationData);
      const { error } = await (supabase.from("locations") as any).update(validatedUpdates).eq("id", id);
      if (error) {
        console.error("Error updating location:", error);
        toast.error("Erro ao atualizar localização");
        throw error;
      }
      setLocations(locations.map(l => l.id === id ? { ...l, ...validatedUpdates } : l));
      toast.success("Localização atualizada com sucesso!");
    } catch (error) {
      if (error instanceof z.ZodError) {
        toast.error(error.errors[0].message);
        throw error;
      }
      throw error;
    }
  };

  const deleteLocation = async (id: string) => {
    const { error } = await (supabase.from("locations") as any).delete().eq("id", id);
    if (error) throw error;
    setLocations(locations.filter(l => l.id !== id));
  };

  const addAsset = async (asset: Omit<Asset, "id">) => {
    try {
      const validatedAsset = assetSchema.parse(asset);
      const { data, error } = await (supabase.from("assets") as any).insert([validatedAsset]).select();
      if (error) {
        console.error("Error adding asset:", error);
        toast.error("Erro ao adicionar ativo");
        throw error;
      }
      if (data) {
        const newAsset = data[0] as Asset;
        setAssets([...assets, newAsset]);
        toast.success("Ativo adicionado com sucesso!");
      }
    } catch (error) {
      if (error instanceof z.ZodError) {
        toast.error(error.errors[0].message);
        throw error;
      }
      throw error;
    }
  };

  const updateAsset = async (id: string, assetData: Partial<Asset>) => {
    try {
      const validatedUpdates = assetSchema.partial().parse(assetData);
      const { error } = await (supabase.from("assets") as any).update(validatedUpdates).eq("id", id);
      if (error) {
        console.error("Error updating asset:", error);
        toast.error("Erro ao atualizar ativo");
        throw error;
      }
      setAssets(assets.map(a => a.id === id ? { ...a, ...validatedUpdates } : a));
      toast.success("Ativo atualizado com sucesso!");
    } catch (error) {
      if (error instanceof z.ZodError) {
        toast.error(error.errors[0].message);
        throw error;
      }
      throw error;
    }
  };

  const deleteAsset = async (id: string) => {
    const { error } = await (supabase.from("assets") as any).delete().eq("id", id);
    if (error) throw error;
    setAssets(assets.filter(a => a.id !== id));
  };

  const addInventory = async (inventory: Omit<Inventory, "id">) => {
    try {
      const validatedInventory = inventorySchema.parse(inventory);
      const { data, error } = await (supabase.from("inventories") as any).insert([validatedInventory]).select();
      if (error) {
        console.error("Error adding inventory:", error);
        toast.error("Erro ao adicionar inventário");
        throw error;
      }
      if (data) {
        const newInventory = data[0] as Inventory;
        setInventories([...inventories, newInventory]);
        toast.success("Inventário adicionado com sucesso!");
      }
    } catch (error) {
      if (error instanceof z.ZodError) {
        toast.error(error.errors[0].message);
        throw error;
      }
      throw error;
    }
  };

  const updateInventory = async (id: string, inventoryData: Partial<Inventory>) => {
    try {
      const validatedUpdates = inventorySchema.partial().parse(inventoryData);
      const { error } = await (supabase.from("inventories") as any).update(validatedUpdates).eq("id", id);
      if (error) {
        console.error("Error updating inventory:", error);
        toast.error("Erro ao atualizar inventário");
        throw error;
      }
      setInventories(inventories.map(i => i.id === id ? { ...i, ...validatedUpdates } : i));
      toast.success("Inventário atualizado com sucesso!");
    } catch (error) {
      if (error instanceof z.ZodError) {
        toast.error(error.errors[0].message);
        throw error;
      }
      throw error;
    }
  };

  const deleteInventory = async (id: string) => {
    const { error } = await (supabase.from("inventories") as any).delete().eq("id", id);
    if (error) throw error;
    setInventories(inventories.filter(i => i.id !== id));
  };

  const addDiscrepancy = async (discrepancy: Omit<Discrepancy, "id">) => {
    try {
      const validatedDiscrepancy = discrepancySchema.parse(discrepancy);
      const { data, error } = await (supabase.from("discrepancies") as any).insert([validatedDiscrepancy]).select();
      if (error) {
        console.error("Error adding discrepancy:", error);
        toast.error("Erro ao adicionar discrepância");
        throw error;
      }
      if (data) {
        const newDiscrepancy = data[0] as Discrepancy;
        setDiscrepancies([...discrepancies, newDiscrepancy]);
        toast.success("Discrepância adicionada com sucesso!");
      }
    } catch (error) {
      if (error instanceof z.ZodError) {
        toast.error(error.errors[0].message);
        throw error;
      }
      throw error;
    }
  };

  const updateDiscrepancy = async (id: string, discrepancyData: Partial<Discrepancy>) => {
    try {
      const validatedUpdates = discrepancySchema.partial().parse(discrepancyData);
      const { error } = await (supabase.from("discrepancies") as any).update(validatedUpdates).eq("id", id);
      if (error) {
        console.error("Error updating discrepancy:", error);
        toast.error("Erro ao atualizar discrepância");
        throw error;
      }
      setDiscrepancies(discrepancies.map(d => d.id === id ? { ...d, ...validatedUpdates } : d));
      toast.success("Discrepância atualizada com sucesso!");
    } catch (error) {
      if (error instanceof z.ZodError) {
        toast.error(error.errors[0].message);
        throw error;
      }
      throw error;
    }
  };

  const deleteDiscrepancy = async (id: string) => {
    const { error } = await (supabase.from("discrepancies") as any).delete().eq("id", id);
    if (error) throw error;
    setDiscrepancies(discrepancies.filter(d => d.id !== id));
  };

  const addTransfer = async (transfer: Omit<Transfer, "id">) => {
    try {
      const validatedTransfer = transferSchema.parse(transfer);
      const { data, error } = await (supabase.from("transfers") as any).insert([validatedTransfer]).select();
      if (error) {
        console.error("Error adding transfer:", error);
        toast.error("Erro ao adicionar transferência");
        throw error;
      }
      if (data) {
        const newTransfer = data[0] as Transfer;
        setTransfers([...transfers, newTransfer]);
        toast.success("Transferência adicionada com sucesso!");
      }
    } catch (error) {
      if (error instanceof z.ZodError) {
        toast.error(error.errors[0].message);
        throw error;
      }
      throw error;
    }
  };

  const updateTransfer = async (id: string, transferData: Partial<Transfer>) => {
    try {
      const validatedUpdates = transferSchema.partial().parse(transferData);
      const { error } = await (supabase.from("transfers") as any).update(validatedUpdates).eq("id", id);
      if (error) {
        console.error("Error updating transfer:", error);
        toast.error("Erro ao atualizar transferência");
        throw error;
      }
      setTransfers(transfers.map(t => t.id === id ? { ...t, ...validatedUpdates } : t));
      toast.success("Transferência atualizada com sucesso!");
    } catch (error) {
      if (error instanceof z.ZodError) {
        toast.error(error.errors[0].message);
        throw error;
      }
      throw error;
    }
  };

  const deleteTransfer = async (id: string) => {
    const { error } = await (supabase.from("transfers") as any).delete().eq("id", id);
    if (error) throw error;
    setTransfers(transfers.filter(t => t.id !== id));
  };

  const addDepartment = async (department: Omit<Department, "id">) => {
    try {
      const validatedDepartment = departmentSchema.parse(department);
      const { data, error } = await (supabase.from("departments") as any).insert([validatedDepartment]).select();
      if (error) {
        console.error("Error adding department:", error);
        toast.error("Erro ao adicionar departamento");
        throw error;
      }
      if (data) {
        const newDepartment = data[0] as Department;
        setDepartments([...departments, newDepartment]);
        toast.success("Departamento adicionado com sucesso!");
      }
    } catch (error) {
      if (error instanceof z.ZodError) {
        toast.error(error.errors[0].message);
        throw error;
      }
      throw error;
    }
  };

  const updateDepartment = async (id: string, departmentData: Partial<Department>) => {
    try {
      const validatedUpdates = departmentSchema.partial().parse(departmentData);
      const { error } = await (supabase.from("departments") as any).update(validatedUpdates).eq("id", id);
      if (error) {
        console.error("Error updating department:", error);
        toast.error("Erro ao atualizar departamento");
        throw error;
      }
      setDepartments(departments.map(d => d.id === id ? { ...d, ...validatedUpdates } : d));
      toast.success("Departamento atualizado com sucesso!");
    } catch (error) {
      if (error instanceof z.ZodError) {
        toast.error(error.errors[0].message);
        throw error;
      }
      throw error;
    }
  };

  const deleteDepartment = async (id: string) => {
    const { error } = await (supabase.from("departments") as any).delete().eq("id", id);
    if (error) throw error;
    setDepartments(departments.filter(d => d.id !== id));
  };

  const value: DataContextType = {
    users,
    locations,
    assets,
    inventories,
    discrepancies,
    transfers,
    departments,
    categories,
    addUser,
    updateUser,
    deleteUser,
    addLocation,
    updateLocation,
    deleteLocation,
    addAsset,
    updateAsset,
    deleteAsset,
    addInventory,
    updateInventory,
    deleteInventory,
    addDiscrepancy,
    updateDiscrepancy,
    deleteDiscrepancy,
    addTransfer,
    updateTransfer,
    deleteTransfer,
    addDepartment,
    updateDepartment,
    deleteDepartment,
    refreshTransfers: loadTransfers,
    refreshAssets: loadAssets,
  };

  return <DataContext.Provider value={value}>{children}</DataContext.Provider>;
}

export function useData() {
  const context = useContext(DataContext);
  if (context === undefined) {
    throw new Error("useData must be used within a DataProvider");
  }
  return context;
}
