import { useState, useEffect } from 'react';
import { supabase } from '@/integrations/supabase/client';

export type UserRole = 'admin' | 'manager' | 'user';

interface UserRoleData {
  role: UserRole | null;
  loading: boolean;
  isAdmin: boolean;
  isManager: boolean;
  isUser: boolean;
  userId: string | null;
  userDepartmentId: string | null;
}

export function useUserRole(): UserRoleData {
  const [role, setRole] = useState<UserRole | null>(null);
  const [loading, setLoading] = useState(true);
  const [userId, setUserId] = useState<string | null>(null);
  const [userDepartmentId, setUserDepartmentId] = useState<string | null>(null);

  useEffect(() => {
    async function fetchUserRole() {
      try {
        const { data: { user } } = await supabase.auth.getUser();
        
        if (!user) {
          setRole(null);
          setUserId(null);
          setUserDepartmentId(null);
          setLoading(false);
          return;
        }

        setUserId(user.id);

        const { data, error } = await supabase
          .from('user_roles')
          .select('role')
          .eq('user_id', user.id)
          .single();

        if (error) {
          console.error('Erro ao buscar role do usuário:', error);
          setRole('user'); // Default to user if error
        } else {
          setRole(data.role as UserRole);
          
          // Se for manager, buscar o departamento associado
          if (data.role === 'manager') {
            const { data: deptData } = await supabase
              .from('departments')
              .select('id')
              .eq('responsible_id', user.id)
              .single();
            
            if (deptData) {
              setUserDepartmentId(deptData.id);
            }
          }
        }
      } catch (error) {
        console.error('Erro ao verificar role:', error);
        setRole('user');
      } finally {
        setLoading(false);
      }
    }

    fetchUserRole();
  }, []);

  const isAdmin = role === 'admin';
  const isManager = role === 'manager';
  const isUser = role === 'user';

  return {
    role,
    loading,
    isAdmin,
    isManager,
    isUser,
    userId,
    userDepartmentId,
  };
}
