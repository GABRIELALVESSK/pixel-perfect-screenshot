import { z } from 'zod';

// Asset validation schema
export const assetSchema = z.object({
  name: z.string()
    .trim()
    .min(1, 'Nome é obrigatório')
    .max(200, 'Nome deve ter no máximo 200 caracteres'),
  inventory_number: z.string()
    .trim()
    .min(1, 'Número de inventário é obrigatório')
    .max(50, 'Número de inventário deve ter no máximo 50 caracteres')
    .regex(/^[A-Z0-9-]+$/i, 'Número de inventário deve conter apenas letras, números e hífens'),
  description: z.string()
    .max(1000, 'Descrição deve ter no máximo 1000 caracteres')
    .nullable()
    .optional(),
  value: z.number()
    .min(0, 'Valor deve ser positivo')
    .max(999999999, 'Valor muito alto'),
  acquisition_date: z.string()
    .regex(/^\d{4}-\d{2}-\d{2}$/, 'Data inválida (formato: YYYY-MM-DD)'),
  start_use_date: z.string()
    .regex(/^\d{4}-\d{2}-\d{2}$/, 'Data inválida (formato: YYYY-MM-DD)')
    .nullable()
    .optional(),
  status: z.enum(['Ativo', 'Inativo', 'Em Manutenção', 'Baixado'], {
    errorMap: () => ({ message: 'Status inválido' })
  }).default('Ativo'),
  category_id: z.string().uuid('ID de categoria inválido').nullable().optional(),
  location_id: z.string().uuid('ID de localização inválido').nullable().optional(),
  department_id: z.string().uuid('ID de departamento inválido').nullable().optional(),
  responsible_id: z.string().uuid('ID de responsável inválido').nullable().optional(),
  custom_depreciation: z.boolean().optional().default(false),
  notes: z.string()
    .max(2000, 'Notas devem ter no máximo 2000 caracteres')
    .nullable()
    .optional()
});

// Location validation schema
export const locationSchema = z.object({
  name: z.string()
    .trim()
    .min(1, 'Nome é obrigatório')
    .max(200, 'Nome deve ter no máximo 200 caracteres'),
  type: z.enum(['Prédio', 'Andar', 'Sala', 'Setor'], {
    errorMap: () => ({ message: 'Tipo de localização inválido' })
  }),
  address: z.string()
    .max(500, 'Endereço deve ter no máximo 500 caracteres')
    .nullable()
    .optional(),
  parent: z.string().uuid('ID do local pai inválido').nullable().optional(),
  floors: z.number()
    .int('Número de andares deve ser inteiro')
    .min(0, 'Número de andares deve ser positivo')
    .max(200, 'Número de andares muito alto')
    .nullable()
    .optional(),
  status: z.boolean().default(true)
});

// Department validation schema
export const departmentSchema = z.object({
  name: z.string()
    .trim()
    .min(1, 'Nome é obrigatório')
    .max(200, 'Nome deve ter no máximo 200 caracteres'),
  location_id: z.string().uuid('ID de localização inválido').nullable().optional(),
  responsible_id: z.string().uuid('ID de responsável inválido').nullable().optional(),
  qtd: z.number().int().nullable().optional(),
  codigo: z.string().max(50, 'Código deve ter no máximo 50 caracteres').nullable().optional(),
  sigla: z.string().max(50, 'Sigla deve ter no máximo 50 caracteres').nullable().optional(),
  encarregado: z.string().max(200, 'Nome do encarregado deve ter no máximo 200 caracteres').nullable().optional(),
  id_funcional_encarregado: z.string().max(50, 'ID funcional deve ter no máximo 50 caracteres').nullable().optional(),
  substituto: z.string().max(200, 'Nome do substituto deve ter no máximo 200 caracteres').nullable().optional(),
  id_funcional_substituto: z.string().max(50, 'ID funcional deve ter no máximo 50 caracteres').nullable().optional(),
  created_at: z.string().nullable().optional(),
  updated_at: z.string().nullable().optional()
});

// Transfer validation schema
export const transferSchema = z.object({
  asset_id: z.string().uuid('ID de ativo inválido'),
  from_location_id: z.string().uuid('ID de localização de origem inválido').nullable().optional(),
  to_location_id: z.string().uuid('ID de localização de destino inválido').nullable().optional(),
  responsible_id: z.string().uuid('ID de responsável inválido').nullable().optional(),
  date: z.string()
    .regex(/^\d{4}-\d{2}-\d{2}(T\d{2}:\d{2}:\d{2})?/, 'Data inválida')
    .nullable()
    .optional(),
  status: z.enum(['Pendente', 'Em Andamento', 'Concluída', 'Cancelada'], {
    errorMap: () => ({ message: 'Status inválido' })
  }).default('Pendente'),
  notes: z.string()
    .max(1000, 'Notas devem ter no máximo 1000 caracteres')
    .nullable()
    .optional()
});

// Inventory validation schema
export const inventorySchema = z.object({
  name: z.string()
    .trim()
    .min(1, 'Nome é obrigatório')
    .max(200, 'Nome deve ter no máximo 200 caracteres'),
  start_date: z.string()
    .regex(/^\d{4}-\d{2}-\d{2}$/, 'Data inválida (formato: YYYY-MM-DD)'),
  end_date: z.string()
    .regex(/^\d{4}-\d{2}-\d{2}$/, 'Data inválida (formato: YYYY-MM-DD)')
    .nullable()
    .optional(),
  status: z.enum(['Em Andamento', 'Concluído', 'Cancelado'], {
    errorMap: () => ({ message: 'Status inválido' })
  }).default('Em Andamento'),
  responsible_id: z.string().uuid('ID de responsável inválido').nullable().optional(),
  progress: z.number()
    .min(0, 'Progresso deve ser entre 0 e 100')
    .max(100, 'Progresso deve ser entre 0 e 100')
    .nullable()
    .optional()
    .default(0)
});

// Discrepancy validation schema
export const discrepancySchema = z.object({
  inventory_id: z.string().uuid('ID de inventário inválido'),
  asset_id: z.string().uuid('ID de ativo inválido'),
  expected_location_id: z.string().uuid('ID de localização esperada inválido').nullable().optional(),
  actual_location_id: z.string().uuid('ID de localização real inválido').nullable().optional(),
  status: z.enum(['Pendente', 'Resolvida', 'Ignorada'], {
    errorMap: () => ({ message: 'Status inválido' })
  }).default('Pendente'),
  date: z.string()
    .regex(/^\d{4}-\d{2}-\d{2}(T\d{2}:\d{2}:\d{2})?/, 'Data inválida')
    .nullable()
    .optional(),
  notes: z.string()
    .max(1000, 'Notas devem ter no máximo 1000 caracteres')
    .nullable()
    .optional()
});

// Type exports for TypeScript
export type AssetInput = z.infer<typeof assetSchema>;
export type LocationInput = z.infer<typeof locationSchema>;
export type DepartmentInput = z.infer<typeof departmentSchema>;
export type TransferInput = z.infer<typeof transferSchema>;
export type InventoryInput = z.infer<typeof inventorySchema>;
export type DiscrepancyInput = z.infer<typeof discrepancySchema>;
