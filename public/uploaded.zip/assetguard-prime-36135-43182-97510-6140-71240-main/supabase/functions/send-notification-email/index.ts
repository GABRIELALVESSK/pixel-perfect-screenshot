import { serve } from "https://deno.land/std@0.190.0/http/server.ts";
import { Resend } from "https://esm.sh/resend@2.0.0";

const resend = new Resend(Deno.env.get("RESEND_API_KEY"));

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
};

interface NotificationEmailRequest {
  to: string;
  subject: string;
  type: 'transfer_initiated' | 'transfer_pending_approval' | 'transfer_approved' | 'transfer_completed' | 'user_invitation';
  data: {
    userName?: string;
    assetName?: string;
    fromLocation?: string;
    toLocation?: string;
    inviteLink?: string;
    transferId?: string;
  };
}

const getEmailTemplate = (type: string, data: any): string => {
  const templates: Record<string, string> = {
    transfer_initiated: `
      <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
        <h2 style="color: #1a365d;">Nova Transferência Iniciada</h2>
        <p>Olá ${data.userName},</p>
        <p>Uma nova transferência foi iniciada e aguarda sua aprovação:</p>
        <div style="background: #f7fafc; padding: 16px; border-radius: 8px; margin: 16px 0;">
          <p><strong>Bem:</strong> ${data.assetName}</p>
          <p><strong>Origem:</strong> ${data.fromLocation}</p>
          <p><strong>Destino:</strong> ${data.toLocation}</p>
        </div>
        <p>Acesse o sistema para aprovar ou rejeitar a transferência.</p>
        <p style="color: #718096; font-size: 12px;">Sistema de Gestão de Bens Móveis</p>
      </div>
    `,
    transfer_pending_approval: `
      <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
        <h2 style="color: #1a365d;">Transferência Aguardando Recebimento</h2>
        <p>Olá ${data.userName},</p>
        <p>O encarregado da unidade de origem aprovou o envio do bem. Agora é necessário confirmar o recebimento:</p>
        <div style="background: #f7fafc; padding: 16px; border-radius: 8px; margin: 16px 0;">
          <p><strong>Bem:</strong> ${data.assetName}</p>
          <p><strong>Origem:</strong> ${data.fromLocation}</p>
          <p><strong>Destino:</strong> ${data.toLocation}</p>
        </div>
        <p>Acesse o sistema para confirmar o recebimento do bem.</p>
        <p style="color: #718096; font-size: 12px;">Sistema de Gestão de Bens Móveis</p>
      </div>
    `,
    transfer_completed: `
      <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
        <h2 style="color: #38a169;">Transferência Concluída</h2>
        <p>Olá ${data.userName},</p>
        <p>A transferência foi concluída com sucesso:</p>
        <div style="background: #f0fff4; padding: 16px; border-radius: 8px; margin: 16px 0;">
          <p><strong>Bem:</strong> ${data.assetName}</p>
          <p><strong>Nova localização:</strong> ${data.toLocation}</p>
        </div>
        <p style="color: #718096; font-size: 12px;">Sistema de Gestão de Bens Móveis</p>
      </div>
    `,
    user_invitation: `
      <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
        <h2 style="color: #1a365d;">Convite para o Sistema de Gestão de Bens</h2>
        <p>Olá ${data.userName},</p>
        <p>Você foi convidado para acessar o Sistema de Gestão de Bens Móveis.</p>
        <p>Clique no link abaixo para criar sua senha e acessar o sistema:</p>
        <div style="margin: 24px 0;">
          <a href="${data.inviteLink}" style="background: #3182ce; color: white; padding: 12px 24px; text-decoration: none; border-radius: 6px;">
            Criar Senha e Acessar
          </a>
        </div>
        <p style="color: #718096; font-size: 12px;">Se você não esperava este convite, pode ignorar este email.</p>
        <p style="color: #718096; font-size: 12px;">Sistema de Gestão de Bens Móveis</p>
      </div>
    `,
  };

  return templates[type] || templates.transfer_initiated;
};

const handler = async (req: Request): Promise<Response> => {
  if (req.method === "OPTIONS") {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const { to, subject, type, data }: NotificationEmailRequest = await req.json();

    console.log(`Sending ${type} email to ${to}`);

    const html = getEmailTemplate(type, data);

    const emailResponse = await resend.emails.send({
      from: "Sistema de Bens <onboarding@resend.dev>",
      to: [to],
      subject: subject,
      html: html,
    });

    console.log("Email sent successfully:", emailResponse);

    return new Response(JSON.stringify(emailResponse), {
      status: 200,
      headers: { "Content-Type": "application/json", ...corsHeaders },
    });
  } catch (error: any) {
    console.error("Error sending email:", error);
    return new Response(
      JSON.stringify({ error: error.message }),
      {
        status: 500,
        headers: { "Content-Type": "application/json", ...corsHeaders },
      }
    );
  }
};

serve(handler);
