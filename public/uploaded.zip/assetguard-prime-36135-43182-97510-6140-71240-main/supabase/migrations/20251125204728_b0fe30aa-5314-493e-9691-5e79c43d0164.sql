-- Adicionar campos necessários para setores na tabela departments
ALTER TABLE public.departments 
ADD COLUMN IF NOT EXISTS qtd integer,
ADD COLUMN IF NOT EXISTS codigo text,
ADD COLUMN IF NOT EXISTS sigla text,
ADD COLUMN IF NOT EXISTS encarregado text,
ADD COLUMN IF NOT EXISTS id_funcional_encarregado text,
ADD COLUMN IF NOT EXISTS substituto text,
ADD COLUMN IF NOT EXISTS id_funcional_substituto text;