-- Remover políticas antigas de assets e locations que permitem managers
DROP POLICY IF EXISTS "Admins e managers podem gerenciar ativos" ON public.assets;
DROP POLICY IF EXISTS "Admins e managers podem gerenciar localizações" ON public.locations;

-- Criar novas políticas permitindo apenas admins para INSERT, UPDATE, DELETE em assets
CREATE POLICY "Apenas admins podem inserir ativos" 
ON public.assets 
FOR INSERT 
TO authenticated
WITH CHECK (has_role(auth.uid(), 'admin'::app_role));

CREATE POLICY "Apenas admins podem atualizar ativos" 
ON public.assets 
FOR UPDATE 
TO authenticated
USING (has_role(auth.uid(), 'admin'::app_role));

CREATE POLICY "Apenas admins podem excluir ativos" 
ON public.assets 
FOR DELETE 
TO authenticated
USING (has_role(auth.uid(), 'admin'::app_role));

-- Criar novas políticas permitindo apenas admins para INSERT, UPDATE, DELETE em locations
CREATE POLICY "Apenas admins podem inserir localizações" 
ON public.locations 
FOR INSERT 
TO authenticated
WITH CHECK (has_role(auth.uid(), 'admin'::app_role));

CREATE POLICY "Apenas admins podem atualizar localizações" 
ON public.locations 
FOR UPDATE 
TO authenticated
USING (has_role(auth.uid(), 'admin'::app_role));

CREATE POLICY "Apenas admins podem excluir localizações" 
ON public.locations 
FOR DELETE 
TO authenticated
USING (has_role(auth.uid(), 'admin'::app_role));

-- Adicionar política para permitir admins excluírem usuários
CREATE POLICY "Apenas admins podem excluir perfis" 
ON public.profiles 
FOR DELETE 
TO authenticated
USING (has_role(auth.uid(), 'admin'::app_role));